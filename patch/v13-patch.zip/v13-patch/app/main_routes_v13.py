"""
v13 route patches — Multi-workload restore endpoints.

Add to main.py:
    from app.main_routes_v13 import register_v13_routes
    register_v13_routes(app)
"""
from flask import jsonify, request, render_template
from app.restore_manager_v2 import RestoreManagerV2


def register_v13_routes(app):
    mgr = RestoreManagerV2()

    # ── UI Page ──
    @app.route("/restore-v2")
    def restore_v2_page():
        return render_template("restore_v2.html")

    # ── Create restore job ──
    @app.route("/api/v2/restore/jobs", methods=["POST"])
    def create_restore_job():
        data = request.get_json(force=True, silent=True) or {}
        try:
            job = mgr.create_job(data)
            # Queue for execution
            from app.tasks import celery_app
            celery_app.send_task("app.tasks.execute_restore_job_v2", args=[job["id"]])
            return jsonify({"status": "created", "job": job}), 201
        except ValueError as e:
            return jsonify({"error": str(e)}), 400
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    # ── List all restore jobs ──
    @app.route("/api/v2/restore/jobs", methods=["GET"])
    def list_restore_jobs():
        return jsonify({"jobs": mgr.list_jobs(limit=int(request.args.get("limit", 50)))})

    # ── Get single job ──
    @app.route("/api/v2/restore/jobs/<job_id>", methods=["GET"])
    def get_restore_job(job_id):
        job = mgr.get_job(job_id)
        if not job:
            return jsonify({"error": "Job not found"}), 404
        return jsonify(job)

    # ── Cancel job ──
    @app.route("/api/v2/restore/jobs/<job_id>/cancel", methods=["POST"])
    def cancel_restore_job(job_id):
        job = mgr.get_job(job_id)
        if not job:
            return jsonify({"error": "Job not found"}), 404
        
        # Mark as cancelled in job + set task control flag
        task_id = job.get("task_id")
        if task_id:
            try:
                from app.tasks import force_cancel_task
                force_cancel_task(task_id)
            except Exception:
                pass
        
        mgr.update_job(job_id, {"status": "cancelled"})
        return jsonify({"status": "cancelled"})

    # ── Delete job ──
    @app.route("/api/v2/restore/jobs/<job_id>", methods=["DELETE"])
    def delete_restore_job(job_id):
        ok = mgr.delete_job(job_id)
        if not ok:
            return jsonify({"error": "Cannot delete active job"}), 409
        return jsonify({"status": "deleted"})

    # ── Dry run preview ──
    @app.route("/api/v2/restore/preview", methods=["POST"])
    def preview_restore():
        data = request.get_json(force=True, silent=True) or {}
        try:
            result = mgr.dry_run(data)
            return jsonify(result)
        except Exception as e:
            return jsonify({"error": str(e)}), 500
