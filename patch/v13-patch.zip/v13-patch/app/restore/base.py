"""
Base restore class — v13.
Handles common auth + progress tracking + control (pause/resume/cancel).
"""
import os
import json
import time
import logging
import msal
import requests
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Callable

log = logging.getLogger("m365_backup")


class BaseRestore:
    """Base class for all workload restores."""

    WORKLOAD_NAME = "base"
    GRAPH = "https://graph.microsoft.com/v1.0"

    def __init__(self, tenant: dict, backup_path: str,
                 progress_callback: Optional[Callable] = None,
                 task_id: str = None, mode: str = "merge"):
        """
        Args:
            tenant: tenant dict (with credentials)
            backup_path: absolute path to backup folder to restore
            progress_callback: callable(event_name, data_dict)
            task_id: for pause/resume/cancel
            mode: 'overwrite' | 'merge' | 'new_location'
        """
        self.tenant = tenant
        self.backup_path = Path(backup_path)
        self.progress_callback = progress_callback
        self.task_id = task_id
        self.mode = mode

        # Auth
        self._token = None
        self._token_expires_at = 0
        self.session = requests.Session()

        # Stats
        self.stats = {
            "tenant_id": tenant.get("id"),
            "tenant_name": tenant.get("name"),
            "workload": self.WORKLOAD_NAME,
            "mode": mode,
            "backup_path": str(backup_path),
            "start_time": None,
            "end_time": None,
            "items_processed": 0,
            "items_skipped": 0,
            "items_failed": 0,
            "bytes_uploaded": 0,
            "targets_processed": 0,
            "targets_failed": 0,
            "errors": [],
            "cancelled": False,
        }
        self._last_emit = 0

    # ── AUTH ──────────────────────────────────────────────────
    def get_token(self) -> str:
        now = time.time()
        if self._token and now < self._token_expires_at - 60:
            return self._token
        app = msal.ConfidentialClientApplication(
            self.tenant["client_id"],
            authority=f"https://login.microsoftonline.com/{self.tenant['tenant_id']}",
            client_credential=self.tenant["client_secret"],
        )
        result = app.acquire_token_for_client(
            scopes=["https://graph.microsoft.com/.default"]
        )
        if "access_token" not in result:
            raise Exception(f"Auth failed: {result.get('error_description', 'Unknown')}")
        self._token = result["access_token"]
        self._token_expires_at = now + result.get("expires_in", 3600)
        return self._token

    def _headers(self, content_type="application/json") -> dict:
        return {
            "Authorization": f"Bearer {self.get_token()}",
            "Content-Type": content_type,
        }

    # ── HTTP with retry ──
    def _request(self, method, url, **kwargs):
        for attempt in range(3):
            try:
                r = self.session.request(method, url, **kwargs)
                if r.status_code == 429:
                    retry = int(r.headers.get("Retry-After", 30))
                    log.warning(f"Rate limited, wait {retry}s")
                    time.sleep(retry)
                    continue
                r.raise_for_status()
                return r
            except requests.HTTPError as e:
                if r.status_code in (404, 409, 400) or attempt == 2:
                    raise
                time.sleep(2 ** attempt)
        raise Exception(f"Failed after 3 attempts: {method} {url}")

    def _get(self, url, params=None):
        r = self._request("GET", url, headers=self._headers(),
                          params=params, timeout=60)
        return r.json()

    def _post(self, url, json_body=None, data=None,
              content_type="application/json"):
        headers = self._headers(content_type)
        r = self._request("POST", url, headers=headers,
                          json=json_body, data=data, timeout=120)
        return r.json() if r.text else {}

    def _put(self, url, data=None, content_type="application/octet-stream"):
        headers = self._headers(content_type)
        r = self._request("PUT", url, headers=headers, data=data, timeout=300)
        return r.json() if r.text else {}

    # ── CONTROL ──
    def _check_control(self):
        if not self.task_id:
            return
        try:
            from app.task_control import check_control
            check_control(self.task_id)
        except ImportError:
            pass

    # ── PROGRESS ──
    def emit(self, event: str, extra: dict = None):
        now = time.time()
        important = event in (
            "restore_start", "restore_done", "target_start", "target_done",
            "paused", "resumed", "cancelled",
        )
        if important or (now - self._last_emit > 0.5):
            self._last_emit = now
            if self.progress_callback:
                data = dict(self.stats)
                if extra:
                    data.update(extra)
                data["event"] = event
                self.progress_callback(event, data)

    # ── MAIN INTERFACE (override) ──
    def restore(self) -> dict:
        """Main restore entry. Override in subclass."""
        raise NotImplementedError(f"{self.WORKLOAD_NAME} does not implement restore()")

    def dry_run(self) -> dict:
        """Preview what will be restored without doing it."""
        raise NotImplementedError()
