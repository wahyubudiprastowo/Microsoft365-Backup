"""Restore workload factory — v13."""
from .base import BaseRestore
from .sharepoint import SharePointRestore
from .onedrive import OneDriveRestore
from .outlook import OutlookRestore


RESTORE_REGISTRY = {
    "sharepoint": SharePointRestore,
    "onedrive": OneDriveRestore,
    "outlook": OutlookRestore,
}


def get_restore(workload: str, tenant: dict, backup_path: str,
                progress_callback=None, task_id=None, mode="merge",
                **extra_kwargs) -> BaseRestore:
    """Factory function to get restore instance for a workload."""
    cls = RESTORE_REGISTRY.get(workload)
    if not cls:
        raise ValueError(f"Unknown workload: {workload}. "
                         f"Available: {list(RESTORE_REGISTRY.keys())}")
    return cls(
        tenant=tenant,
        backup_path=backup_path,
        progress_callback=progress_callback,
        task_id=task_id,
        mode=mode,
        **extra_kwargs,
    )
