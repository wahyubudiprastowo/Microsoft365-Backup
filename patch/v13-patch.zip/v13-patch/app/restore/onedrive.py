"""OneDrive restore — v13 NEW.
Restores per-user OneDrive contents.

Backup structure:
  backup_20260628_020000/
    ├── user1_at_digiserve.co.id/
    │   ├── file1.docx
    │   ├── subfolder/
    │   │   └── file2.xlsx
    │   └── _user_metadata.json
    ├── user2_at_digiserve.co.id/
    └── _workload_manifest.json

Restore strategies:
- overwrite : Replace files in user's OneDrive
- merge     : Only add files that don't exist
- new_location : Restore to a different user's OneDrive (mapped)
"""
import os
import json
from pathlib import Path
from datetime import datetime, timezone
from .base import BaseRestore

import logging
log = logging.getLogger("m365_backup")


class OneDriveRestore(BaseRestore):
    WORKLOAD_NAME = "onedrive"

    def __init__(self, tenant, backup_path, user_mapping=None,
                 target_folder="Restored", **kwargs):
        """
        user_mapping: dict {backup_user_email: target_user_email}
                     If None, restore to same user email.
        target_folder: subfolder in user's OneDrive to restore into
                     (e.g., "Restored/2026-07-08")
        """
        super().__init__(tenant, backup_path, **kwargs)
        self.user_mapping = user_mapping or {}
        self.target_folder = target_folder.strip("/")

    def _resolve_user_drive(self, user_email: str):
        """Get target user's drive ID by email/UPN."""
        # First resolve user ID
        try:
            user = self._get(f"{self.GRAPH}/users/{user_email}")
        except Exception as e:
            raise Exception(f"User not found: {user_email}: {e}")

        # Get user's drive
        try:
            drive = self._get(f"{self.GRAPH}/users/{user['id']}/drive")
            return user["id"], drive["id"]
        except Exception as e:
            raise Exception(f"OneDrive not provisioned for {user_email}: {e}")

    def restore(self) -> dict:
        self.stats["start_time"] = datetime.now(timezone.utc).isoformat()
        self.emit("restore_start", {"backup_path": str(self.backup_path)})

        try:
            # Iterate user folders in backup
            for user_dir in self.backup_path.iterdir():
                if not user_dir.is_dir() or user_dir.name.startswith("_"):
                    continue

                self._check_control()
                
                # Decode backup email (user_at_domain.com → user@domain.com)
                backup_email = user_dir.name.replace("_at_", "@")
                target_email = self.user_mapping.get(backup_email, backup_email)
                
                self.emit("target_start", {
                    "target_name": target_email,
                    "backup_source": backup_email,
                })

                try:
                    user_id, drive_id = self._resolve_user_drive(target_email)
                    self._restore_user_drive(user_dir, drive_id)
                    self.stats["targets_processed"] += 1
                    self.emit("target_done", {"target_name": target_email, "status": "success"})
                except Exception as e:
                    self.stats["targets_failed"] += 1
                    self.stats["errors"].append(f"[{target_email}] {e}")
                    self.emit("target_done", {"target_name": target_email, "status": "failed", "error": str(e)})

        except Exception as e:
            log.error(f"OneDrive restore failed: {e}", exc_info=True)
            self.stats["errors"].append(f"Fatal: {e}")

        self.stats["end_time"] = datetime.now(timezone.utc).isoformat()
        self.emit("restore_done")
        return self.stats

    def _restore_user_drive(self, user_dir: Path, drive_id: str):
        """Restore one user's OneDrive contents."""
        # Ensure target folder exists in OneDrive
        base_path = self.target_folder if self.mode == "new_location" else ""
        
        if base_path:
            try:
                # Try to create the base folder (idempotent)
                self._post(
                    f"{self.GRAPH}/drives/{drive_id}/root/children",
                    json_body={
                        "name": base_path,
                        "folder": {},
                        "@microsoft.graph.conflictBehavior": "replace",
                    }
                )
            except Exception:
                pass  # already exists

        self._upload_folder(user_dir, drive_id, base_path)

    def _upload_folder(self, local_dir: Path, drive_id: str, remote_path: str):
        for item in local_dir.iterdir():
            self._check_control()
            if item.name.startswith("_") or item.name.startswith("."):
                continue

            if item.is_dir():
                sub = f"{remote_path}/{item.name}" if remote_path else item.name
                self._upload_folder(item, drive_id, sub)
            elif item.is_file():
                self._upload_file(item, drive_id, remote_path)

    def _upload_file(self, local_file: Path, drive_id: str, remote_path: str):
        file_name = local_file.name
        remote_full = f"{remote_path}/{file_name}" if remote_path else file_name

        if self.mode == "merge":
            try:
                existing = self._get(f"{self.GRAPH}/drives/{drive_id}/root:/{remote_full}")
                if existing.get("id"):
                    self.stats["items_skipped"] += 1
                    return
            except Exception:
                pass

        try:
            size = local_file.stat().st_size
            if size < 4 * 1024 * 1024:
                with open(local_file, "rb") as f:
                    self._put(
                        f"{self.GRAPH}/drives/{drive_id}/root:/{remote_full}:/content",
                        data=f,
                    )
            else:
                self._upload_large_file(local_file, drive_id, remote_full)

            self.stats["items_processed"] += 1
            self.stats["bytes_uploaded"] += size
            self.emit("file_uploaded", {"current_file": file_name})
        except Exception as e:
            self.stats["items_failed"] += 1
            self.stats["errors"].append(f"{file_name}: {str(e)[:120]}")

    def _upload_large_file(self, local_file: Path, drive_id: str, remote_path: str):
        session = self._post(
            f"{self.GRAPH}/drives/{drive_id}/root:/{remote_path}:/createUploadSession",
            json_body={"item": {"@microsoft.graph.conflictBehavior": "replace"}}
        )
        upload_url = session["uploadUrl"]
        chunk_size = 5 * 1024 * 1024
        total = local_file.stat().st_size

        with open(local_file, "rb") as f:
            start = 0
            while start < total:
                self._check_control()
                chunk = f.read(chunk_size)
                if not chunk:
                    break
                end = start + len(chunk) - 1
                headers = {
                    "Content-Length": str(len(chunk)),
                    "Content-Range": f"bytes {start}-{end}/{total}",
                }
                r = self.session.put(upload_url, data=chunk, headers=headers, timeout=300)
                r.raise_for_status()
                start = end + 1

    def dry_run(self) -> dict:
        result = {
            "workload": "onedrive",
            "users_in_backup": 0,
            "files_to_upload": 0,
            "total_size_bytes": 0,
        }
        for user_dir in self.backup_path.iterdir():
            if not user_dir.is_dir() or user_dir.name.startswith("_"):
                continue
            result["users_in_backup"] += 1
            for f in user_dir.rglob("*"):
                if f.is_file() and not f.name.startswith("_"):
                    result["files_to_upload"] += 1
                    result["total_size_bytes"] += f.stat().st_size
        return result
