"""Outlook restore — v13 NEW.
Restores per-user mailbox: messages / calendar / contacts.

Backup structure:
  backup_20260628_020000/
    ├── user1_at_digiserve.co.id/
    │   ├── messages.json         (Graph message objects)
    │   ├── calendar.json         (Graph event objects)
    │   ├── contacts.json         (Graph contact objects)
    │   └── _mailbox_metadata.json
    └── _workload_manifest.json

Restore modes:
- overwrite : Replace items if they exist (matched by internetMessageId)
- merge     : Only import items that don't exist
- new_location : Create restore folder in mailbox, import there

Restore strategy:
- Messages → into "M365 Restored" folder (Graph doesn't support direct restore)
- Calendar → into user's default calendar as new events
- Contacts → into default contacts folder
"""
import os
import json
from pathlib import Path
from datetime import datetime, timezone
from .base import BaseRestore

import logging
log = logging.getLogger("m365_backup")

RESTORE_FOLDER_NAME = "M365 Restored"


class OutlookRestore(BaseRestore):
    WORKLOAD_NAME = "outlook"

    def __init__(self, tenant, backup_path, user_mapping=None,
                 restore_items=None, **kwargs):
        """
        user_mapping: {backup_email: target_email}
        restore_items: list of ['messages', 'calendar', 'contacts']
                      If None, restore all three.
        """
        super().__init__(tenant, backup_path, **kwargs)
        self.user_mapping = user_mapping or {}
        self.restore_items = restore_items or ["messages", "calendar", "contacts"]

    def _resolve_user_id(self, user_email: str) -> str:
        try:
            user = self._get(f"{self.GRAPH}/users/{user_email}")
            return user["id"]
        except Exception as e:
            raise Exception(f"User not found: {user_email}: {e}")

    def restore(self) -> dict:
        self.stats["start_time"] = datetime.now(timezone.utc).isoformat()
        self.emit("restore_start", {"backup_path": str(self.backup_path)})

        try:
            for user_dir in self.backup_path.iterdir():
                if not user_dir.is_dir() or user_dir.name.startswith("_"):
                    continue

                self._check_control()

                backup_email = user_dir.name.replace("_at_", "@")
                target_email = self.user_mapping.get(backup_email, backup_email)

                self.emit("target_start", {
                    "target_name": target_email,
                    "backup_source": backup_email,
                })

                try:
                    user_id = self._resolve_user_id(target_email)

                    # Restore each item type
                    if "messages" in self.restore_items:
                        self._restore_messages(user_dir, user_id)
                    if "calendar" in self.restore_items:
                        self._restore_calendar(user_dir, user_id)
                    if "contacts" in self.restore_items:
                        self._restore_contacts(user_dir, user_id)

                    self.stats["targets_processed"] += 1
                    self.emit("target_done", {"target_name": target_email, "status": "success"})
                except Exception as e:
                    self.stats["targets_failed"] += 1
                    self.stats["errors"].append(f"[{target_email}] {e}")
                    self.emit("target_done", {"target_name": target_email, "status": "failed", "error": str(e)})
        except Exception as e:
            log.error(f"Outlook restore failed: {e}", exc_info=True)
            self.stats["errors"].append(f"Fatal: {e}")

        self.stats["end_time"] = datetime.now(timezone.utc).isoformat()
        self.emit("restore_done")
        return self.stats

    # ── Messages ──
    def _restore_messages(self, user_dir: Path, user_id: str):
        msg_file = user_dir / "messages.json"
        if not msg_file.exists():
            return

        try:
            messages = json.load(open(msg_file))
        except Exception as e:
            self.stats["errors"].append(f"messages.json: {e}")
            return

        # Create/get restore folder
        restore_folder_id = self._ensure_mail_folder(user_id, RESTORE_FOLDER_NAME)

        # For merge mode: get existing message internetMessageIds in that folder
        existing_ids = set()
        if self.mode == "merge":
            try:
                items = self._get(
                    f"{self.GRAPH}/users/{user_id}/mailFolders/{restore_folder_id}/messages",
                    params={"$select": "internetMessageId", "$top": 999}
                )
                existing_ids = {m.get("internetMessageId") for m in items.get("value", [])}
            except Exception:
                pass

        for msg in messages:
            self._check_control()
            try:
                imi = msg.get("internetMessageId")
                if self.mode == "merge" and imi and imi in existing_ids:
                    self.stats["items_skipped"] += 1
                    continue

                # Clean the message for POST
                clean_msg = self._clean_message_for_post(msg)

                self._post(
                    f"{self.GRAPH}/users/{user_id}/mailFolders/{restore_folder_id}/messages",
                    json_body=clean_msg,
                )
                self.stats["items_processed"] += 1
                self.emit("message_restored", {"current_file": msg.get("subject", "(no subject)")[:50]})
            except Exception as e:
                self.stats["items_failed"] += 1
                self.stats["errors"].append(f"msg '{msg.get('subject','?')[:30]}': {str(e)[:100]}")

    def _ensure_mail_folder(self, user_id: str, folder_name: str) -> str:
        """Get or create a mail folder. Returns folder ID."""
        # Try to find existing
        try:
            folders = self._get(
                f"{self.GRAPH}/users/{user_id}/mailFolders",
                params={"$filter": f"displayName eq '{folder_name}'"}
            )
            if folders.get("value"):
                return folders["value"][0]["id"]
        except Exception:
            pass

        # Create new
        try:
            new = self._post(
                f"{self.GRAPH}/users/{user_id}/mailFolders",
                json_body={"displayName": folder_name},
            )
            return new["id"]
        except Exception as e:
            raise Exception(f"Cannot create folder '{folder_name}': {e}")

    def _clean_message_for_post(self, msg: dict) -> dict:
        """Remove read-only fields Graph rejects on POST."""
        remove_fields = [
            "id", "createdDateTime", "lastModifiedDateTime",
            "changeKey", "categories", "parentFolderId",
            "conversationId", "conversationIndex", "isDeliveryReceiptRequested",
            "isReadReceiptRequested", "webLink", "inferenceClassification",
            "@odata.etag", "@odata.context",
        ]
        cleaned = {k: v for k, v in msg.items() if k not in remove_fields}
        # Ensure body is preserved
        if "body" in cleaned and isinstance(cleaned["body"], dict):
            cleaned["body"] = {
                "contentType": cleaned["body"].get("contentType", "html"),
                "content": cleaned["body"].get("content", ""),
            }
        return cleaned

    # ── Calendar ──
    def _restore_calendar(self, user_dir: Path, user_id: str):
        cal_file = user_dir / "calendar.json"
        if not cal_file.exists():
            return

        try:
            events = json.load(open(cal_file))
        except Exception as e:
            self.stats["errors"].append(f"calendar.json: {e}")
            return

        # For merge: get existing event iCalUIds
        existing_uids = set()
        if self.mode == "merge":
            try:
                items = self._get(
                    f"{self.GRAPH}/users/{user_id}/events",
                    params={"$select": "iCalUId", "$top": 999}
                )
                existing_uids = {e.get("iCalUId") for e in items.get("value", []) if e.get("iCalUId")}
            except Exception:
                pass

        for event in events:
            self._check_control()
            try:
                icu = event.get("iCalUId")
                if self.mode == "merge" and icu and icu in existing_uids:
                    self.stats["items_skipped"] += 1
                    continue

                clean_evt = self._clean_event_for_post(event)
                self._post(f"{self.GRAPH}/users/{user_id}/events", json_body=clean_evt)
                self.stats["items_processed"] += 1
                self.emit("event_restored", {"current_file": event.get("subject", "(no subject)")[:50]})
            except Exception as e:
                self.stats["items_failed"] += 1
                self.stats["errors"].append(f"event '{event.get('subject','?')[:30]}': {str(e)[:100]}")

    def _clean_event_for_post(self, event: dict) -> dict:
        remove_fields = [
            "id", "createdDateTime", "lastModifiedDateTime",
            "changeKey", "categories", "originalStartTimeZone",
            "originalEndTimeZone", "iCalUId", "reminderMinutesBeforeStart",
            "isReminderOn", "hasAttachments", "responseStatus",
            "seriesMasterId", "webLink", "onlineMeetingUrl",
            "@odata.etag", "@odata.context",
        ]
        return {k: v for k, v in event.items() if k not in remove_fields}

    # ── Contacts ──
    def _restore_contacts(self, user_dir: Path, user_id: str):
        cont_file = user_dir / "contacts.json"
        if not cont_file.exists():
            return

        try:
            contacts = json.load(open(cont_file))
        except Exception as e:
            self.stats["errors"].append(f"contacts.json: {e}")
            return

        # For merge: build existing contact emails set
        existing_emails = set()
        if self.mode == "merge":
            try:
                items = self._get(
                    f"{self.GRAPH}/users/{user_id}/contacts",
                    params={"$select": "emailAddresses", "$top": 999}
                )
                for c in items.get("value", []):
                    for e in (c.get("emailAddresses") or []):
                        if e.get("address"):
                            existing_emails.add(e["address"].lower())
            except Exception:
                pass

        for contact in contacts:
            self._check_control()
            try:
                # Check merge
                if self.mode == "merge":
                    c_emails = [e.get("address", "").lower() for e in (contact.get("emailAddresses") or [])]
                    if any(e in existing_emails for e in c_emails):
                        self.stats["items_skipped"] += 1
                        continue

                clean_contact = self._clean_contact_for_post(contact)
                self._post(f"{self.GRAPH}/users/{user_id}/contacts", json_body=clean_contact)
                self.stats["items_processed"] += 1
                self.emit("contact_restored", {"current_file": contact.get("displayName", "(no name)")})
            except Exception as e:
                self.stats["items_failed"] += 1
                self.stats["errors"].append(f"contact '{contact.get('displayName','?')[:30]}': {str(e)[:100]}")

    def _clean_contact_for_post(self, contact: dict) -> dict:
        remove_fields = [
            "id", "createdDateTime", "lastModifiedDateTime",
            "changeKey", "categories", "parentFolderId",
            "@odata.etag", "@odata.context",
        ]
        return {k: v for k, v in contact.items() if k not in remove_fields}

    # ── Dry run ──
    def dry_run(self) -> dict:
        result = {
            "workload": "outlook",
            "users_in_backup": 0,
            "messages_to_restore": 0,
            "events_to_restore": 0,
            "contacts_to_restore": 0,
        }
        for user_dir in self.backup_path.iterdir():
            if not user_dir.is_dir() or user_dir.name.startswith("_"):
                continue
            result["users_in_backup"] += 1
            for key, filename in [
                ("messages_to_restore", "messages.json"),
                ("events_to_restore", "calendar.json"),
                ("contacts_to_restore", "contacts.json"),
            ]:
                f = user_dir / filename
                if f.exists():
                    try:
                        items = json.load(open(f))
                        result[key] += len(items)
                    except Exception:
                        pass
        return result
