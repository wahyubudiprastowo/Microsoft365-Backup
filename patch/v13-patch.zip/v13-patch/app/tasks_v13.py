"""
v13 additive Celery tasks.
Add to app/tasks.py at END OF FILE:

    from app.tasks_v13 import register_v13_tasks
    register_v13_tasks(celery_app)
"""
import logging

log = logging.getLogger("m365_backup")


def register_v13_tasks(celery_app):
    """Register v13 restore execution task."""

    @celery_app.task(bind=True, name="app.tasks.execute_restore_job_v2")
    def execute_restore_job_v2(self, job_id: str):
        """
        Execute a queued restore job (v13 multi-workload).
        """
        from app.restore_manager_v2 import RestoreManagerV2
        mgr = RestoreManagerV2()
        log.info(f"═══ Restore job {job_id[:8]} ═══")
        return mgr.execute(job_id, task_id=self.request.id)
