"""
Restore Manager v13 — Multi-workload restore orchestration.

Job schema in Redis:
  key: m365:restore_job:{job_id}
  value: {
    id, tenant_id, tenant_name, workload,
    backup_path, source_backup, mode,
    target_site_id, target_site_path,  # SP-specific
    user_mapping,                       # OneDrive/Outlook-specific
    target_folder,                      # OneDrive new_location
    restore_items,                      # Outlook: which items
    status: queued|running|paused|completed|failed|cancelled,
    progress: 0-100,
    created_at, started_at, completed_at,
    result: {stats},
    error: str,
  }
"""
import os
import json
import uuid
import logging
import redis as redis_lib
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Optional, List

log = logging.getLogger("m365_backup")


class RestoreManagerV2:
    """Manages restore jobs across all workloads."""

    JOB_PREFIX = "m365:restore_job:"
    JOB_LIST = "m365:restore_jobs:list"

    def __init__(self):
        self.r = redis_lib.Redis(host="redis", port=6379, db=2, decode_responses=True)

    # ── CRUD ──
    def create_job(self, config: dict) -> dict:
        """
        Create a new restore job.
        
        config must contain:
          - tenant_id
          - workload (sharepoint/onedrive/outlook)
          - backup_path (absolute path)
          - source_backup (display name like backup_20260628_020000)
          - mode (overwrite/merge/new_location)
          
        Optional (workload-specific):
          - target_site_id, target_site_path  (SharePoint)
          - user_mapping                        (OneDrive, Outlook)
          - target_folder                       (OneDrive new_location)
          - restore_items                       (Outlook: [messages, calendar, contacts])
        """
        job_id = str(uuid.uuid4())
        
        # Validate required fields
        for field in ["tenant_id", "workload", "backup_path", "source_backup"]:
            if not config.get(field):
                raise ValueError(f"Missing required field: {field}")
        
        # Validate workload
        if config["workload"] not in ["sharepoint", "onedrive", "outlook"]:
            raise ValueError(f"Unknown workload: {config['workload']}")
        
        # Validate mode
        mode = config.get("mode", "merge")
        if mode not in ["overwrite", "merge", "new_location"]:
            raise ValueError(f"Invalid mode: {mode}")

        # Build job record
        job = {
            "id": job_id,
            "tenant_id": config["tenant_id"],
            "tenant_name": config.get("tenant_name", ""),
            "workload": config["workload"],
            "backup_path": config["backup_path"],
            "source_backup": config["source_backup"],
            "mode": mode,
            "status": "queued",
            "progress": 0,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "started_at": None,
            "completed_at": None,
            "result": None,
            "error": None,
        }
        
        # Workload-specific fields
        if config["workload"] == "sharepoint":
            job["target_site_id"] = config.get("target_site_id")
            job["target_site_path"] = config.get("target_site_path")
            job["target_name"] = config.get("target_name", "")
        elif config["workload"] == "onedrive":
            job["user_mapping"] = config.get("user_mapping", {})
            job["target_folder"] = config.get("target_folder", "Restored")
        elif config["workload"] == "outlook":
            job["user_mapping"] = config.get("user_mapping", {})
            job["restore_items"] = config.get("restore_items",
                                              ["messages", "calendar", "contacts"])

        # Save to Redis
        self.r.set(self.JOB_PREFIX + job_id, json.dumps(job))
        self.r.lpush(self.JOB_LIST, job_id)
        self.r.ltrim(self.JOB_LIST, 0, 99)  # Keep last 100

        log.info(f"Restore job created: {job_id[:8]} — {config['workload']} for {config.get('tenant_name', '?')}")
        return job

    def get_job(self, job_id: str) -> Optional[dict]:
        data = self.r.get(self.JOB_PREFIX + job_id)
        return json.loads(data) if data else None

    def list_jobs(self, limit: int = 50) -> List[dict]:
        ids = self.r.lrange(self.JOB_LIST, 0, limit - 1)
        jobs = []
        for job_id in ids:
            j = self.get_job(job_id)
            if j:
                jobs.append(j)
        return jobs

    def update_job(self, job_id: str, updates: dict):
        job = self.get_job(job_id)
        if not job:
            return None
        job.update(updates)
        self.r.set(self.JOB_PREFIX + job_id, json.dumps(job))
        return job

    def delete_job(self, job_id: str) -> bool:
        j = self.get_job(job_id)
        if not j:
            return False
        # Only allow deletion of completed/failed/cancelled
        if j.get("status") in ("queued", "running", "paused"):
            return False
        self.r.delete(self.JOB_PREFIX + job_id)
        self.r.lrem(self.JOB_LIST, 0, job_id)
        return True

    # ── EXECUTION ──
    def execute(self, job_id: str, task_id: str = None) -> dict:
        """Execute a restore job — called from Celery task."""
        from app.tenant_manager import TenantManager
        from app.restore import get_restore

        job = self.get_job(job_id)
        if not job:
            return {"error": "Job not found"}

        # Mark started
        self.update_job(job_id, {
            "status": "running",
            "started_at": datetime.now(timezone.utc).isoformat(),
            "task_id": task_id,
        })

        # Load tenant
        tm = TenantManager()
        tenant = tm.get_tenant(job["tenant_id"], include_secret=True)
        if not tenant:
            self.update_job(job_id, {
                "status": "failed",
                "error": f"Tenant not found: {job['tenant_id']}",
                "completed_at": datetime.now(timezone.utc).isoformat(),
            })
            return {"error": "Tenant not found"}

        # Progress callback
        def progress_cb(evt, data):
            # Compute progress from targets_processed / total (rough)
            targets_done = data.get("targets_processed", 0) + data.get("targets_failed", 0)
            items_done = data.get("items_processed", 0) + data.get("items_failed", 0)
            
            # For simplicity: use items count as progress (0-100 scale)
            # If we know target count, use it; else estimate
            progress = min(99, int(items_done / max(items_done + 10, 100) * 100)) if items_done else 5
            
            self.update_job(job_id, {
                "progress": progress,
                "current_target": data.get("target_name", ""),
                "items_processed": data.get("items_processed", 0),
                "items_failed": data.get("items_failed", 0),
                "bytes_uploaded": data.get("bytes_uploaded", 0),
            })
            log.info(f"[restore {job_id[:8]}] {evt}: {data.get('target_name', '')[:40]}")

        # Build restore instance
        try:
            kwargs = {"mode": job["mode"]}
            if job["workload"] == "sharepoint":
                kwargs["target_site_id"] = job.get("target_site_id")
                kwargs["target_site_path"] = job.get("target_site_path")
            elif job["workload"] == "onedrive":
                kwargs["user_mapping"] = job.get("user_mapping", {})
                kwargs["target_folder"] = job.get("target_folder", "Restored")
            elif job["workload"] == "outlook":
                kwargs["user_mapping"] = job.get("user_mapping", {})
                kwargs["restore_items"] = job.get("restore_items",
                                                  ["messages", "calendar", "contacts"])

            restorer = get_restore(
                workload=job["workload"],
                tenant=tenant,
                backup_path=job["backup_path"],
                progress_callback=progress_cb,
                task_id=task_id,
                **kwargs,
            )

            # Execute
            result = restorer.restore()

            # Mark complete
            status = "completed"
            if result.get("cancelled"):
                status = "cancelled"
            elif result.get("targets_failed", 0) > 0 and result.get("targets_processed", 0) == 0:
                status = "failed"

            self.update_job(job_id, {
                "status": status,
                "progress": 100,
                "completed_at": datetime.now(timezone.utc).isoformat(),
                "result": result,
            })

            log.info(f"Restore job {job_id[:8]} {status}")
            return result

        except Exception as e:
            log.error(f"Restore job {job_id[:8]} failed: {e}", exc_info=True)
            self.update_job(job_id, {
                "status": "failed",
                "error": str(e),
                "completed_at": datetime.now(timezone.utc).isoformat(),
            })
            return {"error": str(e)}

    # ── DRY RUN ──
    def dry_run(self, config: dict) -> dict:
        """Preview a restore without executing."""
        from app.tenant_manager import TenantManager
        from app.restore import get_restore

        tm = TenantManager()
        tenant = tm.get_tenant(config["tenant_id"], include_secret=True)
        if not tenant:
            return {"error": "Tenant not found"}

        kwargs = {}
        if config["workload"] == "sharepoint":
            kwargs["target_site_id"] = config.get("target_site_id")
            kwargs["target_site_path"] = config.get("target_site_path")

        try:
            restorer = get_restore(
                workload=config["workload"],
                tenant=tenant,
                backup_path=config["backup_path"],
                mode=config.get("mode", "merge"),
                **kwargs,
            )
            return restorer.dry_run()
        except Exception as e:
            return {"error": str(e)}
