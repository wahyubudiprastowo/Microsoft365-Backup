# 📡 API Reference — v13 Restore Endpoints

Base URL: `http://<zima-ip>:5055`

All endpoints return JSON. Errors return HTTP 4xx/5xx with `{"error": "..."}`.

---

## POST /api/v2/restore/jobs

Create and queue a restore job.

### Request Body

**Common fields (all workloads):**
```json
{
  "tenant_id": "uuid-tenant-id",
  "tenant_name": "Digiserve by Telkom",
  "workload": "sharepoint|onedrive|outlook",
  "backup_path": "/backup/m365/digiserve-by-telkom/sharepoint/backup_20260628_020000",
  "source_backup": "backup_20260628_020000",
  "mode": "overwrite|merge|new_location"
}
```

**Additional fields — SharePoint:**
```json
{
  "target_site_path": "sites/RestoreArea",
  "target_site_id": "host,uuid,uuid"  // OR use path
}
```

**Additional fields — OneDrive:**
```json
{
  "user_mapping": {
    "user1@digiserve.co.id": "manager@digiserve.co.id"
  },
  "target_folder": "M365 Restored"     // For new_location mode
}
```

**Additional fields — Outlook:**
```json
{
  "user_mapping": {"old@x.com": "new@x.com"},
  "restore_items": ["messages", "calendar", "contacts"]
}
```

### Responses

**201 Created:**
```json
{
  "status": "created",
  "job": {
    "id": "abc-123-uuid",
    "status": "queued",
    "progress": 0,
    "created_at": "2026-07-08T14:30:00Z"
  }
}
```

**400 Bad Request:**
```json
{
  "error": "Missing required field: workload"
}
```

**500 Server Error:**
```json
{
  "error": "Redis connection failed"
}
```

### cURL Example
```bash
curl -X POST http://localhost:5055/api/v2/restore/jobs \
  -H "Content-Type: application/json" \
  -d '{
    "tenant_id": "089a...",
    "tenant_name": "Digiserve",
    "workload": "onedrive",
    "backup_path": "/backup/m365/digiserve-by-telkom/onedrive/backup_20260628_020000",
    "source_backup": "backup_20260628_020000",
    "mode": "merge",
    "user_mapping": {"user1@digiserve.co.id": "manager@digiserve.co.id"}
  }'
```

---

## GET /api/v2/restore/jobs

List all restore jobs (newest first).

### Query Parameters
- `limit`: number (default 50, max 100)

### Response
```json
{
  "jobs": [
    {
      "id": "uuid",
      "tenant_id": "uuid",
      "tenant_name": "Digiserve by Telkom",
      "workload": "sharepoint",
      "source_backup": "backup_20260628_020000",
      "mode": "merge",
      "status": "running",
      "progress": 45,
      "current_target": "BIRA_TEAM",
      "items_processed": 142,
      "items_failed": 0,
      "bytes_uploaded": 15728640,
      "created_at": "2026-07-08T14:30:00Z",
      "started_at": "2026-07-08T14:30:15Z",
      "completed_at": null,
      "result": null,
      "error": null
    }
  ]
}
```

### cURL Example
```bash
curl http://localhost:5055/api/v2/restore/jobs?limit=20
```

---

## GET /api/v2/restore/jobs/<job_id>

Get single job details.

### Response
Same object as one item in the `jobs` array above.

### 404 Not Found
```json
{"error": "Job not found"}
```

---

## POST /api/v2/restore/jobs/<job_id>/cancel

Cancel a running/queued job.

### Response
```json
{"status": "cancelled"}
```

### Behavior
1. Set Redis flag `m365:task:{task_id}:control` = `cancelled`
2. Send SIGTERM to Celery worker via `celery_app.control.revoke()`
3. Worker's `check_control()` raises `PauseException`, propagates up
4. Job marked as `status=cancelled`

---

## DELETE /api/v2/restore/jobs/<job_id>

Delete job from history.

### Constraints
- Only completed / failed / cancelled jobs can be deleted
- Active jobs (queued/running/paused) return 409 Conflict

### Response 200
```json
{"status": "deleted"}
```

### Response 409
```json
{"error": "Cannot delete active job"}
```

---

## POST /api/v2/restore/preview

Dry-run — analyze backup without executing.

### Request
Same body as `POST /api/v2/restore/jobs`.

### Response — SharePoint
```json
{
  "workload": "sharepoint",
  "files_to_upload": 247,
  "total_size_bytes": 5242880,
  "files_that_would_skip": 12
}
```

### Response — OneDrive
```json
{
  "workload": "onedrive",
  "users_in_backup": 15,
  "files_to_upload": 320,
  "total_size_bytes": 104857600
}
```

### Response — Outlook
```json
{
  "workload": "outlook",
  "users_in_backup": 15,
  "messages_to_restore": 3200,
  "events_to_restore": 128,
  "contacts_to_restore": 45
}
```

---

## Related Endpoints (from v11-v12)

- `GET /api/tenants` — List tenants
- `GET /api/v2/backups?tenant_slug=X&workload=Y` — List backups for a tenant+workload
- `POST /api/v2/backup/start` — Start a new backup
- `GET /api/v2/tenants/<id>/schedule` — Per-tenant schedule (v12)
