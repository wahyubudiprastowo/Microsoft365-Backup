# 🛠️ Troubleshooting Guide — v13

## Common Issues

### 1. "No backups found for this workload"

**Symptom:** When selecting a workload in `/restore-v2`, the backup dropdown is empty.

**Causes:**
- No backup exists for this workload yet
- Tenant slug mismatch (backup folder name vs tenant.name.slugify())

**Solutions:**
1. Verify backup exists:
   ```bash
   ls /media/Storage/Container/M365/data/
   ```
2. Check tenant slug:
   ```bash
   docker exec m365-backup-web python3 -c "
   from app.workloads.base import slugify
   print(slugify('Digiserve by Telkom'))  # should be 'digiserve-by-telkom'
   "
   ```
3. Ensure backup folder matches: `/backup/m365/<slug>/<workload>/backup_XXX/`

---

### 2. Restore Job Stuck in "running" Forever

**Symptom:** Job shows "running" status but no progress after 30+ minutes.

**Causes:**
- Celery worker crashed
- Graph API hitting rate limits (throttled)
- Very large files being uploaded

**Solutions:**
1. Check worker logs:
   ```bash
   docker logs m365-backup-worker --tail 100
   ```
2. Look for rate limit warnings — this is normal, engine will retry
3. If truly stuck, cancel via UI and restart:
   ```bash
   docker compose restart worker
   ```
4. Manually reset job status:
   ```bash
   docker exec m365-backup-redis redis-cli -n 2 KEYS "m365:restore_job:*"
   # Find the stuck job, then:
   docker exec m365-backup-redis redis-cli -n 2 DEL "m365:restore_job:<uuid>"
   ```

---

### 3. Error: "Auth failed: AADSTS7000215"

**Symptom:** Job fails immediately with "Invalid client secret provided".

**Causes:**
- Client secret in tenant config is wrong or expired
- Secret was rotated in Azure but not updated in the app

**Solutions:**
1. Verify secret in Azure Portal (App Registrations → your app → Certificates & secrets)
2. Update tenant config in the app:
   - Go to `/tenants` page
   - Edit tenant, paste new secret
   - Click "Test Connection" to verify

---

### 4. Error: "Insufficient privileges to complete the operation"

**Symptom:** SharePoint/OneDrive/Outlook restore returns HTTP 403.

**Causes:**
- App Registration missing required Graph permissions
- Permissions added but admin consent not granted

**Solutions:**
1. Go to Azure Portal → App Registrations → your app → API permissions
2. For restore, you need APPLICATION permissions:
   - SharePoint: `Sites.ReadWrite.All`, `Files.ReadWrite.All`
   - OneDrive: `Files.ReadWrite.All`, `User.Read.All`
   - Outlook: `Mail.ReadWrite`, `Calendars.ReadWrite`, `Contacts.ReadWrite`
3. Click **"Grant admin consent"**
4. Wait 5-10 minutes for propagation
5. Try again

---

### 5. Outlook Restore: "Failed to create folder 'M365 Restored'"

**Symptom:** Outlook restore fails to create the restore folder in mailbox.

**Causes:**
- Insufficient permissions (`MailboxSettings.ReadWrite`)
- User has no mailbox (unlicensed)
- Folder name conflict (case sensitivity)

**Solutions:**
1. Verify user has Exchange Online license
2. Check Graph permissions include `MailboxSettings.ReadWrite`
3. Manually delete existing "M365 Restored" folder in Outlook, then retry

---

### 6. OneDrive Restore: "OneDrive not provisioned"

**Symptom:** OneDrive restore fails with "OneDrive not provisioned for user@..."

**Cause:** User has never accessed OneDrive, so it's not initialized.

**Solutions:**
1. Ask user to log into `https://onedrive.com` at least once
2. OR use Graph API to provision:
   ```bash
   POST /users/{userId}/drive
   ```
3. Then retry restore

---

### 7. Large File Upload Fails Halfway

**Symptom:** File > 100 MB fails during upload session with network error.

**Causes:**
- Network instability
- ZimaOS to Graph API network hiccup

**Solutions:**
1. Retry restore — engine will resume upload session where it left off
2. Check ZimaOS network:
   ```bash
   ping -c 5 graph.microsoft.com
   ```
3. Verify DNS is configured:
   ```bash
   cat /etc/resolv.conf
   # Should contain nameserver 8.8.8.8 or similar
   ```

---

### 8. Restore Job Count Not Matching Backup

**Symptom:** Backup shows 100 items but restore only shows 87 processed.

**Causes:**
- Some items skipped (merge mode + already exists)
- Some items failed silently
- Corrupted backup file

**Solutions:**
1. Check job result for details:
   ```bash
   curl http://localhost:5055/api/v2/restore/jobs/<job_id> | python3 -m json.tool
   ```
2. Look at `items_skipped` and `items_failed` counts
3. Check `errors[]` array for specific failure reasons
4. Review worker logs for detailed traceback

---

### 9. UI Not Refreshing Job Status

**Symptom:** Jobs stay showing "queued" even after Celery started them.

**Causes:**
- JavaScript polling stopped (browser tab was inactive)
- Redis connection lost

**Solutions:**
1. Refresh page (F5)
2. Check browser console for JS errors
3. Verify Redis is accessible:
   ```bash
   docker exec m365-backup-web redis-cli -h redis ping
   # Should return PONG
   ```

---

### 10. "Tenant not found" Error

**Symptom:** Restore job fails immediately with "Tenant not found: <uuid>".

**Causes:**
- Tenant was deleted from config
- Config file was manually edited and UUID changed

**Solutions:**
1. Check current tenants:
   ```bash
   curl http://localhost:5055/api/tenants
   ```
2. If tenant missing, re-add via `/tenants` page
3. The restore job needs to be recreated with correct tenant_id

---

## Debug Mode

### Enable Verbose Logging

Edit `docker-compose.yml`, add to worker service:
```yaml
environment:
  - LOG_LEVEL=DEBUG
```

Rebuild and restart:
```bash
docker compose up -d --build worker
```

### Inspect Redis State
```bash
# List all restore jobs
docker exec m365-backup-redis redis-cli -n 2 KEYS "m365:restore_job:*"

# Get specific job
docker exec m365-backup-redis redis-cli -n 2 GET "m365:restore_job:<uuid>"

# Delete stuck job
docker exec m365-backup-redis redis-cli -n 2 DEL "m365:restore_job:<uuid>"
docker exec m365-backup-redis redis-cli -n 2 LREM "m365:restore_jobs:list" 0 "<uuid>"
```

### Test Graph API Manually

```bash
docker exec m365-backup-web python3 << 'EOF'
from app.tenant_manager import TenantManager
from app.restore.base import BaseRestore

tm = TenantManager()
tenant = tm.get_active_tenant()

# Test auth
class TestRestore(BaseRestore):
    pass

t = TestRestore(tenant, backup_path="/tmp")
try:
    token = t.get_token()
    print(f"✅ Token OK ({len(token)} chars)")
except Exception as e:
    print(f"❌ Auth failed: {e}")
EOF
```

---

## Log Locations

- **App logs:** `/media/Storage/Container/M365/logs/m365_backup.log`
- **Celery worker logs:** `docker logs m365-backup-worker`
- **Web logs:** `docker logs m365-backup-web`
- **Scheduler logs:** `docker logs m365-backup-scheduler`
- **Redis logs:** `docker logs m365-backup-redis`

---

## Getting Help

If stuck:
1. Collect logs from all containers
2. Note the exact error message
3. Note steps to reproduce
4. Check GitHub issues (or Wahyu's project repo)
5. Include this info when asking for help:
   - v13 patch applied? Yes/No
   - v10, v11, v12 applied? Yes/No
   - Tenant config valid? (Test Connection passes?)
   - Backup exists? Path?
   - Graph permissions granted with admin consent?
