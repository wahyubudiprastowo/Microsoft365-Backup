# 🧪 Testing Checklist — v13

## Prerequisites
- v10, v11, v12 patches applied and running
- At least 1 tenant configured with valid Graph API credentials
- Test SharePoint site created (e.g., `sites/TestRestore`)
- Test user accounts with OneDrive + Outlook
- At least 1 backup already exists (from prior backup runs)

---

## ✅ Pre-Deployment Tests

### T-01: Container Health
```bash
cd /media/Storage/Container/M365
DOCKER_CONFIG=/media/Storage/Container/M365/.docker docker compose ps
```
- [ ] All 4 containers "Up" and healthy: web, redis, worker, scheduler

### T-02: Web UI Loads
- [ ] Open `http://<zima-ip>:5055/restore-v2` in browser
- [ ] Page loads without errors (check browser console)
- [ ] All 3 workload buttons visible
- [ ] Tenant dropdown populated

### T-03: API Ping
```bash
curl -s http://localhost:5055/api/v2/restore/jobs | head -c 200
```
- [ ] Returns `{"jobs": [...]}` or empty `{"jobs": []}`

---

## 🎯 Functional Tests

### F-01: SharePoint Restore — Merge (Same Site)
**Setup:**
- Backup exists: `/backup/m365/digiserve-by-telkom/sharepoint/backup_XXX/`
- Contains folder `BIRA_TEAM/Documents/file1.docx`

**Steps:**
1. Go to `/restore-v2`
2. Select tenant "Digiserve by Telkom"
3. Click workload "SharePoint"
4. Select backup from dropdown
5. Keep mode = **Merge**
6. Leave "Target Site Path" empty
7. Click **Preview**
   - [ ] Shows `files_to_upload: <number>`
8. Click **Start Restore**
9. Confirm dialog

**Expected:**
- [ ] Job appears in queue with status "queued" → "running"
- [ ] Progress bar increments
- [ ] Job status changes to "completed"
- [ ] Verify in SharePoint: files exist in BIRA_TEAM/Documents

### F-02: SharePoint Restore — New Location
**Setup:** Same as F-01

**Steps:**
1. Same as F-01, but set mode = **New Location**
2. Set "Target Site Path" = `sites/TestRestore`
3. Click **Start Restore**

**Expected:**
- [ ] Files uploaded to `sites/TestRestore/Documents/...`
- [ ] Original site unchanged

### F-03: OneDrive Restore — Same User (Merge)
**Setup:**
- Backup exists for `user1@digiserve.co.id`
- User1 currently has some files in OneDrive

**Steps:**
1. Select tenant, workload "OneDrive"
2. Select backup
3. Mode = Merge
4. Leave user_mapping empty
5. Preview → verify counts
6. Start Restore

**Expected:**
- [ ] Files uploaded to user1's OneDrive root
- [ ] Existing files skipped (check `items_skipped` in result)

### F-04: OneDrive Restore — User Mapping
**Setup:** Backup for `user1@digiserve.co.id`

**Steps:**
1. Select OneDrive workload
2. Set user_mapping:
   ```json
   {"user1@digiserve.co.id": "manager@digiserve.co.id"}
   ```
3. Start Restore

**Expected:**
- [ ] Files appear in manager's OneDrive
- [ ] user1's OneDrive unchanged

### F-05: OneDrive Restore — New Location Folder
**Setup:** Same as F-04

**Steps:**
1. Mode = **New Location**
2. Target folder = `Legal_Hold/2026-Q2`
3. Start Restore

**Expected:**
- [ ] Folder `Legal_Hold/2026-Q2/` created in target OneDrive
- [ ] All files inside that folder

### F-06: Outlook Restore — Messages Only
**Setup:** Backup for user1 with messages.json

**Steps:**
1. Select Outlook workload
2. Check only "Messages"
3. Mode = Merge
4. Preview → shows `messages_to_restore: N`
5. Start Restore

**Expected:**
- [ ] User1's mailbox has new folder "M365 Restored"
- [ ] Messages present in that folder
- [ ] Calendar/Contacts unchanged

### F-07: Outlook Restore — Full Mailbox
**Setup:** Backup with messages + calendar + contacts

**Steps:**
1. Outlook workload
2. Check all 3 items
3. Start Restore

**Expected:**
- [ ] Messages in "M365 Restored" folder
- [ ] Events in user's default calendar
- [ ] Contacts in default contacts folder

### F-08: Dry Run Accuracy
**Steps:**
1. Prepare a backup with **known** counts (e.g., manually count files)
2. Run dry-run preview
3. Compare shown counts vs actual

**Expected:**
- [ ] Preview counts match actual backup contents (±1)
- [ ] Preview does NOT modify M365 data

### F-09: Cancel Running Job
**Setup:** Large backup (100+ files)

**Steps:**
1. Start SharePoint restore
2. Wait until progress ~20-30%
3. Click **Cancel** on job card

**Expected:**
- [ ] Job status changes to "cancelled" within ~5 seconds
- [ ] No further files uploaded (verify by watching Graph traffic or file timestamps)
- [ ] Partially uploaded files remain (not rolled back)

### F-10: Delete Completed Job
**Steps:**
1. After a completed job appears
2. Click **Delete** button

**Expected:**
- [ ] Job removed from list
- [ ] Cannot delete active jobs (button hidden or 409 error)

---

## 🔒 Security Tests

### S-01: Invalid Tenant ID
```bash
curl -X POST http://localhost:5055/api/v2/restore/jobs \
  -H "Content-Type: application/json" \
  -d '{"tenant_id": "nonexistent", "workload": "sharepoint", "backup_path": "/x", "source_backup": "x"}'
```
- [ ] Returns error (Tenant not found)
- [ ] Job marked as "failed" in list

### S-02: Missing Required Field
```bash
curl -X POST http://localhost:5055/api/v2/restore/jobs \
  -d '{}'
```
- [ ] Returns 400 with error message

### S-03: Invalid Mode
- [ ] Mode `foobar` rejected with 400

### S-04: Confirmation Dialog
- [ ] Clicking "Start Restore" WITHOUT confirming does not create job

---

## ⚡ Performance Tests

### P-01: Single File SharePoint Restore
- [ ] < 5 seconds for a 100 KB file (small)
- [ ] < 30 seconds for a 5 MB file (medium)

### P-02: OneDrive 100-file Restore
- [ ] Completes in < 15 minutes for 100 files ~500 MB total

### P-03: Outlook 1000 Messages Restore
- [ ] Completes in < 20 minutes

### P-04: Concurrent Restores
1. Start 2 different restore jobs simultaneously
- [ ] Both run in parallel (Celery concurrency=2)
- [ ] No deadlock

### P-05: UI Refresh Rate
- [ ] Jobs queue updates every ~4 seconds
- [ ] No noticeable UI lag

---

## 🔄 Regression Tests

### R-01: v10 Backup Still Works
- [ ] Click "Run Backup" on Dashboard
- [ ] Backup completes and appears in backup list

### R-02: v11 Tenant-Aware Structure Preserved
- [ ] Backups still saved to `/backup/m365/{slug}/{workload}/`

### R-03: v12 Per-Tenant Schedule Works
- [ ] Open `/schedules` → tenant schedules display correctly
- [ ] Save schedule works
- [ ] Beat picks up new schedule (after restart)

### R-04: v10 Restore Still Available (Non-broken)
- [ ] Open `/restore` (old page) → still loads
- [ ] Doesn't conflict with new `/restore-v2`

---

## 🚨 Error Handling Tests

### E-01: Backup Path Doesn't Exist
- [ ] Submit job with `backup_path: "/nonexistent"`
- [ ] Job fails gracefully with error message

### E-02: Graph API Rate Limit Simulated
- [ ] Force many rapid requests
- [ ] Engine sleeps and retries (no crash)

### E-03: Insufficient Graph Permissions
- [ ] Restore Outlook without `Mail.ReadWrite`
- [ ] Job fails with clear "permission" error

### E-04: Corrupted Backup File
- [ ] Manually corrupt `messages.json`
- [ ] Restore continues with other items, logs error for corrupted file

---

## ✅ Sign-Off Checklist

- [ ] All functional tests (F-01 to F-10) pass
- [ ] All security tests (S-01 to S-04) pass
- [ ] Performance targets met (P-01 to P-05)
- [ ] Regressions checked (R-01 to R-04)
- [ ] Error handling verified (E-01 to E-04)
- [ ] Documentation reviewed (README, PRD, API docs)
- [ ] Rollback plan tested
- [ ] Monitoring in place (logs, notifications)

**Ready for production: [ ] Yes  [ ] No**

Signed off by: ___________  Date: ___________
