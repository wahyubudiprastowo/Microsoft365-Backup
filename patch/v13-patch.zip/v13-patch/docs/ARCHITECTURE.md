# 🏗️ Architecture Document — v13

## Component Diagram

```
                        ┌────────────────────────────────┐
                        │   ZimaOS Host                  │
                        │  /media/Storage/Container/M365 │
                        └────────────────────────────────┘
                                     │
        ┌────────────────────────────┼────────────────────────────┐
        │                            │                            │
        ↓                            ↓                            ↓
┌───────────────┐          ┌───────────────┐          ┌───────────────┐
│  m365-web     │          │  m365-worker  │          │ m365-scheduler│
│  (Gunicorn)   │──Redis──▶│   (Celery)    │◀─Redis──│(celery beat)  │
│  Flask app    │          │  concurrency=2│          │               │
└───────────────┘          └───────────────┘          └───────────────┘
        │                          │                           │
        └──────────┬───────────────┴───────────────┬──────────┘
                   ↓                               ↓
             ┌───────────┐                 ┌────────────────┐
             │   Redis   │                 │ Graph API      │
             │  db=0 broker              │ (per-tenant)    │
             │  db=1 result             │                 │
             │  db=2 jobs/state         │                 │
             └───────────┘                 └────────────────┘

Volume mounts (persistent):
  /media/Storage/Container/M365/data    → /backup/m365   (backups)
  /media/Storage/Container/M365/config  → /app/data      (config.json)
  /media/Storage/Container/M365/logs    → /app/logs      (log rotation)
```

## Restore Engine Architecture (v13)

### Class Hierarchy
```
BaseRestore (abstract)
    │
    ├── SharePointRestore    (workload="sharepoint")
    ├── OneDriveRestore      (workload="onedrive")
    └── OutlookRestore       (workload="outlook")
```

### Factory Pattern
```python
from app.restore import get_restore

restorer = get_restore(
    workload="onedrive",              # dispatches to OneDriveRestore
    tenant=tenant_dict,               # required
    backup_path="/backup/m365/...",   # required
    mode="merge",                     # overwrite/merge/new_location
    user_mapping={},                  # OneDrive/Outlook-specific
    target_folder="Restored",         # OneDrive-specific
    restore_items=["messages"],       # Outlook-specific
)
result = restorer.restore()
```

### State Machine — Restore Job
```
       [Create]
          │
          ↓
      ┌───────┐    execute()    ┌────────┐
      │queued ├────────────────▶│running │
      └───────┘                 └───┬────┘
                                    │
                       ┌────────────┼────────────┬─────────┐
                       ↓            ↓            ↓         ↓
                  ┌────────┐  ┌──────────┐ ┌──────┐  ┌────────┐
                  │completed│  │ failed  │ │paused│  │cancel  │
                  └────────┘  └──────────┘ └──┬───┘  └────────┘
                                             │
                                             ↓ (future)
                                          ┌──────┐
                                          │resume│
                                          └──────┘
```

## Data Structures

### Restore Job (Redis)
Key: `m365:restore_job:{uuid}`
```json
{
  "id": "uuid-v4",
  "tenant_id": "tenant-uuid",
  "tenant_name": "Digiserve by Telkom",
  "workload": "sharepoint|onedrive|outlook",
  "backup_path": "/backup/m365/.../backup_...",
  "source_backup": "backup_20260628_020000",
  "mode": "overwrite|merge|new_location",
  "status": "queued|running|paused|completed|failed|cancelled",
  "progress": 0-100,
  "created_at": "ISO 8601",
  "started_at": "ISO 8601 or null",
  "completed_at": "ISO 8601 or null",
  "current_target": "target being processed",
  "items_processed": 0,
  "items_failed": 0,
  "bytes_uploaded": 0,
  "task_id": "celery-task-uuid",
  "result": { /* full stats dict */ },
  "error": "error string or null",
  
  // Workload-specific fields:
  "target_site_id": "...",        // SharePoint
  "target_site_path": "sites/X",  // SharePoint
  "user_mapping": {},             // OneDrive/Outlook
  "target_folder": "Restored",    // OneDrive
  "restore_items": [...]          // Outlook
}
```

### Backup Folder Structure (from v11)
```
/backup/m365/
├── digiserve-by-telkom/          # tenant slug
│   ├── sharepoint/
│   │   └── backup_20260628_020000/
│   │       ├── BIRA_TEAM/
│   │       │   ├── Documents/
│   │       │   │   └── files...
│   │       │   └── _site_metadata.json
│   │       └── _workload_manifest.json
│   ├── onedrive/
│   │   └── backup_20260628_020000/
│   │       ├── user1_at_digiserve.co.id/
│   │       │   ├── files...
│   │       │   └── _user_metadata.json
│   │       └── _workload_manifest.json
│   └── outlook/
│       └── backup_20260628_020000/
│           ├── user1_at_digiserve.co.id/
│           │   ├── messages.json
│           │   ├── calendar.json
│           │   ├── contacts.json
│           │   └── _mailbox_metadata.json
│           └── _workload_manifest.json
```

## Sequence Diagrams

### Restore SharePoint (Merge Mode)
```
User        UI                Flask           Redis         Celery         Graph API
 │           │                  │              │              │              │
 ├─Submit──▶│                  │              │              │              │
 │           ├─POST /jobs─────▶│              │              │              │
 │           │                  ├─create job──▶│              │              │
 │           │                  ├─enqueue task────────────────▶              │
 │           │◀─201 created─────┤              │              │              │
 │           │                  │              │              ├─mark running │
 │           │                  │              │              ├─get target site─▶
 │           │                  │              │              │◀─site info───┤
 │           │                  │              │              │              │
 │           │                  │              │              ├─get drives──▶│
 │           │                  │              │              │◀─drives──────┤
 │           │                  │              │              │              │
 │           │                  │              │              │─── per file ─┤
 │           │                  │              │              │  check exist│
 │           │                  │              │              │  upload────▶│
 │           │                  │              ├─progress────┤              │
 │           │◀─poll /jobs──────┤◀─────────────┤              │              │
 │           │                  │              │              │              │
 │           │                  │              │              ├─mark done   │
 │           │◀─status=done─────┤              │              │              │
```

### Cancel Running Job
```
User        UI          Flask       Redis       Celery worker
 │           │            │           │              │
 ├─Cancel──▶│            │           │              │
 │           ├─POST cancel─▶          │              │
 │           │            ├─set control:cancelled─▶ │
 │           │            ├─revoke task────────────▶│
 │           │            │           │              │─ IN LOOP:
 │           │            │           │              │   check_control()
 │           │            │           │              │   → PauseException
 │           │            │           │              │
 │           │            │           │              ├─mark cancelled
 │           │            │           │              │
```

## Performance Considerations

### Upload Strategies
| File Size | Strategy | Reason |
|-----------|---------|--------|
| < 4 MB | Simple `PUT /content` | Fast, single request |
| 4 MB - 250 MB | Upload session, 5 MB chunks | Chunked, can resume |
| > 250 MB | Same as above, longer timeout | Graph limit ~250 MB per file |

### Rate Limiting
- Graph API: **10,000 requests / 10 minutes** per app
- On HTTP 429: sleep for `Retry-After` seconds
- Exponential backoff on transient errors (2^attempt)

### Optimizations
- Token caching (55min TTL)
- Session reuse (`requests.Session`)
- Batch listing before upload
- Skip existing files early (merge mode) to avoid uploads

## Failure Modes & Recovery

| Failure | Detection | Recovery |
|---------|-----------|----------|
| Graph rate limit (429) | HTTP status | Automatic retry with backoff |
| Token expired | HTTP 401 | Refresh token, retry |
| Network timeout | requests.Timeout | Retry 3x with backoff |
| File locked on target | HTTP 423 | Log error, continue with next file |
| User not found | HTTP 404 | Skip user, log error |
| Corrupted backup file | JSON decode error | Skip, log error, continue |
| Container crash mid-job | Celery restarts | Job stuck in "running"; needs manual reset |

## Extension Points

To add a new workload restore (e.g., Teams):

1. Create `app/restore/teams.py` extending `BaseRestore`
2. Implement `restore()` and `dry_run()` methods
3. Register in `app/restore/__init__.py`:
   ```python
   from .teams import TeamsRestore
   RESTORE_REGISTRY["teams"] = TeamsRestore
   ```
4. Add UI option in `restore_v2.html` (workload picker button)
5. Add workload-specific form fields
