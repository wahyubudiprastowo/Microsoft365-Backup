# 📋 PRD — M365 Backup v13: Full Multi-Workload Restore

**Product Owner:** Wahyu Budi Prastowo (IT Infrastructure Specialist)  
**Version:** 13.0  
**Status:** Ready for Production  
**Release Date:** July 2026

---

## 1. Executive Summary

### 1.1 Problem Statement
Sistem backup M365 Multi-tenant (v10-v12) sudah bisa **BACKUP** SharePoint,
OneDrive, dan Outlook, tapi restore-nya masih **terbatas ke SharePoint saja**.
Ketika terjadi data loss (accidental delete, ransomware, user request rollback),
admin tidak bisa restore OneDrive files atau Outlook mailbox items dari backup.

### 1.2 Goal
Implementasi restore engine yang **komprehensif untuk semua 3 workload**:
- SharePoint Online (enhanced dari v10)
- OneDrive for Business (NEW)
- Outlook / Exchange Online (NEW — messages, calendar, contacts)

Dengan **UI yang seragam**, **job queue tracking**, **dry-run preview**, dan
**mode-based restore** (overwrite / merge / new_location).

### 1.3 Success Metrics
| Metric | Target |
|--------|--------|
| Restore SharePoint file (single) | ≤ 30 detik |
| Restore OneDrive user (100 files, ~500 MB) | ≤ 15 menit |
| Restore Outlook mailbox (1000 messages) | ≤ 20 menit |
| Restore accuracy (item content preserved) | 100% |
| Dry-run preview response time | ≤ 3 detik |
| UI responsiveness (job status refresh) | ≤ 4 detik |
| Concurrent restore jobs supported | 2 (Celery concurrency=2) |

---

## 2. User Personas

### 2.1 Wahyu — IT Infrastructure Admin (Primary)
- **Role:** Manage M365 for Digiserve
- **Pain Points:**
  - CEO's OneDrive corrupted → butuh restore semua file, tapi ke user baru
  - Ex-employee mailbox archive → butuh restore ke shared mailbox
  - Legal request → butuh restore email dari tanggal tertentu
- **Needs:** Fast restore, preview before commit, granular control

### 2.2 Junior IT Ops (Secondary)
- **Role:** Handle daily support tickets
- **Pain Points:**
  - User accidentally deleted files from Documents library → butuh restore cepat
  - Tidak familiar dengan Graph API
- **Needs:** Simple UI, safe defaults (merge mode), clear feedback

### 2.3 Compliance Officer (Future)
- **Role:** Retention & legal hold
- **Needs:** Audit trail, dry-run before commit, point-in-time restore

---

## 3. Feature Scope (v13)

### 3.1 IN Scope ✅

#### **F1: SharePoint Restore (Enhanced)**
- Restore from any backup folder (tenant-aware structure)
- Modes: `overwrite`, `merge`, `new_location`
- Target: same site OR different site path
- Large file support (upload session, chunked)
- Site auto-mapping (backup folder name → target site)

#### **F2: OneDrive Restore (NEW)**
- Restore per-user OneDrive from backup
- User mapping (restore User A's OneDrive to User B's OneDrive)
- Optional target folder (e.g., all files go to `/M365 Restored/`)
- Modes: `overwrite`, `merge`, `new_location`
- Skip files that already exist (merge)

#### **F3: Outlook Restore (NEW)**
- **Messages:** Restore into "M365 Restored" mail folder
- **Calendar Events:** Restore into user's default calendar
- **Contacts:** Restore into user's default contacts folder
- Deduplication by `internetMessageId` (messages) / `iCalUId` (events) / email addr (contacts)
- Selective restore (choose which item types)
- User mapping support

#### **F4: Job Queue & Tracking**
- Persistent restore jobs in Redis
- Status states: queued, running, paused, completed, failed, cancelled
- Progress percentage (0-100)
- Real-time UI refresh (4s polling)
- Cancel active job
- Delete completed job

#### **F5: Dry-Run Preview**
- Preview WITHOUT executing
- Counts items that would be uploaded/skipped
- Total size for file-based workloads
- User count for mailbox workloads

#### **F6: Unified UI (`/restore-v2`)**
- Single page for all 3 workloads
- Workload switcher (buttons)
- Backup source dropdown (filtered by workload + tenant)
- Mode selector (visual buttons with hints)
- Workload-specific fields hidden/shown dynamically
- Split layout: Form (left) + Jobs Queue (right)

### 3.2 OUT of Scope ❌ (Future Versions)

- **Point-in-time restore** — Restore specific date range (v14?)
- **Item-level cherry pick** — Choose specific messages/files (v14?)
- **Pause/Resume mid-job** — Currently only cancel supported (v14)
- **Restore to different tenant** — Cross-tenant restore (v15?)
- **Teams Chat restore** — Teams workload not backed up yet (v14)
- **Restore verification** — Post-restore integrity check (v15?)
- **Restore report export** — PDF/CSV report (v15?)
- **Multi-region deployment** — Assume single-region for now
- **Encryption at-rest** — Backups stored as-is (v16?)

---

## 4. Technical Architecture

### 4.1 High-Level Diagram
```
┌────────────────────────────────────────────────────────────────┐
│                     Web UI (/restore-v2)                        │
│         Job form + workload selector + Jobs queue table         │
└─────────────────────────┬──────────────────────────────────────┘
                          │ REST API v2
                          ↓
┌────────────────────────────────────────────────────────────────┐
│                Flask Blueprint (main_routes_v13.py)             │
│      POST /api/v2/restore/jobs   → Create + queue Celery task   │
│      GET  /api/v2/restore/jobs   → List job status              │
│      POST /api/v2/restore/preview → Dry-run                     │
└─────────────────────────┬──────────────────────────────────────┘
                          │
                          ↓
┌────────────────────────────────────────────────────────────────┐
│           RestoreManagerV2 (restore_manager_v2.py)              │
│         Job CRUD in Redis (m365:restore_job:{uuid})             │
│         execute() → dispatch to workload restorer               │
└─────────────────────────┬──────────────────────────────────────┘
                          │
                          ↓
┌────────────────────────────────────────────────────────────────┐
│              Celery Worker (execute_restore_job_v2)             │
└─────────────────────────┬──────────────────────────────────────┘
                          │
             ┌────────────┼─────────────┐
             ↓            ↓             ↓
┌─────────────────┐ ┌──────────────┐ ┌─────────────────┐
│ SharePoint      │ │ OneDrive     │ │ Outlook         │
│ Restore         │ │ Restore      │ │ Restore         │
│ (Graph API)     │ │ (Graph API)  │ │ (Graph API)     │
└─────────────────┘ └──────────────┘ └─────────────────┘
             │            │             │
             └────────────┴─────────────┘
                          │
                          ↓
                ┌─────────────────────┐
                │ Microsoft Graph API │
                │  (tenant scope)     │
                └─────────────────────┘
```

### 4.2 Restore Job Lifecycle
```
[User submits form]
         │
         ↓
[Job created in Redis: status=queued]
         │
         ↓
[Celery task picked up: status=running]
         │
         ↓
[Iterate targets (sites/users/mailboxes)]
         │
         ↓
[For each target: upload files / import items]
         │
         ↓
[Progress updates every ~0.5s to Redis]
         │
         ↓
[User can cancel → status=cancelled]
         │
         ↓
[Complete: status=completed / failed]
         │
         ↓
[UI polls /api/v2/restore/jobs every 4s]
```

### 4.3 Backup → Restore Mapping

Backup structure (from v11):
```
/backup/m365/{tenant-slug}/{workload}/backup_{ts}/
```

Restore path resolution:
```python
# Given: backup_path = /backup/m365/digiserve-by-telkom/sharepoint/backup_20260628_020000
# Restore engine iterates:
#   /backup_.../BIRA_TEAM/         → target site "BIRA_TEAM"
#     /Documents/                   → target drive "Documents"
#       /file1.docx                 → POST to Graph API
```

### 4.4 Data Flow — SharePoint Restore
```
1. Client: POST /api/v2/restore/jobs { workload: "sharepoint", ... }
2. Server: create job in Redis, dispatch Celery task
3. Worker: RestoreManagerV2.execute(job_id)
4. Worker: SharePointRestore(tenant, backup_path, mode)
5. Restore engine:
   a. Get target site (by path or ID)
   b. Get target drives (document libraries)
   c. Iterate backup folder structure:
      for site_dir in backup_path:
        for lib_dir in site_dir:
          for file in lib_dir.rglob("*"):
            if mode == "merge" and exists on target: SKIP
            if size < 4 MB: PUT /drives/{id}/root:/{path}:/content
            else: create upload session, chunk 5 MB
6. Progress emit → Redis job update
7. UI polling /api/v2/restore/jobs shows real-time status
```

### 4.5 Data Flow — Outlook Restore
```
1. Same job creation as above (workload=outlook)
2. Restore engine:
   a. For each user folder in backup:
     b. Resolve target user_id via Graph
     c. If restore_items includes "messages":
        - Get/create "M365 Restored" folder
        - Load messages.json
        - For each message: strip read-only fields, POST /users/{id}/mailFolders/{folder}/messages
     d. If restore_items includes "calendar":
        - Load calendar.json
        - For each event: strip read-only fields, POST /users/{id}/events
     e. If restore_items includes "contacts":
        - Load contacts.json
        - For each contact: strip read-only fields, POST /users/{id}/contacts
```

---

## 5. UI/UX Specifications

### 5.1 Page: `/restore-v2`
**Two-column layout:**
- **Left (5/12):** Form
- **Right (7/12):** Jobs Queue (real-time)

### 5.2 Form Fields (Dynamic based on workload)

**Common:**
- Tenant (dropdown, populated from `/api/tenants`)
- Workload (button group: SharePoint / OneDrive / Outlook)
- Source Backup (dropdown, filtered by selected tenant + workload)
- Restore Mode (button group: Overwrite / Merge / New Location)

**SharePoint-only:**
- Target Site Path (text, e.g., `sites/RestoreArea`)

**OneDrive-only:**
- Target Folder in OneDrive (text, default: "M365 Restored")
- User Mapping (JSON textarea, e.g., `{"old@x.com": "new@x.com"}`)

**Outlook-only:**
- Items to Restore (checkboxes: Messages / Calendar / Contacts)
- User Mapping (JSON textarea)

### 5.3 Action Buttons
- **Preview (Dry Run)** — Ghost button
- **Start Restore** — Primary button (with confirmation dialog)

### 5.4 Preview Result Panel
Muncul setelah dry-run:
```
files_to_upload: 247
total_size_bytes: 5,242,880
files_that_would_skip: 12
```

### 5.5 Jobs Queue Cards
```
┌──────────────────────────────────────────────────────────┐
│ [SHAREPOINT] Digiserve by Telkom             [Running]   │
│ backup_20260628_020000 · mode: merge                     │
│ → Currently processing: BIRA_TEAM                        │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ │
│ ━━━━━━━━━━━━━━━━━━━━━━────────────────────────  67%      │
│ Started: 2026-07-08 14:30:15 · 142 items                 │
│ [Cancel]                                                  │
└──────────────────────────────────────────────────────────┘
```

### 5.6 Status Colors
- 🟢 completed  → green
- 🔵 running    → primary blue
- 🔴 failed     → red
- 🟡 queued     → yellow
- ⚪ cancelled  → gray
- 🟣 paused     → purple (future)

---

## 6. API Specification

### 6.1 Endpoints

#### `POST /api/v2/restore/jobs`
Create + queue a restore job.

**Request:**
```json
{
  "tenant_id": "uuid-...",
  "tenant_name": "Digiserve by Telkom",
  "workload": "sharepoint",
  "backup_path": "/backup/m365/digiserve-by-telkom/sharepoint/backup_20260628_020000",
  "source_backup": "backup_20260628_020000",
  "mode": "merge",
  
  "target_site_path": "sites/RestoreArea",           // SharePoint
  "user_mapping": {"old@x.com": "new@x.com"},        // OneDrive/Outlook
  "target_folder": "M365 Restored",                  // OneDrive
  "restore_items": ["messages", "calendar"]           // Outlook
}
```

**Response 201:**
```json
{
  "status": "created",
  "job": { "id": "uuid-...", "status": "queued", "progress": 0, ... }
}
```

**Response 400:** Missing/invalid fields

#### `GET /api/v2/restore/jobs?limit=50`
List all jobs (newest first).

**Response:**
```json
{
  "jobs": [
    {
      "id": "uuid-...",
      "workload": "sharepoint",
      "tenant_name": "Digiserve by Telkom",
      "source_backup": "backup_20260628_020000",
      "mode": "merge",
      "status": "running",
      "progress": 45,
      "current_target": "BIRA_TEAM",
      "items_processed": 142,
      "items_failed": 0,
      "bytes_uploaded": 15728640,
      "created_at": "2026-07-08T14:30:00Z",
      "started_at": "2026-07-08T14:30:15Z",
      "completed_at": null
    }
  ]
}
```

#### `GET /api/v2/restore/jobs/<job_id>`
Get single job details.

#### `POST /api/v2/restore/jobs/<job_id>/cancel`
Cancel an active job. Uses `force_cancel_task()` from v11.

#### `DELETE /api/v2/restore/jobs/<job_id>`
Delete a completed/failed/cancelled job from history.

#### `POST /api/v2/restore/preview`
Dry-run — same request body as create, but returns preview without executing.

---

## 7. Security & Permissions

### 7.1 Required Graph API Permissions

For restore to work, App Registration must have **APPLICATION** permissions:

| Workload | Required Permissions |
|----------|---------------------|
| SharePoint | `Sites.ReadWrite.All`, `Files.ReadWrite.All` |
| OneDrive | `Files.ReadWrite.All`, `User.Read.All` |
| Outlook | `Mail.ReadWrite`, `MailboxSettings.ReadWrite`, `Calendars.ReadWrite`, `Contacts.ReadWrite` |

**Admin consent required for all.**

### 7.2 Safety Measures
- ⚠️ Confirmation dialog before starting restore (native `confirm()`)
- ⚠️ Dry-run preview available before commit
- ⚠️ Merge mode is default (safest — no destructive action)
- ⚠️ Restore into isolated folder ("M365 Restored") for Outlook
- ⚠️ No cross-tenant restore in v13 (tenant_id fixed)
- ⚠️ Job cancellation propagates via SIGTERM to Celery worker

### 7.3 Audit Trail
Every job stored in Redis with:
- `created_at`, `started_at`, `completed_at`
- `status` transitions
- `errors[]` array
- `result` full stats

Persisted to Redis with 24h TTL for job list (last 100 jobs).

---

## 8. Testing Plan

### 8.1 Test Cases (Manual)

#### **TC-01: SharePoint Restore Basic (Merge)**
1. Prepare: A backup folder with 3 sites, 100 files total
2. Action: Create restore job, workload=sharepoint, mode=merge
3. Expected: All 100 files uploaded; if any file exists, it's skipped

#### **TC-02: SharePoint Restore (New Location)**
1. Prepare: Backup for site "BIRA_TEAM"
2. Action: Set target_site_path="sites/RestoreArea"
3. Expected: Files uploaded to `sites/RestoreArea/Documents/...`

#### **TC-03: OneDrive Restore Same User**
1. Prepare: Backup for user1@digiserve.co.id
2. Action: Restore with no user_mapping, mode=merge
3. Expected: Files uploaded to user1's OneDrive root; skipped if exist

#### **TC-04: OneDrive Restore Mapped User**
1. Prepare: Backup for user1@digiserve.co.id (user1 left company)
2. Action: user_mapping={"user1@digiserve.co.id": "manager@digiserve.co.id"}
3. Expected: Files uploaded to manager's OneDrive

#### **TC-05: OneDrive New Location Folder**
1. Prepare: Backup for user1
2. Action: mode=new_location, target_folder="Legal_Hold/2026-Q2"
3. Expected: Files inside `Legal_Hold/2026-Q2/` subfolder in user1's OneDrive

#### **TC-06: Outlook Messages Restore**
1. Prepare: Backup with 500 messages
2. Action: restore_items=["messages"], mode=merge
3. Expected: 500 messages in "M365 Restored" folder in target mailbox

#### **TC-07: Outlook Full Mailbox Restore**
1. Prepare: Backup with messages + calendar + contacts
2. Action: restore_items=all 3, mode=merge
3. Expected: All 3 item types restored; existing items skipped

#### **TC-08: Dry-Run Accuracy**
1. Prepare: Backup with known counts
2. Action: Click "Preview" on restore form
3. Expected: Counts match actual backup content

#### **TC-09: Cancel Running Job**
1. Prepare: Large backup (>1000 items)
2. Action: Start restore, cancel after ~30% progress
3. Expected: Job status=cancelled, no more uploads happen

#### **TC-10: Concurrent Restores**
1. Prepare: 2 different backups
2. Action: Start 2 restore jobs simultaneously
3. Expected: Both run concurrently (Celery concurrency=2)

### 8.2 Regression Tests (v10-v12 features)
- Backup task still runs on schedule
- Global config editable
- Tenant CRUD works
- Per-tenant schedule (v12) still works

---

## 9. Deployment Steps

### 9.1 Pre-requisites
- v10, v11, v12 already applied and working
- ZimaOS host with Docker + docker-compose
- `/media/Storage/Container/M365/` path exists
- Graph API permissions granted (see 7.1)

### 9.2 Apply v13 Patch
See `README.md` in this ZIP for detailed steps.

### 9.3 Rollback Plan
If restore causes issues:
1. Stop containers: `docker compose down`
2. Delete `app/restore/` folder
3. Delete `app/restore_manager_v2.py`, `tasks_v13.py`, `main_routes_v13.py`
4. Remove v13 registration lines from `tasks.py` and `main.py`
5. Delete `app/templates/restore_v2.html`
6. Rebuild: `docker compose build && docker compose up -d`
7. Old restore engine (v10) still available via `/restore` (unchanged)

---

## 10. Success Criteria

| ID | Criteria | Method |
|----|----------|--------|
| SC-01 | Can restore SharePoint files to same/different site | Manual test TC-01, TC-02 |
| SC-02 | Can restore OneDrive to same or mapped user | Manual test TC-03, TC-04 |
| SC-03 | Can restore Outlook messages/calendar/contacts | Manual test TC-06, TC-07 |
| SC-04 | Merge mode skips existing items correctly | Verify item counts in dry-run vs actual |
| SC-05 | UI shows real-time progress with <5s lag | Observe UI while restore runs |
| SC-06 | Cancel button stops restore | Manual test TC-09 |
| SC-07 | Dry-run does NOT modify M365 data | Compare tenant state before/after preview |
| SC-08 | Job history persists across container restart | Restart container, check UI |
| SC-09 | No regressions in v10-v12 features | Regression test checklist |

---

## 11. Known Limitations & Risks

### Limitations
- **Outlook `id` field** — Original message IDs cannot be preserved (Graph limitation).
  Restored messages get new IDs.
- **Attachments** — Currently included in messages.json for restore. Very large
  attachments (>150 MB) may fail (Graph limit).
- **Categories & Flags** — Message flags/categories preserved via JSON but restore
  behavior depends on Graph API acceptance.
- **Shared/Delegated mailboxes** — Requires additional permissions not covered.
- **Preserved Original Location** — SharePoint restore uses library name matching;
  if backup lib name doesn't exist on target, falls back to "Documents".

### Risks
- **Quota Exceeded** — Restore might hit OneDrive/SharePoint storage quota
  → recommend user monitor storage
- **Rate Limits** — Bulk restore of 10,000+ items may trigger throttling
  → engine has retry logic + backoff
- **Data Duplication** — If merge dedup logic fails, could create duplicates
  → mitigated by internetMessageId/iCalUId checks
- **Timezone Ambiguity** — Restored calendar events may show slight time shifts
  if timezone metadata missing from backup

---

## 12. Future Roadmap (v14+)

| Version | Feature |
|---------|---------|
| v14 | Teams chat backup + restore |
| v15 | Point-in-time restore (choose date range) |
| v16 | Backup encryption at-rest (AES-256) |
| v17 | Retention policies per tenant |
| v18 | Multi-user login (RBAC) |
| v19 | Export restore report (PDF) |
| v20 | Cross-tenant restore |

---

## 13. Appendix

### 13.1 File Inventory (v13-patch.zip)
```
v13-patch/
├── README.md
├── PRD-v13.md                              (this file)
├── docs/
│   ├── ARCHITECTURE.md
│   ├── API-REFERENCE.md
│   ├── TESTING-CHECKLIST.md
│   └── TROUBLESHOOTING.md
└── app/
    ├── restore/
    │   ├── __init__.py                     (factory)
    │   ├── base.py                         (BaseRestore + auth + retry)
    │   ├── sharepoint.py                   (SharePoint restore)
    │   ├── onedrive.py                     (OneDrive restore — NEW)
    │   └── outlook.py                      (Outlook restore — NEW)
    ├── restore_manager_v2.py               (job queue + orchestration)
    ├── tasks_v13.py                        (Celery task registration)
    ├── main_routes_v13.py                  (Flask API endpoints)
    └── templates/
        └── restore_v2.html                 (Multi-workload restore UI)
```

### 13.2 Config Additions
No config.json changes needed for v13. All state is in Redis + backup folder metadata.

### 13.3 Related Documents
- v10 README — Multi-tenant introduction
- v11 README — Tenant-aware folder structure
- v12 README — Per-tenant schedules
- Microsoft Graph API docs — https://learn.microsoft.com/en-us/graph/

---

**End of PRD v13**
