# 🚀 v13 Patch — Full Multi-Workload Restore

**Additive patch — v10, v11, v12 tetap jalan. Menambahkan restore untuk semua workloads.**

---

## 🎯 What's New

| Feature | Description |
|---------|-------------|
| ✅ **SharePoint Restore (Enhanced)** | Upload files kembali ke SP dengan mode overwrite/merge/new_location |
| ✅ **OneDrive Restore (NEW)** | Restore per-user OneDrive dengan user mapping |
| ✅ **Outlook Restore (NEW)** | Restore messages/calendar/contacts ke mailbox target |
| ✅ **Job Queue System** | Persistent restore jobs di Redis dengan real-time status |
| ✅ **Dry-Run Preview** | Preview count sebelum commit — safety first |
| ✅ **3 Restore Modes** | Overwrite / Merge (safest) / New Location |
| ✅ **User Mapping** | Restore User A's data ke User B (mailbox handover, dll) |
| ✅ **Cancel Running Job** | Stop active restore via UI |
| ✅ **New Restore UI** | `/restore-v2` — unified untuk semua workloads |
| ✅ **Comprehensive PRD** | Full Product Requirements Document included |

---

## 📖 Documentation Included

Semua dokumentasi PRD dan technical docs sudah di dalam ZIP:

```
v13-patch/
├── README.md                    ← File ini
├── PRD-v13.md                   ← Product Requirements (full detail)
├── docs/
│   ├── ARCHITECTURE.md          ← Component + sequence diagrams
│   ├── API-REFERENCE.md         ← REST endpoint spec + curl examples
│   ├── TESTING-CHECKLIST.md     ← 30+ test cases with checkboxes
│   └── TROUBLESHOOTING.md       ← 10 common issues + solutions
```

**Baca PRD-v13.md dulu** — berisi:
- Executive summary + problem statement
- User personas (Wahyu, Junior IT, Compliance)
- Feature scope (In / Out)
- Technical architecture (diagrams)
- UI/UX specifications
- API specification
- Security & permissions matrix
- Testing plan (10 functional tests + regressions)
- Deployment steps + rollback plan
- Success criteria (SC-01 to SC-09)
- Known limitations & risks
- Future roadmap (v14+)

---

## 📦 Files in v13 Patch

### Application Files
```
app/
├── restore/                       ← NEW directory
│   ├── __init__.py                (factory: get_restore())
│   ├── base.py                    (BaseRestore + auth + retry + progress)
│   ├── sharepoint.py              (Enhanced — supports 3 modes)
│   ├── onedrive.py                (NEW — per-user + user mapping)
│   └── outlook.py                 (NEW — messages/cal/contacts)
├── restore_manager_v2.py          (NEW — job queue + orchestration)
├── tasks_v13.py                   (NEW — Celery task registration)
├── main_routes_v13.py             (NEW — /api/v2/restore/* endpoints)
└── templates/
    └── restore_v2.html            (NEW — Multi-workload restore UI)
```

### Documentation
```
├── README.md
├── PRD-v13.md
└── docs/
    ├── ARCHITECTURE.md
    ├── API-REFERENCE.md
    ├── TESTING-CHECKLIST.md
    └── TROUBLESHOOTING.md
```

---

## 🚀 Deployment Steps

### Step 1: Prerequisites Check
```bash
# Verify v10-v12 are running
cd /media/Storage/Container/M365
DOCKER_CONFIG=/media/Storage/Container/M365/.docker docker compose ps
# Should show 4 containers: web, redis, worker, scheduler

# Verify tenants configured
curl http://localhost:5055/api/tenants

# Verify at least 1 backup exists
ls /media/Storage/Container/M365/data/
```

### Step 2: Backup Current State (Safety)
```bash
# Config backup
cp /media/Storage/Container/M365/config/config.json \
   /media/Storage/Container/M365/config/config.json.pre-v13

# Code backup
tar -czf /tmp/m365-pre-v13.tar.gz -C /media/Storage/Container/M365 app
```

### Step 3: Stop Containers
```bash
DOCKER_CONFIG=/media/Storage/Container/M365/.docker docker compose down
```

### Step 4: Upload & Extract v13-patch.zip
```bash
cd /media/Storage/Container/M365
# Upload v13-patch.zip via ZimaOS File Manager or SCP
unzip v13-patch.zip
```

### Step 5: Copy Files
```bash
cd /media/Storage/Container/M365

# Create restore subdirectory
mkdir -p app/restore

# Copy Python modules
cp v13-patch/app/restore/*.py            app/restore/
cp v13-patch/app/restore_manager_v2.py   app/
cp v13-patch/app/tasks_v13.py            app/
cp v13-patch/app/main_routes_v13.py      app/

# Copy UI template
cp v13-patch/app/templates/restore_v2.html app/templates/
```

### Step 6: Register v13 in tasks.py

Tambahkan di **akhir file** `app/tasks.py`:

```python
# ── v13: Register multi-workload restore task ──
try:
    from app.tasks_v13 import register_v13_tasks
    register_v13_tasks(celery_app)
except Exception as e:
    log.error(f"v13 tasks registration failed: {e}")
```

### Step 7: Register v13 in main.py

Tambahkan setelah import statements:

```python
from app.main_routes_v13 import register_v13_routes
```

Tambahkan setelah `register_v12_routes(app)`:

```python
register_v13_routes(app)
```

### Step 8: Update Sidebar Menu (Optional)

Edit `app/templates/base.html`, tambahkan menu link:

```html
<a href="/restore-v2" class="nav-link {% if request.path == '/restore-v2' %}active{% endif %}">
    <i class="bi bi-arrow-counterclockwise"></i>
    <span>Restore v2</span>
</a>
```

### Step 9: Rebuild & Start
```bash
cd /media/Storage/Container/M365
export DOCKER_CONFIG=/media/Storage/Container/M365/.docker
docker compose build
docker compose up -d
sleep 15
docker compose logs -f worker
```

Look for:
```
✓ v13 tasks registration successful
```

### Step 10: Verify
```bash
# Test API endpoint
curl -s http://localhost:5055/api/v2/restore/jobs | python3 -m json.tool
# Should return: {"jobs": []}

# Open UI
# http://<zima-ip>:5055/restore-v2
```

---

## 🎬 First Use — Quick Start

### Restore SharePoint files (recommended: Merge mode)
1. Open `http://<zima-ip>:5055/restore-v2`
2. Select **Tenant** = "Digiserve by Telkom"
3. Click **SharePoint** workload button
4. Select **Source Backup** from dropdown
5. Keep **Mode = Merge** (safest — won't overwrite)
6. Click **Preview (Dry Run)** first
7. Review counts, then click **Start Restore**
8. Confirm dialog
9. Watch progress in right panel

### Restore OneDrive to different user
1. Select **Tenant** and click **OneDrive** button
2. Select backup
3. Enter user mapping JSON:
   ```json
   {"olduser@digiserve.co.id": "newuser@digiserve.co.id"}
   ```
4. Choose mode:
   - **Merge:** Add to newuser's OneDrive root
   - **New Location:** Put in subfolder (default: "M365 Restored")
5. Start Restore

### Restore Outlook messages only
1. Select tenant + **Outlook** workload
2. Uncheck **Calendar** and **Contacts** (keep only Messages)
3. Mode = Merge (skip duplicates by internetMessageId)
4. Start Restore
5. Messages appear in user's mailbox in folder **"M365 Restored"**

---

## 🔒 Required Graph API Permissions

Untuk restore bekerja, App Registration harus punya permissions ini
(**APPLICATION type + admin consent**):

### SharePoint Restore
- `Sites.ReadWrite.All`
- `Files.ReadWrite.All`

### OneDrive Restore
- `Files.ReadWrite.All`
- `User.Read.All`

### Outlook Restore
- `Mail.ReadWrite`
- `MailboxSettings.ReadWrite`
- `Calendars.ReadWrite`
- `Contacts.ReadWrite`

**Note:** Kalau backup sudah jalan, permissions "Read" sudah ada. Kamu perlu
**tambah** permissions **"ReadWrite"** untuk restore.

---

## 🔌 API Endpoints (v13)

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/v2/restore/jobs` | POST | Create restore job |
| `/api/v2/restore/jobs` | GET | List jobs |
| `/api/v2/restore/jobs/<id>` | GET | Get job details |
| `/api/v2/restore/jobs/<id>/cancel` | POST | Cancel active job |
| `/api/v2/restore/jobs/<id>` | DELETE | Delete finished job |
| `/api/v2/restore/preview` | POST | Dry-run preview |

Full API spec: **`docs/API-REFERENCE.md`**

---

## 🧪 Testing

Full test checklist di **`docs/TESTING-CHECKLIST.md`** dengan 30+ test cases.

Quick smoke test:
```bash
# 1. Container health
docker compose ps

# 2. Web UI loads
curl -sI http://localhost:5055/restore-v2 | head -1
# Should return: HTTP/1.1 200 OK

# 3. API works
curl http://localhost:5055/api/v2/restore/jobs
# Should return: {"jobs": []}

# 4. Preview a backup
curl -X POST http://localhost:5055/api/v2/restore/preview \
  -H "Content-Type: application/json" \
  -d '{
    "tenant_id": "<uuid>",
    "workload": "sharepoint",
    "backup_path": "/backup/m365/digiserve-by-telkom/sharepoint/backup_XXX",
    "source_backup": "backup_XXX",
    "mode": "merge"
  }'
# Should return counts
```

---

## 🛠️ Troubleshooting

Common issues + solutions: **`docs/TROUBLESHOOTING.md`**

Quick diagnostics:
```bash
# View logs
docker logs m365-backup-worker --tail 100

# Check Redis for stuck jobs
docker exec m365-backup-redis redis-cli -n 2 KEYS "m365:restore_job:*"

# Test Graph API auth
docker exec m365-backup-web python3 -c "
from app.tenant_manager import TenantManager
tm = TenantManager()
tenant = tm.get_active_tenant()
result = tm.test_tenant(tenant['id'])
print(result)
"
```

---

## 📊 What's Different from v10 Restore?

| Aspect | v10 Restore | v13 Restore |
|--------|------------|-------------|
| Workloads | SharePoint only | SharePoint + OneDrive + Outlook |
| Modes | Basic (append) | Overwrite / Merge / New Location |
| UI | Simple form | Split form + Jobs Queue with real-time |
| Job tracking | In-memory | Persistent in Redis |
| Dry-run | ❌ | ✅ Preview counts |
| Cancel | Limited | ✅ SIGTERM to worker |
| User mapping | ❌ | ✅ Restore to different user |
| API | v1 endpoints | v2 endpoints (`/api/v2/restore/*`) |
| Deduplication | ❌ | ✅ By internetMessageId, iCalUId, email |
| Large files | Basic | ✅ Upload session, chunked |

**Old v10 endpoints still work** — v13 tambah `/api/v2/restore/*` tanpa hapus yang lama.

---

## 🔄 Rollback

Kalau ada masalah kritis:

```bash
cd /media/Storage/Container/M365
export DOCKER_CONFIG=/media/Storage/Container/M365/.docker
docker compose down

# Restore code from backup
tar -xzf /tmp/m365-pre-v13.tar.gz -C /media/Storage/Container/M365

# Restore config
cp config/config.json.pre-v13 config/config.json

# Comment out v13 registration in tasks.py & main.py
# (or use git revert)

# Rebuild
docker compose build
docker compose up -d
```

Endpoint `/api/v2/restore/*` akan hilang, tapi endpoint v10 `/restore` tetap ada.

---

## 📌 Compatibility Matrix

| Version | Requires |
|---------|----------|
| v13 | v10, v11 (folder structure) |
| v12 | Optional but recommended (per-tenant config) |
| v11 | REQUIRED (tenant-aware backup paths) |
| v10 | REQUIRED (base multi-tenant) |

Cannot skip versions.

---

## 🗺️ Roadmap After v13

| Version | Feature |
|---------|---------|
| **v14** | Teams chat backup + restore |
| **v15** | Point-in-time restore (choose date range) |
| **v16** | Backup encryption at-rest (AES-256) |
| **v17** | Retention policies per tenant (auto-delete old backups) |
| **v18** | Multi-user login (RBAC: Admin/Viewer) |
| **v19** | Export restore report (PDF/CSV) |
| **v20** | Cross-tenant restore |

---

## 📞 Support

Issues? Include this info:
- v13 patch applied? Yes/No
- v10, v11, v12 already applied? Yes/No
- Which workload failed? SharePoint/OneDrive/Outlook
- Exact error message
- Job ID from `/api/v2/restore/jobs`
- Container logs: `docker logs m365-backup-worker --tail 100`

---

**Version:** 13.0  
**Release Date:** 2026-07-08  
**Author:** Wahyu Budi Prastowo (IT Infrastructure Specialist)  
**Status:** Ready for Production
