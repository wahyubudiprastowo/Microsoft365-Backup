"""
v12 route patches.

Add to main.py:
    from app.main_routes_v12 import register_v12_routes
    register_v12_routes(app)
"""
from flask import jsonify, request
from app.schedule_manager import ScheduleManager


def register_v12_routes(app):
    sm = ScheduleManager()
    
    # ── Per-tenant schedule ──
    @app.route("/api/v2/tenants/<tenant_id>/schedule", methods=["GET"])
    def get_tenant_schedule(tenant_id):
        return jsonify(sm.get_schedule(tenant_id))

    @app.route("/api/v2/tenants/<tenant_id>/schedule", methods=["POST", "PUT"])
    def set_tenant_schedule(tenant_id):
        data = request.get_json(force=True, silent=True) or {}
        try:
            ok = sm.set_schedule(tenant_id, data)
            if not ok:
                return jsonify({"error": "Tenant not found"}), 404
            return jsonify({"status": "saved", "schedule": sm.get_schedule(tenant_id)})
        except ValueError as e:
            return jsonify({"error": str(e)}), 400
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    # ── Per-tenant notifications ──
    @app.route("/api/v2/tenants/<tenant_id>/notifications", methods=["GET"])
    def get_tenant_notifications(tenant_id):
        return jsonify(sm.get_notifications(tenant_id))

    @app.route("/api/v2/tenants/<tenant_id>/notifications", methods=["POST", "PUT"])
    def set_tenant_notifications(tenant_id):
        data = request.get_json(force=True, silent=True) or {}
        try:
            ok = sm.set_notifications(tenant_id, data)
            if not ok:
                return jsonify({"error": "Tenant not found"}), 404
            return jsonify({"status": "saved", "notifications": sm.get_notifications(tenant_id)})
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    # ── Test tenant notification ──
    @app.route("/api/v2/tenants/<tenant_id>/notifications/test", methods=["POST"])
    def test_tenant_notification(tenant_id):
        from app.tenant_manager import TenantManager
        from app.tasks_v12 import send_tenant_notification
        
        tm = TenantManager()
        tenant = tm.get_tenant(tenant_id)
        if not tenant:
            return jsonify({"error": "Tenant not found"}), 404
        
        # Fake test stats
        test_stats = {
            "task_id": "test-notification",
            "tenant_id": tenant_id,
            "tenant_name": tenant.get("name"),
            "tenant_slug": tenant.get("id"),
            "workloads": ["sharepoint"],
            "start_time": "2026-07-08T12:00:00+00:00",
            "end_time": "2026-07-08T12:00:15+00:00",
            "total_files": 42,
            "total_bytes": 12345678,
            "total_targets": 3,
            "total_failed": 0,
            "cancelled": False,
            "errors": [],
            "per_workload": {"sharepoint": {"files_downloaded": 42, "bytes_downloaded": 12345678}},
            "is_test": True,
        }
        try:
            result = send_tenant_notification(tenant_id, test_stats)
            return jsonify({"status": "sent", "result": result})
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    # ── List all schedules (for admin overview) ──
    @app.route("/api/v2/schedules")
    def list_all_schedules():
        return jsonify({"schedules": sm.list_enabled_schedules()})

    # ── Manually reload schedules (rebuild beat) ──
    @app.route("/api/v2/schedules/reload", methods=["POST"])
    def reload_schedules():
        """
        Trigger a beat reload. Requires celery-beat restart to fully take effect.
        Returns current schedules list.
        """
        try:
            from app.tasks import celery_app
            from app.tasks_v12 import register_tenant_schedules
            # Clear old
            celery_app.conf.beat_schedule = {}
            # Re-register
            register_tenant_schedules(celery_app)
            return jsonify({
                "status": "reloaded",
                "note": "celery-beat container must be restarted to fully apply",
                "active_schedules": list(celery_app.conf.beat_schedule.keys()),
            })
        except Exception as e:
            return jsonify({"error": str(e)}), 500
