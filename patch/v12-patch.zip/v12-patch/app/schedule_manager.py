"""
Per-tenant schedule manager — v12.
Each tenant can have its own cron schedule + notification config.

Tenant schema extension:
  {
    "id": "uuid",
    "name": "...",
    ...existing fields...,
    "schedule": {
        "enabled": true,
        "cron_expression": "0 2 * * *",
        "timezone": "Asia/Jakarta"
    },
    "notifications": {
        "email": {"enabled": true, "recipients": ["a@x.com", "b@x.com"]},
        "telegram": {"enabled": false, "chat_ids": []},
        "teams": {"enabled": false, "webhook_urls": []}
    }
  }
"""
import json
import logging
from typing import List, Dict, Optional

log = logging.getLogger("m365_backup")

DEFAULT_SCHEDULE = {
    "enabled": False,
    "cron_expression": "0 2 * * *",
    "timezone": "Asia/Jakarta",
}

DEFAULT_NOTIFICATIONS = {
    "email": {"enabled": False, "recipients": []},
    "telegram": {"enabled": False, "chat_ids": []},
    "teams": {"enabled": False, "webhook_urls": []},
}


class ScheduleManager:
    """Manage per-tenant schedules & notifications."""

    def __init__(self, config_path: str = "/app/data/config.json"):
        self.config_path = config_path

    def _load(self) -> dict:
        with open(self.config_path) as f:
            return json.load(f)

    def _save(self, cfg: dict):
        with open(self.config_path, "w") as f:
            json.dump(cfg, f, indent=4)

    # ── Schedule ──────────────────────────────────────────────
    def get_schedule(self, tenant_id: str) -> dict:
        """Get schedule for a tenant. Returns DEFAULT_SCHEDULE if not set."""
        cfg = self._load()
        for t in cfg.get("tenants", []):
            if t.get("id") == tenant_id:
                return t.get("schedule", DEFAULT_SCHEDULE.copy())
        return DEFAULT_SCHEDULE.copy()

    def set_schedule(self, tenant_id: str, schedule: dict) -> bool:
        """Set schedule for a tenant."""
        cfg = self._load()
        for t in cfg.get("tenants", []):
            if t.get("id") == tenant_id:
                # Merge with defaults
                current = t.get("schedule", DEFAULT_SCHEDULE.copy())
                current.update(schedule)
                # Validate cron expression
                self._validate_cron(current.get("cron_expression", ""))
                t["schedule"] = current
                self._save(cfg)
                log.info(f"Schedule updated for tenant {tenant_id[:8]}: "
                         f"{current.get('cron_expression')} "
                         f"(enabled={current.get('enabled')})")
                return True
        return False

    def _validate_cron(self, expr: str):
        """Validate cron expression has 5 fields."""
        if not expr or len(expr.split()) != 5:
            raise ValueError(f"Invalid cron expression: '{expr}'. Must have 5 fields.")

    # ── Notifications ─────────────────────────────────────────
    def get_notifications(self, tenant_id: str) -> dict:
        """Get notification config for a tenant."""
        cfg = self._load()
        for t in cfg.get("tenants", []):
            if t.get("id") == tenant_id:
                return t.get("notifications", DEFAULT_NOTIFICATIONS.copy())
        return DEFAULT_NOTIFICATIONS.copy()

    def set_notifications(self, tenant_id: str, notifications: dict) -> bool:
        """Set notification config for a tenant."""
        cfg = self._load()
        for t in cfg.get("tenants", []):
            if t.get("id") == tenant_id:
                current = t.get("notifications", {})
                # Deep merge each channel
                for channel, cfg_data in notifications.items():
                    if channel not in current:
                        current[channel] = {}
                    current[channel].update(cfg_data)
                t["notifications"] = current
                self._save(cfg)
                log.info(f"Notifications updated for tenant {tenant_id[:8]}")
                return True
        return False

    # ── List all tenant schedules (for beat) ──────────────────
    def list_enabled_schedules(self) -> List[Dict]:
        """
        List all enabled tenant schedules — used by celery-beat.
        Returns: [{tenant_id, tenant_name, cron_expression, timezone}, ...]
        """
        cfg = self._load()
        result = []
        for t in cfg.get("tenants", []):
            sched = t.get("schedule", {})
            if sched.get("enabled"):
                result.append({
                    "tenant_id": t.get("id"),
                    "tenant_name": t.get("name"),
                    "tenant_slug": self._slug(t.get("name", "")),
                    "cron_expression": sched.get("cron_expression"),
                    "timezone": sched.get("timezone", "Asia/Jakarta"),
                    "workloads": t.get("workloads_enabled", ["sharepoint"]),
                })
        return result

    @staticmethod
    def _slug(name: str) -> str:
        import re
        s = re.sub(r'[^a-z0-9]+', '-', name.lower()).strip('-')
        return s or "unknown"

    # ── Migration helper ──────────────────────────────────────
    def migrate_global_schedule_to_tenants(self):
        """
        Convert legacy global schedule (config.schedule) into per-tenant
        schedules. Applies global schedule to first tenant if none has one.
        """
        cfg = self._load()
        global_sched = cfg.get("schedule", {})
        if not global_sched.get("enabled"):
            return False

        migrated = False
        for t in cfg.get("tenants", []):
            if "schedule" not in t:
                t["schedule"] = {
                    "enabled": global_sched.get("enabled", False),
                    "cron_expression": global_sched.get("cron_expression", "0 2 * * *"),
                    "timezone": global_sched.get("timezone", "Asia/Jakarta"),
                }
                log.info(f"Migrated global schedule to tenant: {t.get('name')}")
                migrated = True

        if migrated:
            self._save(cfg)
        return migrated
