"""
v12 additive task registrations.
- Registers per-tenant scheduled backup tasks with Celery Beat
- Provides tenant-aware notification dispatch

Add to app/tasks.py at the END of the file:
    from app.tasks_v12 import register_tenant_schedules, send_tenant_notification
    register_tenant_schedules(celery_app)
"""
import logging
from datetime import datetime, timezone
from celery.schedules import crontab

log = logging.getLogger("m365_backup")


def register_tenant_schedules(celery_app):
    """
    Load per-tenant schedules from config.json and register with celery beat.
    
    Each enabled tenant becomes a separate beat entry:
      scheduled-backup-{tenant-slug}
    """
    try:
        from app.schedule_manager import ScheduleManager
        sm = ScheduleManager()
        
        # Auto-migrate global schedule → tenants (one-time)
        try:
            sm.migrate_global_schedule_to_tenants()
        except Exception as e:
            log.warning(f"Migration skipped: {e}")
        
        schedules = sm.list_enabled_schedules()
        
        # Initialize beat_schedule if not exists
        if not hasattr(celery_app.conf, "beat_schedule") or celery_app.conf.beat_schedule is None:
            celery_app.conf.beat_schedule = {}
        
        # Track scheduled tenants for logging
        registered = []
        
        for sched in schedules:
            try:
                parts = sched["cron_expression"].split()
                if len(parts) != 5:
                    log.error(f"Invalid cron for {sched['tenant_name']}: {sched['cron_expression']}")
                    continue
                
                task_name = f"scheduled-backup-{sched['tenant_slug']}"
                celery_app.conf.beat_schedule[task_name] = {
                    "task": "app.tasks.run_backup_task",
                    "schedule": crontab(
                        minute=parts[0],
                        hour=parts[1],
                        day_of_month=parts[2] if parts[2] != "*" else "*",
                        month_of_year=parts[3] if parts[3] != "*" else "*",
                        day_of_week=parts[4] if parts[4] != "*" else "*",
                    ),
                    "args": (sched["tenant_id"], sched["workloads"]),
                    "options": {"queue": "celery"},
                }
                registered.append(f"{sched['tenant_name']} ({sched['cron_expression']})")
            except Exception as e:
                log.error(f"Failed to register schedule for {sched.get('tenant_name')}: {e}")
        
        # Remove old global schedule if present (deprecated)
        if "scheduled-backup" in celery_app.conf.beat_schedule:
            del celery_app.conf.beat_schedule["scheduled-backup"]
        
        # Log ONCE per worker
        import os
        marker = "/tmp/.m365_tenant_schedules_logged"
        if not os.path.exists(marker) and registered:
            log.info(f"Registered {len(registered)} tenant schedule(s):")
            for r in registered:
                log.info(f"  • {r}")
            try:
                open(marker, "w").write("\n".join(registered))
            except Exception:
                pass
    except Exception as e:
        log.error(f"register_tenant_schedules failed: {e}")


def send_tenant_notification(tenant_id: str, stats: dict):
    """
    Send notification for a completed backup, using tenant-specific config.
    
    stats: dict from run_backup_task result
    """
    try:
        from app.schedule_manager import ScheduleManager
        from app.notifier import NotificationDispatcher
        from app.config_manager import load_config
        
        sm = ScheduleManager()
        tenant_notif = sm.get_notifications(tenant_id) if tenant_id else {}
        
        # Base global config (SMTP creds, bot token, etc)
        cfg = load_config()
        
        # Override recipients from tenant-specific settings
        # Priority: tenant config > global config
        merged_cfg = _merge_notification_config(cfg, tenant_notif)
        
        # Send via dispatcher with merged config
        dispatcher = NotificationDispatcher(merged_cfg)
        return dispatcher.send_all(stats)
    except Exception as e:
        log.error(f"send_tenant_notification failed: {e}")
        return {"error": str(e)}


def _merge_notification_config(global_cfg: dict, tenant_notif: dict) -> dict:
    """
    Merge global (SMTP credentials, bot tokens) with tenant-specific recipients.
    Tenant settings override recipients but keep transport credentials.
    """
    merged = dict(global_cfg)
    notif = dict(merged.get("notification", {}))
    
    # Email: use tenant recipients if enabled
    email_tenant = tenant_notif.get("email", {})
    if email_tenant.get("enabled") and email_tenant.get("recipients"):
        notif["enabled"] = True
        notif["email_to"] = email_tenant["recipients"]
    
    # Telegram: use tenant chat_ids if enabled
    tg_tenant = tenant_notif.get("telegram", {})
    if tg_tenant.get("enabled") and tg_tenant.get("chat_ids"):
        tg_cfg = dict(notif.get("telegram", {}))
        tg_cfg["enabled"] = True
        tg_cfg["chat_ids"] = tg_tenant["chat_ids"]
        notif["telegram"] = tg_cfg
    
    # Teams: use tenant webhook_urls if enabled
    tm_tenant = tenant_notif.get("teams", {})
    if tm_tenant.get("enabled") and tm_tenant.get("webhook_urls"):
        tm_cfg = dict(notif.get("teams", {}))
        tm_cfg["enabled"] = True
        tm_cfg["webhook_urls"] = tm_tenant["webhook_urls"]
        notif["teams"] = tm_cfg
    
    merged["notification"] = notif
    return merged
