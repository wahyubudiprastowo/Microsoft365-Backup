"""
PATCH INSTRUCTIONS for app/tasks.py — v12
─────────────────────────────────────────

Add these 2 sections to existing app/tasks.py.
"""

# ═══════════════════════════════════════════════════════════════
# PART 1: Add AT END OF FILE (after all task definitions)
# ═══════════════════════════════════════════════════════════════

# ── v12: Register per-tenant schedules ──
try:
    from app.tasks_v12 import register_tenant_schedules
    register_tenant_schedules(celery_app)
except Exception as e:
    log.error(f"v12 schedule registration failed: {e}")


# ═══════════════════════════════════════════════════════════════
# PART 2: MODIFY run_backup_task — Replace notification block
# ═══════════════════════════════════════════════════════════════
#
# In run_backup_task, find this block:
#
#     # Try notification
#     try:
#         from app.notifier import NotificationDispatcher
#         NotificationDispatcher(load_config()).send_all(overall_stats)
#     except Exception as e:
#         log.warning(f"Notification failed: {e}")
#
# REPLACE with:
#
#     # v12: Use tenant-aware notification
#     try:
#         from app.tasks_v12 import send_tenant_notification
#         send_tenant_notification(tenant.get("id"), overall_stats)
#     except Exception as e:
#         log.warning(f"Notification failed: {e}")
#         # Fallback to global config
#         try:
#             from app.notifier import NotificationDispatcher
#             NotificationDispatcher(load_config()).send_all(overall_stats)
#         except Exception as e2:
#             log.error(f"Global notification also failed: {e2}")
