# v12 Sidebar Menu Addition

Add this new menu link to `app/templates/base.html`.

Find the existing sidebar navigation section (around where you have links like
Dashboard, Tenants, Workloads, Backups). Insert this NEW item:

```html
<!-- v12: Per-tenant Schedules -->
<a href="/schedules" class="nav-link {% if request.path == '/schedules' %}active{% endif %}">
    <i class="bi bi-clock-history"></i>
    <span>Schedules</span>
</a>
```

Place it between "Workloads" and "Backups" for logical grouping.

## Register the route in main.py

Add this route handler (if not already covered by a blueprint):

```python
@app.route("/schedules")
def schedules_page():
    return render_template("tenant_schedule.html")
```

Then register v12 API routes:

```python
from app.main_routes_v12 import register_v12_routes
register_v12_routes(app)
```
