# 🚀 v12 Patch — Per-Tenant Schedules & Notifications

**Additive patch — v11 tetap jalan.**

## What's New

| Feature | Description |
|---------|-------------|
| 🏢 **Per-tenant cron schedule** | Setiap tenant punya schedule independen |
| 📧 **Per-tenant email recipients** | Beda tenant → beda list email |
| 💬 **Per-tenant Telegram chat_ids** | Kirim ke chat berbeda per tenant |
| 🔗 **Per-tenant Teams webhooks** | Route ke Teams channel yang sesuai |
| 🔄 **Auto-migrate global schedule** | Legacy `config.schedule` otomatis dipindah ke tenants |
| 🎨 **New UI page** | `/schedules` — konfigurasi visual per tenant |
| 🧪 **Test notification per tenant** | Test kirim tanpa harus run backup |

---

## Config Structure (New)

Setelah patch v12, `config.json` tiap tenant bertambah 2 field:

```json
{
  "tenants": [
    {
      "id": "uuid-...",
      "name": "Digiserve by Telkom",
      "tenant_id": "089a...",
      "client_id": "...",
      "client_secret": "...",
      "workloads_enabled": ["sharepoint", "onedrive"],
      
      "schedule": {                           ← NEW v12
        "enabled": true,
        "cron_expression": "0 2 * * *",
        "timezone": "Asia/Jakarta"
      },
      
      "notifications": {                      ← NEW v12
        "email": {
          "enabled": true,
          "recipients": ["admin@digiserve.co.id"]
        },
        "telegram": {
          "enabled": false,
          "chat_ids": []
        },
        "teams": {
          "enabled": false,
          "webhook_urls": []
        }
      }
    }
  ]
}
```

Global `config.schedule` masih ada untuk backward-compat tapi otomatis dimigrasi ke tenants pertama kali worker restart.

---

## Files in v12 Patch

| File | Purpose |
|------|---------|
| `app/schedule_manager.py` | **NEW** — Per-tenant schedule + notification CRUD |
| `app/tasks_v12.py` | **NEW** — Dynamic beat schedule + tenant-aware dispatcher |
| `app/main_routes_v12.py` | **NEW** — `/api/v2/tenants/<id>/schedule` & `/notifications` endpoints |
| `app/templates/tenant_schedule.html` | **NEW** — Per-tenant configuration UI |
| `tasks-patch-instructions.md` | Manual edit instructions for `tasks.py` |
| `sidebar-patch.md` | UI menu addition instructions |

---

## Apply Patch

### Step 1: Stop containers
```bash
cd /media/Storage/Container/M365
DOCKER_CONFIG=/media/Storage/Container/M365/.docker docker compose down
```

### Step 2: Backup config
```bash
cp /media/Storage/Container/M365/config/config.json \
   /media/Storage/Container/M365/config/config.json.pre-v12
```

### Step 3: Upload & extract
```bash
cd /media/Storage/Container/M365
unzip v12-patch.zip
```

### Step 4: Copy files
```bash
cp v12-patch/app/schedule_manager.py            app/
cp v12-patch/app/tasks_v12.py                   app/
cp v12-patch/app/main_routes_v12.py             app/
cp v12-patch/app/templates/tenant_schedule.html app/templates/
```

### Step 5: Edit `app/tasks.py`

Tambahkan di **paling bawah file** `app/tasks.py`:

```python
# ── v12: Register per-tenant schedules ──
try:
    from app.tasks_v12 import register_tenant_schedules
    register_tenant_schedules(celery_app)
except Exception as e:
    log.error(f"v12 schedule registration failed: {e}")
```

**Optional** — di dalam `run_backup_task`, ganti block notification biar pakai tenant-aware config:

```python
# v12: tenant-aware notification
try:
    from app.tasks_v12 import send_tenant_notification
    send_tenant_notification(tenant.get("id"), overall_stats)
except Exception as e:
    log.warning(f"Notification failed: {e}")
```

### Step 6: Edit `app/main.py`

Tambahkan setelah import Flask lainnya:

```python
from app.main_routes_v12 import register_v12_routes
```

Setelah `app = Flask(__name__)` dan setelah v11 register:

```python
register_v12_routes(app)
```

Tambahkan route untuk halaman UI (kalau belum otomatis):

```python
@app.route("/schedules")
def schedules_page():
    return render_template("tenant_schedule.html")
```

### Step 7: Edit `app/templates/base.html`

Cari sidebar navigation, tambahkan link baru:

```html
<a href="/schedules" class="nav-link {% if request.path == '/schedules' %}active{% endif %}">
    <i class="bi bi-clock-history"></i>
    <span>Schedules</span>
</a>
```

### Step 8: Rebuild & restart
```bash
cd /media/Storage/Container/M365
export DOCKER_CONFIG=/media/Storage/Container/M365/.docker
docker compose build
docker compose up -d
sleep 15
docker compose logs -f worker
```

---

## Testing

### 1. Verify migration worked
```bash
docker exec m365-backup-web python3 -c "
from app.schedule_manager import ScheduleManager
sm = ScheduleManager()
print(sm.list_enabled_schedules())
"
```

Should show migrated tenant schedule.

### 2. Access UI
Buka `http://<zima-ip>:5055/schedules`

Akan muncul list semua tenants dengan status badge:
- 🕐 Schedule ON/OFF + cron expression
- 📧 Email recipient count
- 💬 Telegram chat count
- 🔗 Teams webhook count

### 3. Configure a tenant
1. Klik **Configure** di salah satu tenant
2. Tab **Schedule**: aktifkan + set cron (misal `0 2 * * *`)
3. Tab **Email**: aktifkan + isi recipients
4. Klik **Save**
5. Klik **Reload Beat** di header

### 4. Test notification per tenant
1. Di modal Configure → Tab **Email** (atau Telegram/Teams)
2. Klik **Test** button di footer
3. Cek inbox / channel

### 5. Verify beat picked up new schedule
```bash
docker exec m365-backup-scheduler celery -A app.tasks inspect scheduled
# Should show scheduled-backup-<tenant-slug> entries
```

Kalau belum muncul, restart celery-beat:
```bash
docker compose restart scheduler
```

---

## API Endpoints (v12)

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/v2/tenants/<id>/schedule` | GET | Get tenant schedule |
| `/api/v2/tenants/<id>/schedule` | POST | Save tenant schedule |
| `/api/v2/tenants/<id>/notifications` | GET | Get notification config |
| `/api/v2/tenants/<id>/notifications` | POST | Save notification config |
| `/api/v2/tenants/<id>/notifications/test` | POST | Send test notification |
| `/api/v2/schedules` | GET | List all enabled schedules |
| `/api/v2/schedules/reload` | POST | Reload beat schedules |

Example: Set schedule for a tenant
```bash
curl -X POST http://localhost:5055/api/v2/tenants/uuid-here/schedule \
  -H "Content-Type: application/json" \
  -d '{
    "enabled": true,
    "cron_expression": "0 2 * * *",
    "timezone": "Asia/Jakarta"
  }'
```

Example: Set email recipients
```bash
curl -X POST http://localhost:5055/api/v2/tenants/uuid-here/notifications \
  -H "Content-Type: application/json" \
  -d '{
    "email": {
      "enabled": true,
      "recipients": ["admin@digiserve.co.id", "it-team@digiserve.co.id"]
    }
  }'
```

---

## Architecture Notes

### How Per-Tenant Beat Works
Celery Beat scheduler membaca `celery_app.conf.beat_schedule` saat startup. v12 mengisi dict ini dinamis:

```python
{
    "scheduled-backup-digiserve-by-telkom": {
        "task": "app.tasks.run_backup_task",
        "schedule": crontab(minute=0, hour=2),
        "args": ("uuid-digiserve", ["sharepoint", "onedrive"]),
    },
    "scheduled-backup-contoso": {
        "task": "app.tasks.run_backup_task",
        "schedule": crontab(minute=0, hour=3),
        "args": ("uuid-contoso", ["sharepoint"]),
    }
}
```

Setiap entry punya `args` yang di-pass ke `run_backup_task(tenant_id, workloads)` — sehingga backup jalan khusus untuk tenant tersebut dengan workloads yang di-enable.

### Notification Merging
- **Transport credentials** (SMTP host/pass, Bot token) — dari global `config.notification`
- **Recipients** (email addresses, chat_ids, webhook URLs) — dari tenant-specific
- Kalau tenant setting `enabled=False` atau kosong → fallback ke global config

Ini design supaya:
- ✅ 1 SMTP account bisa dipakai semua tenants
- ✅ Setiap tenant tetap dapat notifikasi ke tim mereka masing-masing
- ✅ Global config masih works untuk manual/ad-hoc backups

---

## Rollback

```bash
cd /media/Storage/Container/M365
docker compose down

# Restore config
cp config/config.json.pre-v12 config/config.json

# Hapus 2 baris registrasi di tasks.py & main.py (comment out)
# Hapus route /schedules

docker compose up -d
```
