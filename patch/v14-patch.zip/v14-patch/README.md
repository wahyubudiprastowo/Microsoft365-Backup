# 🚀 v14 Patch — Microsoft Teams Workload

**Additive patch — extends v10-v13 with full Teams backup + HTML export.**

---

## 🎯 What's New

| Feature | Description |
|---------|-------------|
| 💬 **Teams Backup** (NEW) | All Teams, channels, messages + replies, tabs, files metadata |
| 📄 **HTML Export** | Static HTML archive — browseable offline |
| 📊 **JSON/TXT Export** | Multiple format options |
| 🔗 **Integration** | Uses existing v11 folder structure + v13 restore engine |
| 📅 **Compliance-ready** | Preserves message content, sender, timestamps, replies |

---

## 📖 Documentation Included

```
v14-patch/
├── README.md                  ← This file
├── PRD-v14.md                 ← Product Requirements (12 KB, 406 lines)
└── docs/
    ├── DEPLOYMENT.md          ← Step-by-step install (10 steps)
    └── TROUBLESHOOTING.md     ← 8 common issues + fixes
```

**Read PRD-v14.md** for:
- Executive summary + problem statement
- User personas (Compliance Admin, Legal, Handover)
- Feature scope (4 IN scope + 8 OUT scope)
- Technical architecture (folder structure + flow diagrams)
- Testing plan (8 test cases)
- Known limitations & risks
- Storage estimates

---

## ⚠️ Important: Teams "Restore" ≠ Direct Import

Microsoft Graph API **does NOT support importing messages back to Teams channels**
(except via special migration mode with different Azure setup).

Therefore, v14's "restore" for Teams = **EXPORT to browseable HTML/JSON/TXT archive**.

This is still valuable for:
- ✅ Compliance & audit trail (7-year retention)
- ✅ Legal hold (search & extract specific conversations)
- ✅ Employee offboarding (preserve their contributions)
- ✅ Historical reference (before Team is deleted)

---

## 📦 Files (7 files, ~28 KB)

```
v14-patch/
├── PRD-v14.md                     (12 KB)
├── README.md                      (this)
├── docs/
│   ├── DEPLOYMENT.md
│   └── TROUBLESHOOTING.md
└── app/
    ├── workloads/
    │   ├── teams.py               (NEW — 252 lines backup engine)
    │   └── __init___PATCH.py      (edit instructions)
    └── restore/
        ├── teams.py               (NEW — 376 lines export engine)
        └── __init___PATCH.py      (edit instructions)
```

---

## 🚀 Quick Deploy

### 1. Update Azure AD permissions
Add these APPLICATION permissions:
- `Team.ReadBasic.All`
- `Channel.ReadBasic.All`
- `ChannelMessage.Read.All`
- `ChannelSettings.Read.All`
- `TeamMember.Read.All`

**Grant admin consent** → wait 5-10 min.

### 2. Stop containers
```bash
cd /media/Storage/Container/M365
export DOCKER_CONFIG=/media/Storage/Container/M365/.docker
docker compose down
```

### 3. Upload & extract
```bash
unzip v14-patch.zip
```

### 4. Copy new files
```bash
cp v14-patch/app/workloads/teams.py app/workloads/
cp v14-patch/app/restore/teams.py app/restore/
```

### 5. Edit `app/workloads/__init__.py`
Add:
```python
from .teams import TeamsWorkload

WORKLOAD_REGISTRY["teams"] = TeamsWorkload   # add to existing dict
```

Update `WORKLOAD_METADATA["teams"]`:
```python
"teams": {
    "name": "Microsoft Teams",
    "description": "Teams, channels, messages, replies, files",
    "icon": "bi-microsoft-teams",
    "color": "#6264a7",
    "required_scopes": [
        "Team.ReadBasic.All",
        "Channel.ReadBasic.All",
        "ChannelMessage.Read.All",
        "ChannelSettings.Read.All",
        "TeamMember.Read.All",
        "Files.Read.All",
    ],
}
```

### 6. Edit `app/restore/__init__.py`
```python
from .teams import TeamsRestore

RESTORE_REGISTRY["teams"] = TeamsRestore
```

### 7. Edit `app/tasks.py` — Remove Teams filter
Find this line in `run_backup_task`:
```python
workloads = [w for w in workloads if w in WORKLOAD_METADATA and w != "teams"]
```

Change to:
```python
workloads = [w for w in workloads if w in WORKLOAD_METADATA]
```

### 8. Rebuild & start
```bash
docker compose build
docker compose up -d
sleep 15
```

### 9. Enable Teams for tenant
Open `/workloads` → toggle **Microsoft Teams** ON

### 10. Test
```bash
# Backup
curl -X POST http://localhost:5055/api/v2/backup/start \
  -H "Content-Type: application/json" \
  -d '{"workloads": ["teams"]}'

# After completion, check:
ls /media/Storage/Container/M365/data/*/teams/backup_*/
```

Full details: **`docs/DEPLOYMENT.md`**

---

## 🎬 Usage Flow

### Backup Teams
1. Open `/workloads` → enable **Microsoft Teams**
2. Optional: Set schedule in `/schedules`
3. Run backup manually or wait for scheduled
4. Backup created at `/backup/m365/{slug}/teams/backup_XXX/`

### Export to HTML
1. Open `/restore-v2`
2. Select **tenant**
3. Click **Teams** workload button
4. Select backup from dropdown
5. Click **Preview** → shows team/channel/message counts
6. Click **Start Restore**
7. Archive created at `/backup/m365/{slug}/teams-exports/backup_XXX/`

### Browse Archive
```bash
cd /media/Storage/Container/M365/data/digiserve-by-telkom/teams-exports/backup_XXX

# Option 1: Python HTTP server
python3 -m http.server 8080

# Then browse: http://<zima-ip>:8080

# Option 2: Copy to SharePoint / shared drive
tar -czf teams-archive-$(date +%Y%m%d).tar.gz .
# Upload to shared location
```

---

## 📊 HTML Archive Structure

```
teams-exports/backup_20260710_020000/
├── index.html                          ← Master (list of teams)
├── Digiserve Portal/
│   ├── index.html                      ← Team page (channels + members)
│   ├── General.html                    ← Channel with messages formatted
│   ├── General.txt                     ← Plain text version
│   ├── General.json                    ← Prettified JSON
│   ├── IT-Infrastructure.html
│   └── Marketing.html
└── BIRA TEAM/
    └── ...
```

**Design features:**
- 💜 Purple Teams-branded gradient header
- 📇 Card-based message layout
- 🔗 Reply threading (indented + lighter shade)
- 📎 Attachment metadata (name list)
- 🕐 Sender name + timestamp
- 📄 Original message formatting preserved
- 🔍 Ctrl+F search-friendly (all in one page)
- ✈️ Offline-capable (no external dependencies)

---

## 🔒 Required Permissions

For **backup**:
| Permission | Type |
|-----------|------|
| `Team.ReadBasic.All` | Application |
| `Channel.ReadBasic.All` | Application |
| `ChannelMessage.Read.All` | Application |
| `ChannelSettings.Read.All` | Application |
| `TeamMember.Read.All` | Application |
| `Group.Read.All` | (already have from OneDrive) |
| `User.Read.All` | (already have) |

For **export/restore**: No extra permissions needed (only reads local files).

**All require Admin consent.**

---

## 🧪 Verify Deployment

```bash
docker exec m365-backup-web python3 -c "
from app.workloads import WORKLOAD_REGISTRY
from app.restore import RESTORE_REGISTRY
assert 'teams' in WORKLOAD_REGISTRY, 'Teams backup NOT registered'
assert 'teams' in RESTORE_REGISTRY, 'Teams restore NOT registered'
print('✅ v14 Teams deployment: OK')
"
```

Expected output:
```
✅ v14 Teams deployment: OK
```

---

## 📊 Storage Estimates

| Scenario | Storage |
|----------|---------|
| Small team (10 channels, 1000 msgs/ch) — JSON | ~10 MB |
| Same team — HTML export | ~15 MB |
| 20 teams total | 200-300 MB (JSON) + 300-500 MB (HTML) |
| 50 teams total (Digiserve size) | 500 MB - 1.5 GB |

Plan `/media/Storage/Container/M365/data/` capacity accordingly.

---

## 🐛 Troubleshooting Quick Ref

Full guide: **`docs/TROUBLESHOOTING.md`**

Common issues:
- **0 Teams backed up** → Check `Team.ReadBasic.All` permission
- **Messages missing** → Need `ChannelMessage.Read.All` + admin consent  
- **Replies empty** → Verify permission includes ReadWrite for messages
- **Rate limit warnings** → Normal, engine handles it
- **HTML blank** → Check encoding, use Python HTTP server for testing

---

## 🔄 Rollback

```bash
cd /media/Storage/Container/M365
docker compose down
tar -xzf /tmp/m365-pre-v14.tar.gz -C /media/Storage/Container/M365/
docker compose up -d
```

Teams workload will be disabled but existing Teams backups remain on disk.

---

## 🗺️ Next Roadmap

| Version | Feature |
|---------|---------|
| **v15** | Point-in-time restore (choose date range) |
| **v16** | Backup encryption at-rest (AES-256) |
| **v17** | Retention policies per tenant |
| **v18** | Multi-user login (RBAC) |
| **v19** | Export restore report (PDF) |
| **v20** | Cross-tenant restore |

---

## ✅ Compatibility

| Version | Requires |
|---------|----------|
| **v14** | v10, v11 (folder structure) |
| v13 | Optional (restore engine) |
| v12 | Optional (per-tenant scheduling) |
| v11 | **REQUIRED** |
| v10 | **REQUIRED** |

---

**Version:** 14.0  
**Release Date:** 2026-07-10  
**Author:** Wahyu Budi Prastowo (IT Infrastructure Specialist)  
**Status:** Ready for Production
