# 📋 PRD — M365 Backup v14: Microsoft Teams Workload

**Product Owner:** Wahyu Budi Prastowo (IT Infrastructure Specialist)  
**Version:** 14.0  
**Status:** Ready for Production  
**Release Date:** July 2026  
**Depends on:** v10, v11, v12, v13

---

## 1. Executive Summary

### 1.1 Problem Statement
M365 Backup System (v10-v13) sudah support SharePoint, OneDrive, dan Outlook.
Namun **Microsoft Teams** — platform kolaborasi utama Digiserve — belum bisa
di-backup. Data yang berisiko hilang:
- Percakapan channel yang penting (project decisions, technical discussions)
- File yang di-share di channel
- Konfigurasi tabs, apps, dan settings channel
- Riwayat member/owner untuk audit compliance

### 1.2 Goal
Menambahkan **Teams workload** untuk backup:
- Semua Teams di tenant
- Semua channels (Standard, Private, Shared)
- Semua messages + replies + attachments metadata
- Team + channel metadata (settings, members, apps, tabs)

Serta **"Restore" (Export)** ke format HTML archive yang browseable —
karena Graph API tidak support import messages ke Teams channel secara langsung.

### 1.3 Success Metrics
| Metric | Target |
|--------|--------|
| Backup 1 Team (10 channels, 500 msgs) | ≤ 5 menit |
| Backup 20 Teams (~5000 msgs total) | ≤ 30 menit |
| Message content preserved | 100% (dengan formatting HTML) |
| Reply threading preserved | 100% |
| Export HTML file size per channel | ≤ 5 MB (typical) |
| HTML archive browseable offline | ✅ No dependencies |

---

## 2. User Personas

### 2.1 Wahyu — Compliance/Audit Backup Admin (Primary)
- **Need:** Backup all Teams data untuk audit trail 7 tahun
- **Pain:** Message di Teams tidak bisa di-export standard oleh user
- **Value:** Automated backup + browseable archive

### 2.2 Legal Team (New in v14)
- **Need:** Access conversations dari tanggal tertentu (legal hold)
- **Value:** HTML archive bisa di-search, print, share ke lawyer

### 2.3 Ex-Employee Data Handover
- **Need:** Preserve conversations of employee yang keluar
- **Value:** Backup sebelum akun dihapus, export ke folder shared

---

## 3. Feature Scope (v14)

### 3.1 IN Scope ✅

#### **F1: Teams Backup**
- Enumerate all Teams in tenant (Groups with Team provisioning)
- Backup team metadata:
  - Display name, description, visibility
  - Settings: member, messaging, guest, fun, discovery
  - Members + owners (with email + display name)
  - Created date
- Backup installed apps (best effort)

#### **F2: Channel Backup**
- Backup all channels per team (Standard + Private)
- Backup channel messages (paginated, up to 100 per page)
- Backup **replies** per message (nested)
- Backup channel tabs configuration
- Backup file metadata (index only — actual files backed up via SharePoint workload)

#### **F3: Teams "Restore" (HTML Export)**
Since Graph API doesn't support direct message re-import, we EXPORT to browseable formats:

- **HTML export** — Static HTML archive dengan:
  - Master index (list all teams)
  - Per-team index (channels + members)
  - Per-channel page (all messages + replies with formatting)
- **JSON export** — Consolidated JSON per channel
- **TXT export** — Plain text log per channel

#### **F4: Integration with Existing System**
- Registered in `WORKLOAD_REGISTRY` factory
- Uses same folder structure: `/backup/m365/{slug}/teams/backup_XXX/`
- Restore uses same `RESTORE_REGISTRY` and `/api/v2/restore/*` endpoints
- Backup UI shows Teams as available workload
- Per-tenant scheduling (v12) works for Teams

### 3.2 OUT of Scope ❌

- ❌ **Direct message re-import to Teams channel** — Graph API limitation
  - Alternative: use Migration mode (requires special setup, not covered)
- ❌ **Actual file download from channel** — Handled by SharePoint workload
- ❌ **1:1 chats (personal Teams chats)** — Different Graph endpoint, needs different permissions
- ❌ **Meeting recordings** — Stored in Stream, different API
- ❌ **Meeting chat messages** — Separate from channel messages
- ❌ **Reactions/likes** — Preserved in JSON but not visualized in HTML export
- ❌ **Teams Shifts, Planner, Forms** — Separate services

---

## 4. Technical Architecture

### 4.1 Backup Flow
```
1. list_targets() → Graph /groups?$filter=Team provisioning
2. For each team:
   a. Get team metadata (/teams/{id}, /groups/{id}/members, /owners)
   b. Get installed apps (/teams/{id}/installedApps)
   c. Get channels (/teams/{id}/channels)
   d. For each channel:
      - Get messages (/teams/{id}/channels/{id}/messages)
      - For each message: get replies (/messages/{id}/replies)
      - Get tabs (/channels/{id}/tabs)
      - Get files folder (/channels/{id}/filesFolder)
      - Save files index (metadata only)
3. Write _workload_manifest.json
```

### 4.2 Restore/Export Flow
```
1. Scan backup folder for team subdirectories
2. For each team:
   a. Load _team_metadata.json
   b. For each channel folder:
      - Load messages.json
      - Generate HTML page (with escape + formatting)
      - Generate TXT log
      - Copy prettified JSON
   c. Write team-level index.html (channel list + members)
3. Write master index.html (list of teams)
```

### 4.3 Backup Folder Structure
```
/backup/m365/{tenant-slug}/teams/backup_20260710_020000/
├── Digiserve Portal/
│   ├── _team_metadata.json
│   ├── apps.json
│   └── channels/
│       ├── General/
│       │   ├── messages.json           ← all messages + replies
│       │   ├── tabs.json
│       │   └── files/
│       │       └── _files_index.json
│       ├── IT-Infrastructure/
│       │   └── ...
│       └── Marketing/
├── BIRA TEAM/
│   └── ...
└── _workload_manifest.json
```

### 4.4 Export Output Structure
```
/backup/m365/{tenant-slug}/teams-exports/backup_20260710_020000/
├── index.html                          ← Master (list of teams)
├── Digiserve Portal/
│   ├── index.html                      ← Team page (channels + members)
│   ├── General.html                    ← Channel messages HTML
│   ├── General.txt                     ← Plain text log
│   ├── General.json                    ← Prettified JSON
│   └── IT-Infrastructure.html
└── BIRA TEAM/
    └── ...
```

### 4.5 Message Data Model
Each message preserved as-is from Graph API:
```json
{
  "id": "1234567890",
  "createdDateTime": "2026-07-10T10:30:00Z",
  "subject": "Optional subject",
  "body": {
    "contentType": "html",
    "content": "<p>Message body with formatting</p>"
  },
  "from": {
    "user": {
      "displayName": "Wahyu Budi",
      "id": "user-guid",
      "email": "wahyu@digiserve.co.id"
    }
  },
  "attachments": [...],
  "mentions": [...],
  "reactions": [...],
  "_replies": [ /* array of reply message objects */ ]
}
```

---

## 5. UI/UX Specifications

No new UI page needed — Teams workload appears automatically in:

### 5.1 Backup Page (Existing `/backups`)
- Filter dropdown includes "Teams"
- Workload badge with Teams purple color `#6264a7`
- Icon `bi-microsoft-teams`

### 5.2 Restore Page (Existing `/restore-v2`)
- Workload button "Teams" appears alongside SharePoint/OneDrive/Outlook
- When selected, form shows:
  - **Export Format** dropdown: HTML / JSON / TXT / All
  - **Export Directory** (optional override)
- Note displayed: *"Teams doesn't support direct restore. Backup will be exported to browseable HTML archive."*

### 5.3 Workloads Page (Existing `/workloads`)
- Teams card now shows as **enabled** (not "coming soon")
- Toggle switch works
- Required scopes list updated

### 5.4 HTML Archive Design
Bootstrap-inspired clean design:
- Purple Teams header (gradient)
- Card-based message layout
- Reply threading (indented + lighter shade)
- Sender avatar area (name + timestamp)
- Body preserves original HTML formatting
- Attachment list with paperclip icon

---

## 6. API & Config

### 6.1 No New Endpoints
v14 uses existing endpoints from v10-v13:
- `POST /api/v2/backup/start` — with `workloads: ["teams"]`
- `POST /api/v2/restore/jobs` — with `workload: "teams"`, `export_format: "html"`
- `GET /api/v2/backups?workload=teams` — filter Teams backups

### 6.2 Tenant Config
Add `"teams"` to `workloads_enabled` array:
```json
{
  "workloads_enabled": ["sharepoint", "onedrive", "outlook", "teams"]
}
```

---

## 7. Security & Permissions

### 7.1 Required Graph API Permissions (Application)

| Permission | Purpose |
|------------|---------|
| `Team.ReadBasic.All` | List teams |
| `Channel.ReadBasic.All` | List channels |
| `ChannelMessage.Read.All` | Read messages + replies |
| `ChannelSettings.Read.All` | Read channel settings |
| `TeamMember.Read.All` | Read team members |
| `Files.Read.All` | Read channel file metadata (SharePoint) |
| `Group.Read.All` | Enumerate groups (Teams live in groups) |
| `User.Read.All` | Resolve user info for sender/mentions |

All require **Admin consent**.

### 7.2 Data Sensitivity
Teams channel messages often contain:
- Business decisions
- Financial numbers
- Customer info (PII)
- Credentials (sometimes 😬)

**Recommendation:**
- Store backups on encrypted volumes
- Restrict access to `/media/Storage/Container/M365/data/` folder
- Consider v16 encryption at-rest

---

## 8. Testing Plan

### 8.1 Test Cases

#### **TC-01: Backup Small Team**
1. Create test team with 3 channels, ~10 messages each
2. Run Teams backup
3. **Expected:** Folder structure with `_team_metadata.json` + channels/{name}/messages.json

#### **TC-02: Backup Team with Replies**
1. Team has channel with parent messages + replies
2. Run backup
3. **Expected:** Each message in JSON has `_replies` array

#### **TC-03: Export to HTML**
1. Create restore job, workload=teams, mode=merge, export_format=html
2. **Expected:** HTML files generated in `teams-exports/` folder
3. Open `index.html` in browser
4. **Expected:** Master index → team page → channel messages with formatting

#### **TC-04: Export All Formats**
1. Same as TC-03 but `export_format=all`
2. **Expected:** HTML + TXT + JSON generated for each channel

#### **TC-05: Backup with Rate Limiting**
1. Backup tenant with 50+ teams
2. **Expected:** Engine handles 429 Too Many Requests gracefully with backoff

#### **TC-06: Preview (Dry Run)**
1. Preview a Teams backup
2. **Expected:** Returns teams_in_backup, channels_in_backup, messages_in_backup

#### **TC-07: Integration — Full Tenant Backup**
1. Configure tenant with workloads = [sharepoint, onedrive, outlook, teams]
2. Trigger backup
3. **Expected:** All 4 workloads run sequentially, results in email report

#### **TC-08: Failed Permissions**
1. Remove `ChannelMessage.Read.All` from app registration
2. Run backup
3. **Expected:** Channel messages skipped, errors logged clearly, no crash

### 8.2 Manual Verification
- Open HTML export in Firefox/Chrome/Edge — should render without issues
- No external network requests in HTML (self-contained)
- Search-friendly (Ctrl+F works)

---

## 9. Known Limitations & Risks

### 9.1 Limitations
- **Message content is HTML** — Graph provides sanitized HTML. Custom formatting may look different from Teams client.
- **Reactions/likes** stored in JSON but not visualized in HTML.
- **Adaptive cards** (rich messages from bots) may render partially in HTML export.
- **@mentions** kept as raw JSON references, not styled.
- **Deleted messages** — Only current state at backup time. Deleted-then-restored won't be captured.
- **Archive Teams** — Skipped from live enumeration (may need `$filter=archiveDate ne null`)

### 9.2 Risks
- **Large teams** (>1000 messages per channel) may take a long time to backup due to pagination
- **Graph API rate limits** may kick in for large tenants — engine handles gracefully
- **Attachment content** not downloaded (only metadata) — relies on SharePoint workload for actual files

### 9.3 Retention/Storage
- 1 Team with 10 channels, 1000 messages each ≈ 10 MB JSON
- 1 Team HTML export ≈ 15 MB
- 50 Teams full backup ≈ 500 MB - 1 GB
- Storage growth: linear with message count, plan capacity accordingly

---

## 10. Roadmap After v14

| Version | Feature |
|---------|---------|
| **v15** | Point-in-time restore (choose date range from all workloads) |
| **v16** | Backup encryption at-rest (AES-256) |
| **v17** | Retention policies per tenant (auto-delete old backups) |
| **v18** | Multi-user login (RBAC: Admin/Viewer per tenant) |
| **v19** | Export restore report (PDF/CSV) — includes Teams stats |
| **v20** | Cross-tenant restore (Digiserve → Contoso migration) |

---

## 11. Success Criteria

| ID | Criteria | Method |
|----|----------|--------|
| SC-01 | Can backup all Teams in tenant | Manual TC-01 |
| SC-02 | Messages + replies preserved | Manual TC-02, verify JSON |
| SC-03 | HTML export browseable offline | Manual TC-03 in browser |
| SC-04 | Integration with existing v10-v13 workflow | Manual TC-07 |
| SC-05 | Rate limiting handled | Manual TC-05 |
| SC-06 | Dry run accurate | Manual TC-06 |
| SC-07 | No regression in other workloads | Regression test |
| SC-08 | Failure handling graceful | Manual TC-08 |

---

## 12. File Inventory (v14-patch.zip)

```
v14-patch/
├── README.md
├── PRD-v14.md                              (this file)
├── docs/
│   ├── DEPLOYMENT.md
│   ├── TROUBLESHOOTING.md
│   └── API-CHANGES.md
└── app/
    ├── workloads/
    │   ├── teams.py                        (NEW — backup engine)
    │   └── __init___PATCH.py               (instructions)
    └── restore/
        ├── teams.py                        (NEW — export engine)
        └── __init___PATCH.py               (instructions)
```

---

**End of PRD v14**
