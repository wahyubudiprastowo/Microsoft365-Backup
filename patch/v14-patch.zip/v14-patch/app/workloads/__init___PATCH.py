"""
PATCH INSTRUCTIONS: app/workloads/__init__.py

Add these lines to register Teams workload.
"""

# ═══════════════════════════════════════════════════════════════
# Add to imports:
# ═══════════════════════════════════════════════════════════════
from .teams import TeamsWorkload


# ═══════════════════════════════════════════════════════════════
# Add to WORKLOAD_REGISTRY dict:
# ═══════════════════════════════════════════════════════════════
WORKLOAD_REGISTRY = {
    "sharepoint": SharePointWorkload,
    "onedrive": OneDriveWorkload,
    "outlook": OutlookWorkload,
    "teams": TeamsWorkload,        # ← ADD THIS
}


# ═══════════════════════════════════════════════════════════════
# Update WORKLOAD_METADATA["teams"]:
# ═══════════════════════════════════════════════════════════════
WORKLOAD_METADATA["teams"] = {
    "name": "Microsoft Teams",
    "description": "Teams, channels, messages, replies, files",
    "icon": "bi-microsoft-teams",
    "color": "#6264a7",
    "required_scopes": [
        "Team.ReadBasic.All",
        "Channel.ReadBasic.All",
        "ChannelMessage.Read.All",
        "ChannelSettings.Read.All",
        "TeamMember.Read.All",
        "Files.Read.All",
    ],
}
