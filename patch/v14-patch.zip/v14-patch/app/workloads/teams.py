"""
Microsoft Teams workload — v14.
Backs up: Teams, Channels, Messages (with replies), attachments metadata.

Backup structure:
  backup_20260710_020000/
    ├── {team-name-safe}/
    │   ├── _team_metadata.json          (team info + members)
    │   ├── channels/
    │   │   ├── General/
    │   │   │   ├── messages.json        (all messages + replies)
    │   │   │   ├── files/               (channel files metadata)
    │   │   │   │   └── _files_index.json
    │   │   │   └── tabs.json            (channel tabs config)
    │   │   └── {other-channels}/
    │   └── apps.json                    (installed apps in team)
    └── _workload_manifest.json

Required Graph permissions (Application):
    - Team.ReadBasic.All
    - Channel.ReadBasic.All
    - ChannelMessage.Read.All
    - ChannelSettings.Read.All
    - TeamMember.Read.All
    - Files.Read.All (for channel files)
"""
import os
import json
import time
from datetime import datetime, timezone
from .base import BaseWorkload

import logging
log = logging.getLogger("m365_backup")


class TeamsWorkload(BaseWorkload):
    WORKLOAD_NAME = "teams"

    def list_targets(self) -> list:
        """Enumerate all Teams in the tenant."""
        teams = []
        try:
            # Get all groups that are Teams-enabled
            data = self._paginate(
                f"{self.GRAPH}/groups",
                params={
                    "$filter": "resourceProvisioningOptions/Any(x:x eq 'Team')",
                    "$select": "id,displayName,description,visibility,createdDateTime",
                    "$top": 100,
                }
            )
            for g in data:
                teams.append({
                    "id": g["id"],
                    "name": g.get("displayName", "Unknown"),
                    "description": g.get("description", ""),
                    "visibility": g.get("visibility", "private"),
                    "type": "team",
                })
        except Exception as e:
            log.error(f"list_targets(teams) failed: {e}")
        return teams

    def backup(self) -> dict:
        self.stats["start_time"] = datetime.now(timezone.utc).isoformat()
        backup_path = self.build_backup_path()
        self.stats["backup_path"] = backup_path
        self.emit("backup_start", {"backup_path": backup_path})

        try:
            teams = self.list_targets()
            self.stats["teams_count"] = len(teams)
            self.emit("targets_enumerated", {"total_targets": len(teams)})

            for idx, team in enumerate(teams):
                self._check_control()
                self.emit("target_start", {
                    "target_name": team["name"],
                    "target_idx": idx + 1,
                    "target_total": len(teams),
                })
                try:
                    self._backup_team(team, backup_path)
                    self.stats["targets_processed"] += 1
                    self.emit("target_done", {"target_name": team["name"], "status": "success"})
                except Exception as e:
                    self.stats["targets_failed"] += 1
                    self.stats["errors"].append(f"[{team['name']}] {str(e)[:200]}")
                    self.emit("target_done", {"target_name": team["name"], "status": "failed", "error": str(e)})

            self._save_manifest(backup_path, teams)
        except Exception as e:
            log.error(f"Teams backup failed: {e}", exc_info=True)
            self.stats["errors"].append(f"Fatal: {e}")

        self.stats["end_time"] = datetime.now(timezone.utc).isoformat()
        self.emit("workload_done")
        return self.stats

    def _backup_team(self, team: dict, backup_path: str):
        """Backup single team."""
        team_id = team["id"]
        safe_name = self._safe_name(team["name"])
        team_dir = os.path.join(backup_path, safe_name)
        os.makedirs(team_dir, exist_ok=True)

        # 1. Team metadata + members
        try:
            members = self._paginate(f"{self.GRAPH}/groups/{team_id}/members?$top=100")
            owners = self._paginate(f"{self.GRAPH}/groups/{team_id}/owners?$top=100")
            team_full = self._get(f"{self.GRAPH}/teams/{team_id}")
        except Exception as e:
            log.warning(f"Failed to get full team info for {team['name']}: {e}")
            team_full = {}
            members = []
            owners = []

        meta = {
            "team_id": team_id,
            "team_name": team["name"],
            "description": team.get("description"),
            "visibility": team.get("visibility"),
            "created": team_full.get("createdDateTime"),
            "settings": {
                "member": team_full.get("memberSettings"),
                "messaging": team_full.get("messagingSettings"),
                "guest": team_full.get("guestSettings"),
                "fun": team_full.get("funSettings"),
                "discovery": team_full.get("discoverySettings"),
            },
            "members": [{"id": m.get("id"), "displayName": m.get("displayName"),
                         "email": m.get("mail") or m.get("userPrincipalName")} for m in members],
            "owners": [{"id": o.get("id"), "displayName": o.get("displayName"),
                        "email": o.get("mail") or o.get("userPrincipalName")} for o in owners],
            "backup_time": datetime.now(timezone.utc).isoformat(),
        }
        with open(os.path.join(team_dir, "_team_metadata.json"), "w") as f:
            json.dump(meta, f, indent=2, default=str)
        self.stats["files_downloaded"] += 1

        # 2. Installed apps (best effort)
        try:
            apps = self._paginate(f"{self.GRAPH}/teams/{team_id}/installedApps?$expand=teamsAppDefinition")
            with open(os.path.join(team_dir, "apps.json"), "w") as f:
                json.dump(apps, f, indent=2, default=str)
            self.stats["files_downloaded"] += 1
        except Exception as e:
            self.stats["errors"].append(f"apps [{team['name']}]: {str(e)[:100]}")

        # 3. Channels
        channels_dir = os.path.join(team_dir, "channels")
        os.makedirs(channels_dir, exist_ok=True)
        try:
            channels = self._paginate(f"{self.GRAPH}/teams/{team_id}/channels")
        except Exception as e:
            raise Exception(f"Cannot list channels: {e}")

        for channel in channels:
            self._check_control()
            self._backup_channel(team_id, channel, channels_dir)

    def _backup_channel(self, team_id: str, channel: dict, channels_dir: str):
        """Backup one channel: messages + files metadata + tabs."""
        ch_id = channel["id"]
        ch_name = channel.get("displayName", "Unknown")
        safe = self._safe_name(ch_name)
        ch_dir = os.path.join(channels_dir, safe)
        os.makedirs(ch_dir, exist_ok=True)

        # Messages (with replies)
        try:
            messages = self._paginate(
                f"{self.GRAPH}/teams/{team_id}/channels/{ch_id}/messages",
                params={"$top": 50}
            )
            # For each message, fetch replies
            for msg in messages:
                if msg.get("id"):
                    try:
                        msg["_replies"] = self._paginate(
                            f"{self.GRAPH}/teams/{team_id}/channels/{ch_id}/messages/{msg['id']}/replies",
                            params={"$top": 50}
                        )
                    except Exception:
                        msg["_replies"] = []
            with open(os.path.join(ch_dir, "messages.json"), "w") as f:
                json.dump(messages, f, indent=2, default=str)
            self.stats["files_downloaded"] += 1
            self.emit("channel_backed_up", {
                "current_file": f"{ch_name} ({len(messages)} msgs)"
            })
        except Exception as e:
            self.stats["errors"].append(f"messages [{ch_name}]: {str(e)[:100]}")

        # Tabs
        try:
            tabs = self._paginate(
                f"{self.GRAPH}/teams/{team_id}/channels/{ch_id}/tabs?$expand=teamsApp"
            )
            with open(os.path.join(ch_dir, "tabs.json"), "w") as f:
                json.dump(tabs, f, indent=2, default=str)
            self.stats["files_downloaded"] += 1
        except Exception as e:
            self.stats["errors"].append(f"tabs [{ch_name}]: {str(e)[:100]}")

        # Files metadata (from channel's SharePoint folder)
        try:
            folder = self._get(f"{self.GRAPH}/teams/{team_id}/channels/{ch_id}/filesFolder")
            if folder.get("id"):
                drive_id = folder.get("parentReference", {}).get("driveId")
                if drive_id:
                    files_dir = os.path.join(ch_dir, "files")
                    os.makedirs(files_dir, exist_ok=True)
                    file_items = self._paginate(
                        f"{self.GRAPH}/drives/{drive_id}/items/{folder['id']}/children?$top=200"
                    )
                    # Save index (not downloading actual file contents — SharePoint workload handles that)
                    index = [{
                        "id": f.get("id"),
                        "name": f.get("name"),
                        "size": f.get("size", 0),
                        "webUrl": f.get("webUrl"),
                        "lastModified": f.get("lastModifiedDateTime"),
                        "isFolder": "folder" in f,
                    } for f in file_items]
                    with open(os.path.join(files_dir, "_files_index.json"), "w") as f:
                        json.dump({
                            "drive_id": drive_id,
                            "folder_id": folder["id"],
                            "web_url": folder.get("webUrl"),
                            "items": index,
                        }, f, indent=2, default=str)
                    self.stats["files_downloaded"] += 1
        except Exception as e:
            self.stats["errors"].append(f"files [{ch_name}]: {str(e)[:100]}")

    def _safe_name(self, name: str) -> str:
        """Filesystem-safe name."""
        return "".join(c if c.isalnum() or c in "_-. " else "_" for c in name).strip()[:100]

    def _save_manifest(self, backup_path: str, teams: list):
        manifest = {
            **self.get_workload_metadata(),
            "teams_count": len(teams),
            "files_downloaded": self.stats["files_downloaded"],
            "targets_processed": self.stats["targets_processed"],
            "targets_failed": self.stats["targets_failed"],
            "errors": self.stats["errors"][:20],
        }
        with open(os.path.join(backup_path, "_workload_manifest.json"), "w") as f:
            json.dump(manifest, f, indent=2, default=str)
