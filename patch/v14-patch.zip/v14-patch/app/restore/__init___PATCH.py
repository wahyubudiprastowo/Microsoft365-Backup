"""
PATCH INSTRUCTIONS: app/restore/__init__.py

Add Teams restore support.
"""

# ═══════════════════════════════════════════════════════════════
# Add to imports at top:
# ═══════════════════════════════════════════════════════════════
from .teams import TeamsRestore


# ═══════════════════════════════════════════════════════════════
# Update RESTORE_REGISTRY dict:
# ═══════════════════════════════════════════════════════════════
RESTORE_REGISTRY = {
    "sharepoint": SharePointRestore,
    "onedrive": OneDriveRestore,
    "outlook": OutlookRestore,
    "teams": TeamsRestore,          # ← ADD THIS
}
