"""
Teams "Restore" (v14) — Export to human-readable formats.

IMPORTANT: Microsoft Graph API does NOT support importing chat messages
into Teams channels (except via special migration mode). Therefore, v14
"restore" for Teams actually EXPORTS the backup to browseable formats:

Modes:
- "export_html"  : Generate static HTML archive (channel-per-page)
- "export_json"  : Consolidate messages to a single JSON per team
- "export_txt"   : Plain text log per channel

Output location:
  For "new_location" mode: /backup/m365/{slug}/teams-exports/{team-name}/
  For "merge/overwrite": Same location, overwrite existing files
"""
import os
import json
from pathlib import Path
from datetime import datetime, timezone
from html import escape
from .base import BaseRestore

import logging
log = logging.getLogger("m365_backup")


class TeamsRestore(BaseRestore):
    WORKLOAD_NAME = "teams"

    # Note: "mode" parameter here means EXPORT FORMAT
    # overwrite = export_html + export_json (default)
    # merge = export_html only (skip if exists)
    # new_location = same as overwrite, but to different path

    def __init__(self, tenant, backup_path, export_format=None,
                 export_dir=None, **kwargs):
        """
        export_format: 'html' | 'json' | 'txt' | 'all'
        export_dir: Override output directory (default: siblings of backup_path)
        """
        super().__init__(tenant, backup_path, **kwargs)
        self.export_format = export_format or "all"
        # Default export dir: put next to backup folder
        if export_dir:
            self.export_dir = Path(export_dir)
        else:
            self.export_dir = self.backup_path.parent.parent / "teams-exports" / self.backup_path.name

    def restore(self) -> dict:
        """Actually: export the backup to browseable format."""
        self.stats["start_time"] = datetime.now(timezone.utc).isoformat()
        self.emit("restore_start", {"backup_path": str(self.backup_path)})

        try:
            os.makedirs(self.export_dir, exist_ok=True)
            log.info(f"Exporting Teams backup to: {self.export_dir}")

            for team_dir in self.backup_path.iterdir():
                if not team_dir.is_dir() or team_dir.name.startswith("_"):
                    continue

                self._check_control()
                team_name = team_dir.name
                self.emit("target_start", {"target_name": team_name})

                try:
                    team_export_dir = self.export_dir / team_name
                    os.makedirs(team_export_dir, exist_ok=True)
                    self._export_team(team_dir, team_export_dir)
                    self.stats["targets_processed"] += 1
                    self.emit("target_done", {"target_name": team_name, "status": "success"})
                except Exception as e:
                    self.stats["targets_failed"] += 1
                    self.stats["errors"].append(f"[{team_name}] {str(e)[:200]}")
                    self.emit("target_done", {"target_name": team_name, "status": "failed", "error": str(e)})

            # Master index
            self._write_master_index()
        except Exception as e:
            log.error(f"Teams export failed: {e}", exc_info=True)
            self.stats["errors"].append(f"Fatal: {e}")

        self.stats["end_time"] = datetime.now(timezone.utc).isoformat()
        self.stats["export_dir"] = str(self.export_dir)
        self.emit("restore_done", {"export_dir": str(self.export_dir)})
        return self.stats

    def _export_team(self, team_dir: Path, out_dir: Path):
        """Export one team's channels."""
        # Load team metadata
        meta_file = team_dir / "_team_metadata.json"
        team_meta = {}
        if meta_file.exists():
            try:
                team_meta = json.load(open(meta_file))
            except Exception:
                pass

        channels_dir = team_dir / "channels"
        if not channels_dir.exists():
            return

        team_name = team_meta.get("team_name", team_dir.name)
        channel_summaries = []

        # Export each channel
        for ch_dir in channels_dir.iterdir():
            if not ch_dir.is_dir():
                continue

            self._check_control()
            ch_name = ch_dir.name
            msg_file = ch_dir / "messages.json"
            if not msg_file.exists():
                continue

            try:
                messages = json.load(open(msg_file))
                total_msgs = len(messages) + sum(len(m.get("_replies", [])) for m in messages)
            except Exception as e:
                self.stats["errors"].append(f"{ch_name}: {e}")
                continue

            # HTML export
            if self.export_format in ("html", "all"):
                html_path = out_dir / f"{ch_name}.html"
                self._write_channel_html(html_path, team_name, ch_name, messages)
                self.stats["items_processed"] += 1

            # TXT export
            if self.export_format in ("txt", "all"):
                txt_path = out_dir / f"{ch_name}.txt"
                self._write_channel_txt(txt_path, team_name, ch_name, messages)
                self.stats["items_processed"] += 1

            # JSON (consolidated, prettified)
            if self.export_format in ("json", "all"):
                json_path = out_dir / f"{ch_name}.json"
                self._write_channel_json(json_path, messages)
                self.stats["items_processed"] += 1

            channel_summaries.append({
                "name": ch_name,
                "message_count": total_msgs,
                "html_file": f"{ch_name}.html",
            })
            self.emit("channel_exported", {"current_file": f"{team_name}/{ch_name}"})

        # Team-level index.html
        self._write_team_index(out_dir, team_name, team_meta, channel_summaries)

    def _write_channel_html(self, path: Path, team_name: str, ch_name: str, messages: list):
        """Generate HTML archive of channel messages."""
        html = f"""<!DOCTYPE html>
<html lang="en"><head>
<meta charset="UTF-8">
<title>{escape(team_name)} · {escape(ch_name)}</title>
<style>
  body {{ font-family: -apple-system, "Segoe UI", sans-serif; max-width: 900px; margin: 0 auto; padding: 20px; background: #f5f5f7; color: #1a1a1a; }}
  h1 {{ background: linear-gradient(135deg, #464eb8, #6264a7); color: #fff; padding: 20px; border-radius: 12px; margin: 0 0 20px; }}
  h2 {{ color: #6264a7; margin-top: 30px; }}
  .msg {{ background: #fff; margin: 10px 0; padding: 14px; border-radius: 10px; border-left: 4px solid #6264a7; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }}
  .msg-header {{ font-size: 12px; color: #666; margin-bottom: 6px; }}
  .msg-header strong {{ color: #1a1a1a; }}
  .msg-body {{ font-size: 14px; line-height: 1.5; }}
  .reply {{ margin-left: 30px; border-left-color: #a8a9d0; background: #fafaff; }}
  .subject {{ font-weight: 600; color: #464eb8; margin-bottom: 4px; }}
  .attach {{ font-size: 12px; color: #0078d4; margin-top: 6px; }}
</style>
</head><body>
<h1>💬 {escape(team_name)} · #{escape(ch_name)}</h1>
<p style="color:#666;font-size:13px;">Exported by M365 Backup System · {datetime.now().strftime("%Y-%m-%d %H:%M:%S")} · {len(messages)} top-level messages</p>
"""

        for msg in messages:
            html += self._render_message_html(msg)
            for reply in msg.get("_replies", []):
                html += self._render_message_html(reply, is_reply=True)

        html += "</body></html>"

        with open(path, "w", encoding="utf-8") as f:
            f.write(html)

    def _render_message_html(self, msg: dict, is_reply: bool = False) -> str:
        cls = "msg reply" if is_reply else "msg"
        sender = msg.get("from", {})
        user_info = sender.get("user") or {}
        name = user_info.get("displayName") or sender.get("application", {}).get("displayName") or "Unknown"
        ts = msg.get("createdDateTime", "")
        subject = msg.get("subject", "")
        body = msg.get("body", {}) or {}
        content = body.get("content", "")
        content_type = body.get("contentType", "html")
        
        # If plain text, escape and wrap; if html, keep as-is (but limit tags)
        if content_type == "text":
            content_html = f"<div>{escape(content).replace(chr(10), '<br>')}</div>"
        else:
            content_html = content  # Trust as-is (Teams provides sanitized HTML)

        attachments = msg.get("attachments", [])
        attach_html = ""
        if attachments:
            attach_html = '<div class="attach">📎 Attachments: ' + ", ".join(
                escape(a.get("name", "unknown")) for a in attachments
            ) + "</div>"

        subject_html = f'<div class="subject">{escape(subject)}</div>' if subject else ""
        
        return f"""
<div class="{cls}">
  <div class="msg-header">
    <strong>{escape(name)}</strong> · {escape(ts)}
  </div>
  {subject_html}
  <div class="msg-body">{content_html}</div>
  {attach_html}
</div>
"""

    def _write_channel_txt(self, path: Path, team_name: str, ch_name: str, messages: list):
        """Generate plain text log."""
        lines = [
            f"=" * 70,
            f"Team: {team_name}",
            f"Channel: #{ch_name}",
            f"Exported: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"Total messages: {len(messages)}",
            f"=" * 70,
            "",
        ]

        def render_msg(msg, indent=0):
            prefix = "    " * indent
            sender = msg.get("from", {}) or {}
            name = (sender.get("user") or {}).get("displayName") or "Unknown"
            ts = msg.get("createdDateTime", "")
            subject = msg.get("subject", "")
            body = (msg.get("body") or {}).get("content", "")
            # Strip HTML tags roughly
            import re
            body_text = re.sub(r'<[^>]+>', '', body)
            
            out = [f"{prefix}[{ts}] {name}"]
            if subject:
                out.append(f"{prefix}Subject: {subject}")
            out.append(f"{prefix}{body_text[:500]}")
            out.append("")
            return "\n".join(out)

        for msg in messages:
            lines.append(render_msg(msg))
            for reply in msg.get("_replies", []):
                lines.append(render_msg(reply, indent=1))

        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

    def _write_channel_json(self, path: Path, messages: list):
        """Copy JSON, prettified."""
        with open(path, "w", encoding="utf-8") as f:
            json.dump(messages, f, indent=2, default=str, ensure_ascii=False)

    def _write_team_index(self, out_dir: Path, team_name: str, team_meta: dict,
                          channels: list):
        """Team-level index.html listing all channels."""
        members = team_meta.get("members", [])
        owners = team_meta.get("owners", [])

        html = f"""<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>{escape(team_name)}</title>
<style>
  body {{ font-family: -apple-system, "Segoe UI", sans-serif; max-width: 900px; margin: 0 auto; padding: 20px; background: #f5f5f7; }}
  h1 {{ background: linear-gradient(135deg, #464eb8, #6264a7); color: #fff; padding: 20px; border-radius: 12px; margin: 0 0 20px; }}
  .card {{ background: #fff; padding: 16px; border-radius: 10px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); margin: 10px 0; }}
  a {{ color: #464eb8; text-decoration: none; font-weight: 600; }}
  a:hover {{ text-decoration: underline; }}
  ul {{ list-style: none; padding: 0; }}
  .badge {{ background: #6264a7; color: #fff; padding: 2px 8px; border-radius: 6px; font-size: 11px; margin-left: 6px; }}
</style></head><body>
<h1>💬 {escape(team_name)}</h1>

<div class="card">
  <h3>📋 Overview</h3>
  <p><strong>Description:</strong> {escape(team_meta.get("description", "—") or "—")}</p>
  <p><strong>Visibility:</strong> {escape(team_meta.get("visibility", "—") or "—")}</p>
  <p><strong>Members:</strong> {len(members)}</p>
  <p><strong>Owners:</strong> {len(owners)}</p>
</div>

<div class="card">
  <h3>📂 Channels ({len(channels)})</h3>
  <ul>"""
        for ch in channels:
            html += f'    <li><a href="{escape(ch["html_file"])}">#{escape(ch["name"])}</a><span class="badge">{ch["message_count"]} msgs</span></li>\n'
        html += """  </ul>
</div>

<div class="card">
  <h3>👥 Members</h3>
  <ul>"""
        for m in members[:50]:
            html += f'    <li>{escape(m.get("displayName") or "")} · <em>{escape(m.get("email") or "")}</em></li>\n'
        if len(members) > 50:
            html += f'    <li><em>...and {len(members) - 50} more</em></li>\n'
        html += """  </ul>
</div>
</body></html>"""

        with open(out_dir / "index.html", "w", encoding="utf-8") as f:
            f.write(html)

    def _write_master_index(self):
        """Root-level index listing all teams."""
        teams = [d for d in self.export_dir.iterdir()
                 if d.is_dir() and not d.name.startswith("_")]

        html = f"""<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Teams Backup Export</title>
<style>
  body {{ font-family: -apple-system, "Segoe UI", sans-serif; max-width: 900px; margin: 0 auto; padding: 20px; background: #f5f5f7; }}
  h1 {{ background: linear-gradient(135deg, #464eb8, #6264a7); color: #fff; padding: 24px; border-radius: 12px; margin: 0 0 20px; }}
  .card {{ background: #fff; padding: 16px; border-radius: 10px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); margin: 10px 0; }}
  a {{ color: #464eb8; text-decoration: none; font-weight: 600; }}
</style></head><body>
<h1>💬 Teams Backup Export</h1>
<p style="color:#666;">Tenant: <strong>{escape(self.tenant.get('name', 'Unknown'))}</strong> · Exported: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>

<div class="card">
  <h3>Teams ({len(teams)})</h3>
  <ul>"""
        for t in teams:
            html += f'    <li><a href="{escape(t.name)}/index.html">💬 {escape(t.name)}</a></li>\n'
        html += """  </ul>
</div>
</body></html>"""

        with open(self.export_dir / "index.html", "w", encoding="utf-8") as f:
            f.write(html)

    def dry_run(self) -> dict:
        result = {
            "workload": "teams",
            "mode": "export_only",
            "teams_in_backup": 0,
            "channels_in_backup": 0,
            "messages_in_backup": 0,
            "export_dir": str(self.export_dir),
            "note": "Teams does not support direct message re-import via Graph API. Restore = export to HTML/JSON.",
        }
        if not self.backup_path.exists():
            result["error"] = f"Backup not found: {self.backup_path}"
            return result
        
        for team_dir in self.backup_path.iterdir():
            if not team_dir.is_dir() or team_dir.name.startswith("_"):
                continue
            result["teams_in_backup"] += 1
            ch_dir = team_dir / "channels"
            if ch_dir.exists():
                for c in ch_dir.iterdir():
                    if c.is_dir():
                        result["channels_in_backup"] += 1
                        msg_file = c / "messages.json"
                        if msg_file.exists():
                            try:
                                msgs = json.load(open(msg_file))
                                result["messages_in_backup"] += len(msgs)
                                result["messages_in_backup"] += sum(
                                    len(m.get("_replies", [])) for m in msgs
                                )
                            except Exception:
                                pass
        return result
