# 🛠️ Troubleshooting — v14 Teams

## Common Issues

### 1. Backup Returns 0 Teams

**Symptom:** Teams backup completes but `teams_count = 0`

**Causes:**
- Tenant has no Teams (unlikely for Digiserve)
- Missing permission `Team.ReadBasic.All`
- Filter query error

**Solutions:**
```bash
# Test directly
docker exec m365-backup-web python3 -c "
from app.tenant_manager import TenantManager
from app.workloads.teams import TeamsWorkload
tm = TenantManager()
tenant = tm.get_active_tenant()
w = TeamsWorkload(tenant)
teams = w.list_targets()
print(f'Found {len(teams)} teams')
for t in teams[:5]:
    print(f'  {t[\"name\"]}')
"
```

### 2. Messages Missing from Backup

**Symptom:** `messages.json` files empty or missing

**Cause:** Missing `ChannelMessage.Read.All` permission (needs admin consent)

**Solution:**
1. Azure Portal → App Registrations → API permissions
2. Add `ChannelMessage.Read.All` (Application)
3. Grant admin consent
4. Wait 5-10 min, retry

### 3. Replies Not Captured

**Symptom:** Messages have `_replies: []` but Teams shows replies

**Cause:** Race condition or partial permissions

**Solution:**
- Check worker logs for `messages [channel-name]` errors
- Verify `ChannelMessage.Read.All` (not just `Read.Group`)
- Re-run backup — v14 engine will pick up any missed replies

### 4. HTML Export Looks Empty

**Symptom:** Opening `channel.html` shows only header, no messages

**Cause:** Empty channel or JSON parse error

**Solutions:**
```bash
# Check the JSON file exists and has content
cat /media/Storage/Container/M365/data/*/teams/backup_XXX/{team}/channels/{channel}/messages.json | head -100

# Check for parse errors
docker logs m365-backup-worker | grep -i "channel"
```

### 5. Rate Limit Hit (429)

**Symptom:** Backup takes very long, worker logs show many "Rate limited" warnings

**This is normal.** Engine auto-retries with backoff. But if it's excessive:

**Solutions:**
- Split backup into smaller runs (backup one team at a time via API)
- Add throttling delay (edit `base.py` in workloads)
- Consider Graph API Premium (higher limits)

### 6. Teams Not in Workloads UI

**Symptom:** `/workloads` page doesn't show Teams toggle

**Cause:** `WORKLOAD_METADATA["teams"]` still has old placeholder

**Solution:** Update `app/workloads/__init__.py` per DEPLOYMENT.md Step 5.

### 7. HTML Archive Won't Load

**Symptom:** Browser shows blank or error on `index.html`

**Cause:** Encoding issue

**Solution:**
```bash
# Force UTF-8 encoding when serving
python3 -c "
import http.server, socketserver, os
os.chdir('/media/Storage/Container/M365/data/digiserve-by-telkom/teams-exports/backup_XXX')
socketserver.TCPServer(('', 8080), http.server.SimpleHTTPRequestHandler).serve_forever()
"
```

### 8. Archive Not Browseable Externally

**Symptom:** Can access via file:// but not shared with others

**Solutions:**
- Copy to shared network drive (SMB/NFS)
- Compress: `tar -czf teams-archive.tar.gz teams-exports/`
- Upload compressed archive to SharePoint / cloud

## Verify Deployment

Quick health check:
```bash
docker exec m365-backup-web python3 -c "
from app.workloads import WORKLOAD_REGISTRY, WORKLOAD_METADATA
assert 'teams' in WORKLOAD_REGISTRY, 'Teams NOT registered in workloads!'
assert 'teams' in WORKLOAD_METADATA, 'Teams metadata missing!'
print('✅ Teams workload backup: registered')

from app.restore import RESTORE_REGISTRY
assert 'teams' in RESTORE_REGISTRY, 'Teams NOT registered in restore!'
print('✅ Teams workload restore: registered')

print('v14 deployment: OK')
"
```
