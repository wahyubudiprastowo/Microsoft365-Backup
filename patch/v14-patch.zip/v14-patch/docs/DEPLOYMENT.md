# 🚀 v14 Deployment Guide

## Prerequisites
- v10, v11, v12, v13 already applied and running
- ZimaOS host with Docker
- Backup folder: `/media/Storage/Container/M365/data/`

## Step 1: Update Azure AD Permissions

Add these APPLICATION permissions to your App Registration:

| Permission | Purpose |
|------------|---------|
| `Team.ReadBasic.All` | List teams |
| `Channel.ReadBasic.All` | List channels |
| `ChannelMessage.Read.All` | Read messages + replies |
| `ChannelSettings.Read.All` | Read settings |
| `TeamMember.Read.All` | Read members |
| `Group.Read.All` | Already present (from OneDrive) |

**Then click "Grant admin consent"** and wait 5-10 minutes.

## Step 2: Backup Current State
```bash
cd /media/Storage/Container/M365
DOCKER_CONFIG=/media/Storage/Container/M365/.docker docker compose down
tar -czf /tmp/m365-pre-v14.tar.gz app config
```

## Step 3: Upload & Extract Patch
```bash
cd /media/Storage/Container/M365
unzip v14-patch.zip
```

## Step 4: Copy Files
```bash
# Backup workload
cp v14-patch/app/workloads/teams.py app/workloads/

# Restore/export workload
cp v14-patch/app/restore/teams.py app/restore/
```

## Step 5: Edit `app/workloads/__init__.py`

Open the file and:

1. Add import at top:
   ```python
   from .teams import TeamsWorkload
   ```

2. Add to `WORKLOAD_REGISTRY`:
   ```python
   WORKLOAD_REGISTRY = {
       "sharepoint": SharePointWorkload,
       "onedrive": OneDriveWorkload,
       "outlook": OutlookWorkload,
       "teams": TeamsWorkload,   # ← ADD THIS
   }
   ```

3. Update `WORKLOAD_METADATA["teams"]` (was placeholder in v10):
   ```python
   "teams": {
       "name": "Microsoft Teams",
       "description": "Teams, channels, messages, replies, files",
       "icon": "bi-microsoft-teams",
       "color": "#6264a7",
       "required_scopes": [
           "Team.ReadBasic.All",
           "Channel.ReadBasic.All",
           "ChannelMessage.Read.All",
           "ChannelSettings.Read.All",
           "TeamMember.Read.All",
           "Files.Read.All",
       ],
   },
   ```

## Step 6: Edit `app/restore/__init__.py`

1. Add import at top:
   ```python
   from .teams import TeamsRestore
   ```

2. Update `RESTORE_REGISTRY`:
   ```python
   RESTORE_REGISTRY = {
       "sharepoint": SharePointRestore,
       "onedrive": OneDriveRestore,
       "outlook": OutlookRestore,
       "teams": TeamsRestore,   # ← ADD THIS
   }
   ```

## Step 7: Update `tasks.py` (if needed)

The existing v10 tasks.py had this check:
```python
workloads = [w for w in workloads if w in WORKLOAD_METADATA and w != "teams"]
```

**Remove the `and w != "teams"` filter** to allow Teams backup:
```python
workloads = [w for w in workloads if w in WORKLOAD_METADATA]
```

## Step 8: Enable Teams for a Tenant

Via web UI:
1. Open `/workloads`
2. Toggle **Microsoft Teams** to ON

Or edit config.json directly:
```json
"workloads_enabled": ["sharepoint", "onedrive", "outlook", "teams"]
```

## Step 9: Rebuild & Start
```bash
cd /media/Storage/Container/M365
export DOCKER_CONFIG=/media/Storage/Container/M365/.docker
docker compose build
docker compose up -d
sleep 15
docker compose logs -f worker
```

## Step 10: Verify

### Test backup:
```bash
curl -X POST http://localhost:5055/api/v2/backup/start \
  -H "Content-Type: application/json" \
  -d '{"workloads": ["teams"]}'
```

### Check folder structure:
```bash
ls /media/Storage/Container/M365/data/*/teams/
# Should show: backup_YYYYMMDD_HHMMSS/
```

### Test export:
1. Open `/restore-v2`
2. Select tenant + workload=Teams
3. Select Teams backup
4. Click Preview → shows counts
5. Click Start Restore → generates HTML archive
6. Result folder: `/media/Storage/Container/M365/data/{slug}/teams-exports/`

### Browse archive:
Open in file browser (or use Python to serve):
```bash
cd /media/Storage/Container/M365/data/digiserve-by-telkom/teams-exports/backup_XXX
python3 -m http.server 8000
# Then browse http://<zima-ip>:8000
```

## Rollback

```bash
cd /media/Storage/Container/M365
docker compose down
tar -xzf /tmp/m365-pre-v14.tar.gz -C /media/Storage/Container/M365/
docker compose up -d
```
