"""OneDrive for Business workload — backup user files."""
import os
import json
from datetime import datetime, timezone
from app.workloads.base import BaseWorkload


class OneDriveWorkload(BaseWorkload):
    workload_type = "onedrive"

    def list_targets(self):
        """List all users with OneDrive."""
        users = []
        try:
            for user in self._paginate(f"{self.GRAPH}/users?$select=id,displayName,userPrincipalName,mail"):
                users.append({
                    "id": user["id"],
                    "name": user.get("displayName", ""),
                    "email": user.get("userPrincipalName") or user.get("mail", ""),
                    "type": "user_onedrive",
                })
        except Exception as e:
            return [{"error": str(e)}]
        return users

    def backup_user(self, user: dict, dest_dir: str, progress_callback=None):
        """Backup a single user's OneDrive."""
        stats = {"files_downloaded": 0, "bytes_downloaded": 0, "errors": []}
        upn = user.get("email") or user.get("userPrincipalName")
        if not upn:
            stats["errors"].append("Missing user email")
            return stats

        user_dir = os.path.join(dest_dir, upn.replace("@", "_at_"))
        os.makedirs(user_dir, exist_ok=True)

        try:
            # Get user's drive
            drive = self._get(f"{self.GRAPH}/users/{upn}/drive")
            drive_id = drive["id"]

            # Recursively backup
            for item in self._list_recursive(drive_id):
                if "file" not in item:
                    continue
                try:
                    rel = item.get("parentReference", {}).get("path", "").split("root:")[-1].lstrip("/")
                    dest = os.path.join(user_dir, rel, item["name"])
                    fsize = item.get("size", 0)
                    dl_url = f"{self.GRAPH}/drives/{drive_id}/items/{item['id']}/content"
                    self._download(dl_url, dest, fsize)
                    stats["files_downloaded"] += 1
                    stats["bytes_downloaded"] += fsize
                    if progress_callback:
                        progress_callback("file_done", {"file": item["name"],
                                                        "user": upn, **stats})
                except Exception as e:
                    stats["errors"].append(f"{item.get('name', '?')}: {e}")

            meta = {
                "user": upn, "drive_id": drive_id,
                "backup_time": datetime.now(timezone.utc).isoformat(),
                "stats": stats,
            }
            with open(os.path.join(user_dir, "_metadata.json"), "w") as f:
                json.dump(meta, f, indent=2)
        except Exception as e:
            stats["errors"].append(f"User {upn}: {e}")

        return stats

    def _list_recursive(self, drive_id, folder_id="root"):
        url = f"{self.GRAPH}/drives/{drive_id}/items/{folder_id}/children"
        for item in self._paginate(url):
            if "folder" in item:
                yield from self._list_recursive(drive_id, item["id"])
            elif "file" in item:
                yield item

    def backup(self, dest_root: str, users: list = None, progress_callback=None):
        all_stats = {"users_backed_up": 0, "total_files": 0, "total_bytes": 0,
                     "errors": []}
        # If no users specified, get all
        targets = users if users else self.list_targets()
        for user in targets:
            if "error" in user:
                continue
            if progress_callback:
                progress_callback("user_start", {"user": user.get("email", "")})
            stats = self.backup_user(user, dest_root, progress_callback)
            all_stats["users_backed_up"] += 1
            all_stats["total_files"] += stats["files_downloaded"]
            all_stats["total_bytes"] += stats["bytes_downloaded"]
            all_stats["errors"].extend(stats["errors"])
        return all_stats
