"""SharePoint Online workload — backup sites and document libraries."""
import os
import json
import time
from datetime import datetime, timezone
from app.workloads.base import BaseWorkload


class SharePointWorkload(BaseWorkload):
    workload_type = "sharepoint"

    def __init__(self, tenant_config):
        super().__init__(tenant_config)
        self.sp_host = tenant_config.get("sharepoint_host", "")

    def list_targets(self):
        """List all sites in the tenant."""
        try:
            sites = []
            for site in self._paginate(f"{self.GRAPH}/sites?search=*"):
                if site.get("webUrl"):
                    sites.append({
                        "id": site["id"],
                        "name": site.get("displayName", site.get("name", "")),
                        "url": site["webUrl"],
                        "type": "site",
                    })
            return sites
        except Exception as e:
            return [{"error": str(e)}]

    def get_site_id(self, site_path: str):
        url = f"{self.GRAPH}/sites/{self.sp_host}:/{site_path}" if site_path \
              else f"{self.GRAPH}/sites/{self.sp_host}"
        return self._get(url)["id"]

    def backup_site(self, site_info: dict, dest_dir: str, progress_callback=None):
        """Backup a single site."""
        name = site_info["name"]
        path = site_info.get("path", "")
        stats = {"files_downloaded": 0, "bytes_downloaded": 0, "errors": []}

        try:
            site_id = self.get_site_id(path)
            drives = self._get(f"{self.GRAPH}/sites/{site_id}/drives").get("value", [])
            
            site_dir = os.path.join(dest_dir, name.replace(" ", "_"))
            os.makedirs(site_dir, exist_ok=True)

            for drive in drives:
                drive_id = drive["id"]
                lib_name = drive["name"]
                self._backup_drive(drive_id, lib_name, site_dir, stats,
                                   progress_callback)

            # Save metadata
            meta = {
                "site_name": name, "site_path": path, "site_id": site_id,
                "backup_time": datetime.now(timezone.utc).isoformat(),
                "drives": [{"id": d["id"], "name": d["name"]} for d in drives],
            }
            with open(os.path.join(site_dir, "_metadata.json"), "w") as f:
                json.dump(meta, f, indent=2)

        except Exception as e:
            stats["errors"].append(f"{name}: {e}")
        return stats

    def _backup_drive(self, drive_id, lib_name, parent_dir, stats, progress_cb):
        """Recursive drive backup."""
        for item in self._list_items_recursive(drive_id):
            if "file" not in item:
                continue
            try:
                rel = item.get("parentReference", {}).get("path", "").split("root:")[-1].lstrip("/")
                dest = os.path.join(parent_dir, lib_name, rel, item["name"])
                fsize = item.get("size", 0)
                dl_url = f"{self.GRAPH}/drives/{drive_id}/items/{item['id']}/content"
                self._download(dl_url, dest, fsize)
                stats["files_downloaded"] += 1
                stats["bytes_downloaded"] += fsize
                if progress_cb:
                    progress_cb("file_done", {"file": item["name"],
                                              "size": fsize, **stats})
            except Exception as e:
                stats["errors"].append(f"{item.get('name', '?')}: {e}")

    def _list_items_recursive(self, drive_id, folder_id="root"):
        url = f"{self.GRAPH}/drives/{drive_id}/items/{folder_id}/children"
        for item in self._paginate(url):
            if "folder" in item:
                yield from self._list_items_recursive(drive_id, item["id"])
            elif "file" in item:
                yield item

    def backup(self, dest_root: str, sites: list = None, progress_callback=None):
        """Backup all enabled sites."""
        sites = sites or []
        all_stats = {"sites_backed_up": 0, "total_files": 0, "total_bytes": 0,
                     "errors": []}
        for site in sites:
            if not site.get("enabled", True):
                continue
            if progress_callback:
                progress_callback("site_start", {"site": site["name"]})
            stats = self.backup_site(site, dest_root, progress_callback)
            all_stats["sites_backed_up"] += 1
            all_stats["total_files"] += stats["files_downloaded"]
            all_stats["total_bytes"] += stats["bytes_downloaded"]
            all_stats["errors"].extend(stats["errors"])
            if progress_callback:
                progress_callback("site_done", {"site": site["name"], **stats})
        return all_stats
