"""Base class for M365 backup workloads."""
import os
import json
import logging
import requests
import time
from datetime import datetime, timezone
from pathlib import Path
import msal

log = logging.getLogger("spo_backup")


class BaseWorkload:
    """Base class — all workload modules inherit from this."""
    
    GRAPH = "https://graph.microsoft.com/v1.0"
    workload_type = "base"

    def __init__(self, tenant_config: dict):
        self.tenant = tenant_config
        self.tenant_id = tenant_config["tenant_id"]
        self.client_id = tenant_config["client_id"]
        self.client_secret = tenant_config["client_secret"]
        self.session = requests.Session()
        self._token_cache = None
        self._token_expiry = 0

    def get_token(self) -> str:
        """Get OAuth2 token (cached)."""
        if self._token_cache and time.time() < self._token_expiry:
            return self._token_cache
        app = msal.ConfidentialClientApplication(
            self.client_id,
            authority=f"https://login.microsoftonline.com/{self.tenant_id}",
            client_credential=self.client_secret,
        )
        result = app.acquire_token_for_client(
            scopes=["https://graph.microsoft.com/.default"]
        )
        if "access_token" not in result:
            raise Exception(f"Auth failed: {result.get('error_description', 'Unknown')}")
        self._token_cache = result["access_token"]
        # Token typically valid 1 hour
        self._token_expiry = time.time() + 3500
        return self._token_cache

    def _headers(self):
        return {"Authorization": f"Bearer {self.get_token()}",
                "Content-Type": "application/json"}

    def _get(self, url, params=None, max_retry=3):
        """GET with retry on 429."""
        for attempt in range(max_retry):
            try:
                r = self.session.get(url, headers=self._headers(),
                                     params=params, timeout=60)
                if r.status_code == 429:
                    time.sleep(int(r.headers.get("Retry-After", 30)))
                    continue
                r.raise_for_status()
                return r.json()
            except Exception:
                if attempt == max_retry - 1:
                    raise
        return {}

    def _paginate(self, url, params=None):
        """Generator that yields all items across pages."""
        while url:
            data = self._get(url, params)
            for item in data.get("value", []):
                yield item
            url = data.get("@odata.nextLink")
            params = None

    def _download(self, url, dest, size_hint=0, progress_cb=None):
        """Download a file from Graph URL."""
        if os.path.exists(dest) and size_hint > 0:
            if os.path.getsize(dest) == size_hint:
                return size_hint  # Already downloaded
        
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        r = self.session.get(url, headers=self._headers(),
                             stream=True, timeout=300)
        r.raise_for_status()
        
        bytes_written = 0
        tmp = dest + ".tmp"
        with open(tmp, "wb") as f:
            for chunk in r.iter_content(chunk_size=65536):
                if chunk:
                    f.write(chunk)
                    bytes_written += len(chunk)
                    if progress_cb:
                        progress_cb(len(chunk))
        os.replace(tmp, dest)
        return bytes_written

    def backup(self, dest_root: str, progress_callback=None):
        """Run backup. Must be implemented by subclass."""
        raise NotImplementedError

    def list_targets(self):
        """List available backup targets (sites/users/mailboxes).
           Subclass should override."""
        return []

    def emit(self, evt: str, data: dict, callback=None):
        """Emit progress event."""
        if callback:
            callback(evt, {"workload": self.workload_type, **data})
