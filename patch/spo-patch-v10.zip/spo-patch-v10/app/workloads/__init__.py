"""M365 Workloads — pluggable backup modules per service."""
from app.workloads.base import BaseWorkload
from app.workloads.sharepoint import SharePointWorkload
from app.workloads.onedrive import OneDriveWorkload
from app.workloads.outlook import OutlookWorkload

WORKLOADS = {
    "sharepoint": SharePointWorkload,
    "onedrive": OneDriveWorkload,
    "outlook": OutlookWorkload,
}

WORKLOAD_META = {
    "sharepoint": {
        "name": "SharePoint Online",
        "icon": "bi-globe2",
        "color": "var(--primary)",
        "description": "Sites, document libraries, lists",
        "required_scopes": ["Sites.Read.All", "Files.Read.All"],
    },
    "onedrive": {
        "name": "OneDrive for Business",
        "icon": "bi-cloud-fill",
        "color": "var(--accent)",
        "description": "User personal files & folders",
        "required_scopes": ["Files.Read.All", "User.Read.All"],
    },
    "outlook": {
        "name": "Outlook / Exchange",
        "icon": "bi-envelope-fill",
        "color": "var(--warning)",
        "description": "Email, calendar, contacts",
        "required_scopes": ["Mail.Read", "Calendars.Read", "Contacts.Read"],
    },
    "teams": {
        "name": "Teams Chats",
        "icon": "bi-chat-dots-fill",
        "color": "#7c3aed",
        "description": "Channel messages & chat history",
        "required_scopes": ["ChannelMessage.Read.All"],
    },
}


def get_workload(workload_type: str, tenant_config: dict):
    """Factory function — returns a workload instance for a tenant."""
    cls = WORKLOADS.get(workload_type)
    if not cls:
        raise ValueError(f"Unknown workload: {workload_type}")
    return cls(tenant_config)
