"""Outlook workload — backup mail, calendar, contacts."""
import os
import json
from datetime import datetime, timezone
from app.workloads.base import BaseWorkload


class OutlookWorkload(BaseWorkload):
    workload_type = "outlook"

    def list_targets(self):
        """List all users with mailbox."""
        users = []
        try:
            for user in self._paginate(f"{self.GRAPH}/users?$select=id,displayName,userPrincipalName,mail"):
                if user.get("mail"):
                    users.append({
                        "id": user["id"],
                        "name": user.get("displayName", ""),
                        "email": user.get("userPrincipalName") or user["mail"],
                        "type": "user_mailbox",
                    })
        except Exception as e:
            return [{"error": str(e)}]
        return users

    def backup_user(self, user: dict, dest_dir: str, progress_callback=None):
        """Backup mail + calendar + contacts for a user."""
        upn = user.get("email") or user.get("userPrincipalName")
        stats = {"emails": 0, "events": 0, "contacts": 0, "errors": []}
        if not upn:
            stats["errors"].append("Missing email")
            return stats

        user_dir = os.path.join(dest_dir, upn.replace("@", "_at_"))
        mail_dir = os.path.join(user_dir, "mail")
        cal_dir = os.path.join(user_dir, "calendar")
        contacts_dir = os.path.join(user_dir, "contacts")
        os.makedirs(mail_dir, exist_ok=True)
        os.makedirs(cal_dir, exist_ok=True)
        os.makedirs(contacts_dir, exist_ok=True)

        # 1. Mail
        try:
            for msg in self._paginate(
                f"{self.GRAPH}/users/{upn}/messages?$top=50"
            ):
                msg_file = os.path.join(mail_dir, f"{msg['id']}.json")
                with open(msg_file, "w") as f:
                    json.dump(msg, f, indent=2, default=str)
                stats["emails"] += 1
                if progress_callback and stats["emails"] % 10 == 0:
                    progress_callback("mail_progress", {"user": upn, **stats})
        except Exception as e:
            stats["errors"].append(f"Mail error: {e}")

        # 2. Calendar events
        try:
            for evt in self._paginate(
                f"{self.GRAPH}/users/{upn}/events?$top=50"
            ):
                evt_file = os.path.join(cal_dir, f"{evt['id']}.json")
                with open(evt_file, "w") as f:
                    json.dump(evt, f, indent=2, default=str)
                stats["events"] += 1
        except Exception as e:
            stats["errors"].append(f"Calendar error: {e}")

        # 3. Contacts
        try:
            for c in self._paginate(
                f"{self.GRAPH}/users/{upn}/contacts?$top=50"
            ):
                c_file = os.path.join(contacts_dir, f"{c['id']}.json")
                with open(c_file, "w") as f:
                    json.dump(c, f, indent=2, default=str)
                stats["contacts"] += 1
        except Exception as e:
            stats["errors"].append(f"Contacts error: {e}")

        meta = {
            "user": upn,
            "backup_time": datetime.now(timezone.utc).isoformat(),
            "stats": stats,
        }
        with open(os.path.join(user_dir, "_metadata.json"), "w") as f:
            json.dump(meta, f, indent=2)
        return stats

    def backup(self, dest_root: str, users: list = None, progress_callback=None):
        all_stats = {"users_backed_up": 0, "total_emails": 0, "total_events": 0,
                     "total_contacts": 0, "errors": []}
        targets = users if users else self.list_targets()
        for user in targets:
            if "error" in user:
                continue
            if progress_callback:
                progress_callback("user_start", {"user": user.get("email", "")})
            stats = self.backup_user(user, dest_root, progress_callback)
            all_stats["users_backed_up"] += 1
            all_stats["total_emails"] += stats["emails"]
            all_stats["total_events"] += stats["events"]
            all_stats["total_contacts"] += stats["contacts"]
            all_stats["errors"].extend(stats["errors"])
        return all_stats
