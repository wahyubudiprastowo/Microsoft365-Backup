"""Restore Manager — manages restore jobs with multiple modes."""
import os
import json
import uuid
import logging
import time
from datetime import datetime, timezone
from pathlib import Path
import requests

log = logging.getLogger("spo_backup")


class RestoreJob:
    """Represents a single restore job."""
    
    MODE_OVERWRITE = "overwrite"
    MODE_MERGE = "merge"
    MODE_NEW_LOCATION = "new_location"

    STATUS_QUEUED = "queued"
    STATUS_RUNNING = "running"
    STATUS_COMPLETED = "completed"
    STATUS_FAILED = "failed"
    STATUS_CANCELLED = "cancelled"

    def __init__(self, **kwargs):
        self.id = kwargs.get("id", str(uuid.uuid4()))
        self.tenant_id = kwargs.get("tenant_id")
        self.tenant_name = kwargs.get("tenant_name", "")
        self.workload = kwargs.get("workload", "sharepoint")
        self.source_backup = kwargs.get("source_backup", "")
        self.target_site = kwargs.get("target_site", "")
        self.target_name = kwargs.get("target_name", "")
        self.target_location = kwargs.get("target_location", "")  # for NEW_LOCATION
        self.mode = kwargs.get("mode", self.MODE_MERGE)
        self.status = kwargs.get("status", self.STATUS_QUEUED)
        self.progress = kwargs.get("progress", 0)
        self.files_total = kwargs.get("files_total", 0)
        self.files_done = kwargs.get("files_done", 0)
        self.bytes_total = kwargs.get("bytes_total", 0)
        self.bytes_done = kwargs.get("bytes_done", 0)
        self.errors = kwargs.get("errors", [])
        self.started_at = kwargs.get("started_at")
        self.finished_at = kwargs.get("finished_at")
        self.task_id = kwargs.get("task_id")  # Celery task ID

    def to_dict(self):
        return {
            "id": self.id, "tenant_id": self.tenant_id,
            "tenant_name": self.tenant_name, "workload": self.workload,
            "source_backup": self.source_backup, "target_site": self.target_site,
            "target_name": self.target_name, "target_location": self.target_location,
            "mode": self.mode, "status": self.status, "progress": self.progress,
            "files_total": self.files_total, "files_done": self.files_done,
            "bytes_total": self.bytes_total, "bytes_done": self.bytes_done,
            "errors": self.errors[:10],
            "started_at": self.started_at, "finished_at": self.finished_at,
            "task_id": self.task_id,
        }


class RestoreManager:
    """Manage restore jobs."""

    def __init__(self, jobs_dir: str = "/app/logs/restore_jobs"):
        self.jobs_dir = Path(jobs_dir)
        self.jobs_dir.mkdir(parents=True, exist_ok=True)

    def _job_file(self, job_id: str) -> Path:
        return self.jobs_dir / f"{job_id}.json"

    def list_jobs(self, limit: int = 50) -> list:
        """List all restore jobs (newest first)."""
        jobs = []
        for f in sorted(self.jobs_dir.glob("*.json"),
                        key=lambda x: x.stat().st_mtime, reverse=True)[:limit]:
            try:
                with open(f) as fp:
                    jobs.append(json.load(fp))
            except Exception:
                pass
        return jobs

    def get_job(self, job_id: str) -> dict:
        f = self._job_file(job_id)
        if f.exists():
            with open(f) as fp:
                return json.load(fp)
        return None

    def save_job(self, job_data: dict):
        f = self._job_file(job_data["id"])
        with open(f, "w") as fp:
            json.dump(job_data, fp, indent=2, default=str)

    def create_job(self, **kwargs) -> RestoreJob:
        """Create new restore job."""
        job = RestoreJob(**kwargs)
        self.save_job(job.to_dict())
        log.info(f"Restore job created: {job.id[:8]} — {job.target_name}")
        return job

    def update_job(self, job_id: str, **updates):
        job_data = self.get_job(job_id)
        if not job_data:
            return None
        job_data.update(updates)
        self.save_job(job_data)
        return job_data

    def delete_job(self, job_id: str) -> bool:
        f = self._job_file(job_id)
        if f.exists():
            f.unlink()
            return True
        return False


class RestoreEngine:
    """Engine that executes restore operations."""

    GRAPH = "https://graph.microsoft.com/v1.0"

    def __init__(self, tenant_config: dict):
        self.tenant = tenant_config
        from app.workloads.base import BaseWorkload
        # Reuse auth from BaseWorkload
        self._auth = BaseWorkload(tenant_config)

    def _headers(self):
        return {"Authorization": f"Bearer {self._auth.get_token()}",
                "Content-Type": "application/octet-stream"}

    def restore_sharepoint(self, job: dict, backup_path: str,
                           progress_callback=None) -> dict:
        """Restore SharePoint site backup.
        Modes:
          - overwrite: replace existing files
          - merge: keep existing, add missing
          - new_location: restore to different site
        """
        stats = {"uploaded": 0, "skipped": 0, "errors": [], "bytes": 0}
        mode = job.get("mode", "merge")
        target_site = job.get("target_site") or job.get("target_name")
        target_location = job.get("target_location")
        host = self.tenant.get("sharepoint_host", "")

        try:
            # Resolve target site
            if mode == "new_location" and target_location:
                site_path = target_location
            else:
                site_path = target_site

            site_url = f"{self.GRAPH}/sites/{host}:/{site_path}" if site_path \
                       else f"{self.GRAPH}/sites/{host}"
            site_data = requests.get(site_url, headers=self._headers(),
                                     timeout=30).json()
            site_id = site_data["id"]

            # Get drives
            drives_data = requests.get(
                f"{self.GRAPH}/sites/{site_id}/drives",
                headers=self._headers(), timeout=30
            ).json()
            drives_map = {d["name"]: d["id"] for d in drives_data.get("value", [])}

            # Walk backup files
            backup_root = Path(backup_path)
            all_files = [f for f in backup_root.rglob("*")
                         if f.is_file() and not f.name.startswith("_")]
            stats["files_total"] = len(all_files)

            for idx, fp in enumerate(all_files):
                try:
                    # First level dir = library name
                    parts = fp.relative_to(backup_root).parts
                    if len(parts) < 2:
                        continue
                    lib_name = parts[0]
                    drive_id = drives_map.get(lib_name)
                    if not drive_id:
                        continue
                    rel = "/".join(parts[1:])

                    # Check existing for overwrite vs merge
                    if mode == "merge":
                        try:
                            check_url = f"{self.GRAPH}/drives/{drive_id}/root:/{rel}"
                            r = requests.get(check_url, headers={"Authorization":
                                self._headers()["Authorization"]}, timeout=15)
                            if r.status_code == 200:
                                stats["skipped"] += 1
                                continue
                        except Exception:
                            pass

                    # Upload
                    up_url = f"{self.GRAPH}/drives/{drive_id}/root:/{rel}:/content"
                    with open(fp, "rb") as fobj:
                        r = requests.put(up_url, headers=self._headers(),
                                         data=fobj, timeout=120)
                        r.raise_for_status()
                    stats["uploaded"] += 1
                    stats["bytes"] += fp.stat().st_size

                    if progress_callback:
                        progress_callback("file_uploaded", {
                            "file": fp.name, "progress": int((idx + 1) / len(all_files) * 100),
                            **stats,
                        })
                except Exception as e:
                    stats["errors"].append(f"{fp.name}: {e}")

        except Exception as e:
            stats["errors"].append(f"Restore failed: {e}")
        return stats
