"""Celery tasks for M365 multi-tenant operations."""
import os
import logging
from datetime import datetime, timezone
from pathlib import Path

from app.tasks import celery_app
from app.tenant_manager import TenantManager
from app.restore_manager import RestoreManager, RestoreEngine

log = logging.getLogger("spo_backup")


@celery_app.task(bind=True, name="app.tasks_m365.execute_restore_job")
def execute_restore_job(self, job_id: str):
    """Execute a restore job."""
    rm = RestoreManager()
    tm = TenantManager()
    
    job = rm.get_job(job_id)
    if not job:
        log.error(f"Restore job not found: {job_id}")
        return {"error": "Job not found"}
    
    # Mark as running
    rm.update_job(job_id, status="running", 
                  started_at=datetime.now(timezone.utc).isoformat())
    log.info(f"[{job_id[:8]}] RESTORE STARTED — {job.get('target_name', '?')}")
    
    try:
        # Get tenant
        tenant = tm.get_tenant(job["tenant_id"])
        if not tenant:
            raise Exception("Tenant not found")
        
        # Find backup folder
        from app.config_manager import load_config
        config = load_config()
        backup_root = Path(config["backup"]["root_dir"])
        backup_path = backup_root / job["source_backup"]
        if not backup_path.exists():
            raise Exception(f"Backup folder not found: {backup_path}")
        
        # Execute based on workload
        engine = RestoreEngine(tenant)
        
        def progress_cb(evt, data):
            progress = data.get("progress", 0)
            rm.update_job(job_id, progress=progress,
                          files_done=data.get("uploaded", 0),
                          bytes_done=data.get("bytes", 0))
            self.update_state(state="PROGRESS", meta={"event": evt, **data})
        
        if job["workload"] == "sharepoint":
            result = engine.restore_sharepoint(job, str(backup_path), progress_cb)
        else:
            raise Exception(f"Restore not yet supported for: {job['workload']}")
        
        # Mark completed
        rm.update_job(job_id, status="completed", progress=100,
                      finished_at=datetime.now(timezone.utc).isoformat(),
                      files_done=result.get("uploaded", 0),
                      bytes_done=result.get("bytes", 0),
                      errors=result.get("errors", []))
        log.info(f"[{job_id[:8]}] RESTORE COMPLETED — {result.get('uploaded', 0)} files")
        return result
    
    except Exception as e:
        log.error(f"[{job_id[:8]}] RESTORE FAILED: {e}", exc_info=True)
        rm.update_job(job_id, status="failed",
                      finished_at=datetime.now(timezone.utc).isoformat(),
                      errors=[str(e)])
        raise
