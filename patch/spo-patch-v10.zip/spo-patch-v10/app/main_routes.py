"""
M365 Multi-tenant routes — to be added to existing app/main.py
This file contains:
- /tenants page + APIs
- /workloads page + APIs
- /restore page + APIs (job-based)
- Active tenant switcher
"""
import os
import json
import logging
from datetime import datetime, timezone
from pathlib import Path

from flask import Blueprint, render_template, request, jsonify
from celery.result import AsyncResult

from app.tenant_manager import TenantManager, REQUIRED_SCOPES
from app.restore_manager import RestoreManager, RestoreEngine
from app.workloads import WORKLOAD_META, get_workload

log = logging.getLogger("spo_backup")
m365_bp = Blueprint('m365', __name__)

tm = TenantManager()
rm = RestoreManager()


# ═══════════════════════════════════════════════════════════════
# PAGES
# ═══════════════════════════════════════════════════════════════

@m365_bp.route("/tenants")
def tenants_page():
    tenants = tm.list_tenants()
    active = tm.get_active_tenant()
    return render_template("tenants.html", 
                           tenants=tenants,
                           active_tenant=active,
                           required_scopes=REQUIRED_SCOPES)


@m365_bp.route("/workloads")
def workloads_page():
    active = tm.get_active_tenant()
    return render_template("workloads.html", 
                           active_tenant=active,
                           workload_meta=WORKLOAD_META)


@m365_bp.route("/restore")
def restore_page():
    active = tm.get_active_tenant()
    jobs = rm.list_jobs(limit=20)
    
    # List available backups for active tenant
    backups = []
    if active:
        try:
            from app.backup_engine import RestoreEngine as OldRestoreEngine
            # Use config root dir + tenant subfolder
            from app.config_manager import load_config
            config = load_config()
            tenant_slug = active["name"].lower().replace(" ", "-")
            tenant_backup_dir = Path(config["backup"]["root_dir"]) / tenant_slug
            if tenant_backup_dir.exists():
                for d in sorted(tenant_backup_dir.iterdir(), reverse=True):
                    if d.is_dir() and d.name.startswith("backup_"):
                        backups.append({
                            "name": d.name,
                            "date": datetime.fromtimestamp(d.stat().st_mtime).strftime("%Y-%m-%d %H:%M"),
                            "tenant": active["name"],
                        })
        except Exception as e:
            log.error(f"Failed to list backups: {e}")
    
    return render_template("restore.html",
                           active_tenant=active,
                           jobs=jobs,
                           backups=backups)


# ═══════════════════════════════════════════════════════════════
# TENANT APIs
# ═══════════════════════════════════════════════════════════════

@m365_bp.route("/api/tenants", methods=["GET"])
def api_list_tenants():
    return jsonify({
        "tenants": tm.list_tenants(),
        "active_id": tm.get_active_tenant()["id"] if tm.get_active_tenant() else None,
        "required_scopes": REQUIRED_SCOPES,
    })


@m365_bp.route("/api/tenants", methods=["POST"])
def api_add_tenant():
    try:
        data = request.json
        new_tenant = tm.add_tenant(data)
        return jsonify({"status": "added", "tenant": new_tenant})
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        log.error(f"Add tenant failed: {e}")
        return jsonify({"error": str(e)}), 500


@m365_bp.route("/api/tenants/<tid>", methods=["PUT"])
def api_update_tenant(tid):
    try:
        result = tm.update_tenant(tid, request.json)
        if result:
            return jsonify({"status": "updated"})
        return jsonify({"error": "Not found"}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@m365_bp.route("/api/tenants/<tid>", methods=["DELETE"])
def api_delete_tenant(tid):
    if tm.delete_tenant(tid):
        return jsonify({"status": "deleted"})
    return jsonify({"error": "Not found"}), 404


@m365_bp.route("/api/tenants/<tid>/activate", methods=["POST"])
def api_activate_tenant(tid):
    if tm.set_active_tenant(tid):
        return jsonify({"status": "active", "tenant_id": tid})
    return jsonify({"error": "Not found"}), 404


@m365_bp.route("/api/tenants/<tid>/test", methods=["POST"])
def api_test_tenant(tid):
    result = tm.test_tenant(tid)
    return jsonify(result)


@m365_bp.route("/api/tenants/test-config", methods=["POST"])
def api_test_tenant_config():
    """Test a tenant config without saving (for Add Tenant modal)."""
    result = tm.test_tenant(tenant_data=request.json)
    return jsonify(result)


@m365_bp.route("/api/tenants/active", methods=["GET"])
def api_get_active_tenant():
    active = tm.get_active_tenant()
    if active:
        safe = {k: v for k, v in active.items() if k != "client_secret"}
        return jsonify(safe)
    return jsonify({})


# ═══════════════════════════════════════════════════════════════
# WORKLOAD APIs
# ═══════════════════════════════════════════════════════════════

@m365_bp.route("/api/workloads")
def api_list_workloads():
    return jsonify({
        "workloads": WORKLOAD_META,
        "active_tenant": tm.get_active_tenant(),
    })


@m365_bp.route("/api/workloads/<wtype>/targets")
def api_list_workload_targets(wtype):
    """List targets for a workload (sites for SP, users for OneDrive/Outlook)."""
    active = tm.get_active_tenant()
    if not active:
        return jsonify({"error": "No active tenant"}), 400
    try:
        workload = get_workload(wtype, active)
        return jsonify({"targets": workload.list_targets()})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@m365_bp.route("/api/workloads/<wtype>/toggle", methods=["POST"])
def api_toggle_workload(wtype):
    """Toggle workload enabled/disabled for active tenant."""
    active = tm.get_active_tenant()
    if not active:
        return jsonify({"error": "No active tenant"}), 400
    enabled = active.get("workloads_enabled", [])
    if wtype in enabled:
        enabled.remove(wtype)
    else:
        enabled.append(wtype)
    tm.update_tenant(active["id"], {"workloads_enabled": enabled})
    return jsonify({"status": "toggled", "enabled": enabled})


# ═══════════════════════════════════════════════════════════════
# RESTORE APIs
# ═══════════════════════════════════════════════════════════════

@m365_bp.route("/api/restore/jobs", methods=["GET"])
def api_list_restore_jobs():
    return jsonify({"jobs": rm.list_jobs(limit=50)})


@m365_bp.route("/api/restore/jobs", methods=["POST"])
def api_create_restore_job():
    """Create new restore job and queue it."""
    try:
        data = request.json
        active = tm.get_active_tenant()
        if not active:
            return jsonify({"error": "No active tenant"}), 400
        
        job = rm.create_job(
            tenant_id=active["id"],
            tenant_name=active["name"],
            workload=data.get("workload", "sharepoint"),
            source_backup=data.get("source_backup", ""),
            target_site=data.get("target_site", ""),
            target_name=data.get("target_name", ""),
            target_location=data.get("target_location", ""),
            mode=data.get("mode", "merge"),
        )
        
        # Queue Celery task
        try:
            from app.tasks_m365 import execute_restore_job
            task = execute_restore_job.delay(job.id)
            rm.update_job(job.id, task_id=task.id, status="queued")
        except ImportError:
            log.warning("tasks_m365.py not available, job created but not queued")
        
        return jsonify({"status": "created", "job_id": job.id})
    except Exception as e:
        log.error(f"Create restore job failed: {e}")
        return jsonify({"error": str(e)}), 500


@m365_bp.route("/api/restore/jobs/<job_id>", methods=["GET"])
def api_get_restore_job(job_id):
    job = rm.get_job(job_id)
    if not job:
        return jsonify({"error": "Not found"}), 404
    return jsonify(job)


@m365_bp.route("/api/restore/jobs/<job_id>", methods=["DELETE"])
def api_delete_restore_job(job_id):
    if rm.delete_job(job_id):
        return jsonify({"status": "deleted"})
    return jsonify({"error": "Not found"}), 404


@m365_bp.route("/api/restore/jobs/<job_id>/cancel", methods=["POST"])
def api_cancel_restore_job(job_id):
    job = rm.get_job(job_id)
    if not job:
        return jsonify({"error": "Not found"}), 404
    rm.update_job(job_id, status="cancelled")
    if job.get("task_id"):
        try:
            from app.tasks import celery_app
            celery_app.control.revoke(job["task_id"], terminate=True)
        except Exception:
            pass
    return jsonify({"status": "cancelled"})


def register_m365_routes(app):
    """Register all M365 routes to Flask app."""
    app.register_blueprint(m365_bp)
