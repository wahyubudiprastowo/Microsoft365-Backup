"""
Multi-tenant manager for M365 Backup.
Handles tenant CRUD, encryption, connection testing.
"""
import os
import json
import uuid
import logging
import requests
from datetime import datetime, timezone
from pathlib import Path
import msal

log = logging.getLogger("spo_backup")

# Required Microsoft Graph permissions for full M365 backup
REQUIRED_SCOPES = [
    "Sites.Read.All",
    "Sites.FullControl.All",
    "Mail.Read",
    "Calendars.Read",
    "Contacts.Read",
    "Files.Read.All",
    "ChannelMessage.Read.All",
    "User.Read.All",
    "Group.Read.All",
]


class TenantManager:
    """Manage multiple M365 tenants."""

    def __init__(self, config_path: str = "/app/config.json"):
        self.config_path = config_path

    def _load(self) -> dict:
        with open(self.config_path) as f:
            return json.load(f)

    def _save(self, config: dict):
        # Backup before writing
        if os.path.exists(self.config_path):
            with open(self.config_path) as f:
                old = f.read()
            with open(self.config_path + ".bak", "w") as f:
                f.write(old)
        with open(self.config_path, "w") as f:
            json.dump(config, f, indent=4)

    def list_tenants(self, include_secrets: bool = False) -> list:
        """Return all tenants. Masks secrets by default."""
        cfg = self._load()
        tenants = cfg.get("tenants", [])
        if include_secrets:
            return tenants
        # Mask secrets for UI
        safe = json.loads(json.dumps(tenants))
        for t in safe:
            if t.get("client_secret"):
                t["client_secret"] = "***MASKED***"
        return safe

    def get_tenant(self, tenant_id: str, include_secret: bool = True) -> dict:
        """Get tenant by ID (UUID). Returns None if not found."""
        cfg = self._load()
        for t in cfg.get("tenants", []):
            if t.get("id") == tenant_id:
                if include_secret:
                    return t
                safe = json.loads(json.dumps(t))
                if safe.get("client_secret"):
                    safe["client_secret"] = "***MASKED***"
                return safe
        return None

    def get_active_tenant(self) -> dict:
        """Get currently active tenant."""
        cfg = self._load()
        active_id = cfg.get("active_tenant_id")
        if not active_id:
            tenants = cfg.get("tenants", [])
            if tenants:
                return tenants[0]
            return None
        return self.get_tenant(active_id)

    def set_active_tenant(self, tenant_id: str) -> bool:
        """Set the active tenant."""
        cfg = self._load()
        # Verify tenant exists
        if not any(t.get("id") == tenant_id for t in cfg.get("tenants", [])):
            return False
        cfg["active_tenant_id"] = tenant_id
        self._save(cfg)
        log.info(f"Active tenant set to: {tenant_id}")
        return True

    def add_tenant(self, data: dict) -> dict:
        """Add new tenant. Returns the created tenant (with ID)."""
        cfg = self._load()
        if "tenants" not in cfg:
            cfg["tenants"] = []

        # Validate required fields
        required = ["name", "primary_domain", "sharepoint_host", "tenant_id",
                    "client_id", "client_secret"]
        for field in required:
            if not data.get(field):
                raise ValueError(f"Missing required field: {field}")

        # Check duplicate
        for t in cfg["tenants"]:
            if t.get("tenant_id") == data["tenant_id"]:
                raise ValueError(f"Tenant already exists: {data['tenant_id']}")

        new_tenant = {
            "id": str(uuid.uuid4()),
            "name": data["name"].strip(),
            "primary_domain": data["primary_domain"].strip(),
            "sharepoint_host": data["sharepoint_host"].strip(),
            "tenant_id": data["tenant_id"].strip(),
            "client_id": data["client_id"].strip(),
            "client_secret": data["client_secret"].strip(),
            "workloads_enabled": data.get("workloads_enabled",
                                          ["sharepoint", "onedrive", "outlook"]),
            "created_at": datetime.now(timezone.utc).isoformat(),
            "last_tested": None,
            "last_status": "untested",
        }
        cfg["tenants"].append(new_tenant)

        # Set as active if first one
        if len(cfg["tenants"]) == 1:
            cfg["active_tenant_id"] = new_tenant["id"]

        self._save(cfg)
        log.info(f"Tenant added: {new_tenant['name']} ({new_tenant['id']})")
        # Return without secret
        safe = json.loads(json.dumps(new_tenant))
        safe["client_secret"] = "***MASKED***"
        return safe

    def update_tenant(self, tenant_id: str, data: dict) -> dict:
        """Update existing tenant."""
        cfg = self._load()
        for i, t in enumerate(cfg.get("tenants", [])):
            if t.get("id") == tenant_id:
                # Update fields (preserve ID & created_at)
                for k in ["name", "primary_domain", "sharepoint_host",
                          "tenant_id", "client_id", "workloads_enabled"]:
                    if k in data:
                        cfg["tenants"][i][k] = data[k]
                # Only update secret if not masked
                if data.get("client_secret") and data["client_secret"] != "***MASKED***":
                    cfg["tenants"][i]["client_secret"] = data["client_secret"]
                self._save(cfg)
                log.info(f"Tenant updated: {cfg['tenants'][i]['name']}")
                return cfg["tenants"][i]
        return None

    def delete_tenant(self, tenant_id: str) -> bool:
        """Delete a tenant."""
        cfg = self._load()
        before = len(cfg.get("tenants", []))
        cfg["tenants"] = [t for t in cfg.get("tenants", []) if t.get("id") != tenant_id]
        if len(cfg["tenants"]) < before:
            # If we deleted the active one, set first as active
            if cfg.get("active_tenant_id") == tenant_id:
                cfg["active_tenant_id"] = cfg["tenants"][0]["id"] if cfg["tenants"] else None
            self._save(cfg)
            log.info(f"Tenant deleted: {tenant_id}")
            return True
        return False

    def test_tenant(self, tenant_id: str = None, tenant_data: dict = None) -> dict:
        """Test tenant connection. Returns {status, message, details}."""
        if tenant_data is None and tenant_id:
            tenant_data = self.get_tenant(tenant_id)
        if not tenant_data:
            return {"status": "error", "message": "Tenant not found"}

        try:
            # Get access token
            app = msal.ConfidentialClientApplication(
                tenant_data["client_id"],
                authority=f"https://login.microsoftonline.com/{tenant_data['tenant_id']}",
                client_credential=tenant_data["client_secret"],
            )
            result = app.acquire_token_for_client(
                scopes=["https://graph.microsoft.com/.default"]
            )
            if "access_token" not in result:
                return {
                    "status": "error",
                    "message": result.get("error_description", "Auth failed"),
                    "details": result,
                }

            token = result["access_token"]

            # Test multiple endpoints to verify permissions
            tests = {}

            # 1. Get tenant info
            r = requests.get(
                "https://graph.microsoft.com/v1.0/organization",
                headers={"Authorization": f"Bearer {token}"},
                timeout=15,
            )
            tests["organization"] = {
                "status": r.status_code,
                "ok": r.status_code == 200,
            }
            if r.status_code == 200:
                org = r.json().get("value", [{}])[0]
                tests["organization"]["display_name"] = org.get("displayName")

            # 2. Test SharePoint site
            sp_host = tenant_data.get("sharepoint_host", "")
            if sp_host:
                r = requests.get(
                    f"https://graph.microsoft.com/v1.0/sites/{sp_host}",
                    headers={"Authorization": f"Bearer {token}"},
                    timeout=15,
                )
                tests["sharepoint"] = {"status": r.status_code, "ok": r.status_code == 200}

            # 3. Test users (for OneDrive/Outlook access)
            r = requests.get(
                "https://graph.microsoft.com/v1.0/users?$top=1",
                headers={"Authorization": f"Bearer {token}"},
                timeout=15,
            )
            tests["users"] = {"status": r.status_code, "ok": r.status_code == 200}

            # 4. Decode token to check roles
            try:
                import base64
                parts = token.split('.')
                payload = parts[1] + '=' * (4 - len(parts[1]) % 4)
                decoded = json.loads(base64.urlsafe_b64decode(payload))
                tests["granted_roles"] = decoded.get("roles", [])
            except Exception:
                tests["granted_roles"] = []

            all_ok = all(t.get("ok", False) for t in tests.values()
                         if isinstance(t, dict) and "ok" in t)

            # Update last test status
            if tenant_id:
                cfg = self._load()
                for t in cfg.get("tenants", []):
                    if t.get("id") == tenant_id:
                        t["last_tested"] = datetime.now(timezone.utc).isoformat()
                        t["last_status"] = "connected" if all_ok else "disconnected"
                        self._save(cfg)
                        break

            return {
                "status": "ok" if all_ok else "warning",
                "message": "All tests passed" if all_ok else "Some tests failed",
                "details": tests,
            }
        except Exception as e:
            log.error(f"Tenant test failed: {e}")
            return {"status": "error", "message": str(e)}

    def get_required_scopes(self) -> list:
        return REQUIRED_SCOPES
