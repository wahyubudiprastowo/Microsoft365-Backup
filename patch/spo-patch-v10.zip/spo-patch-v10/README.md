# 🚀 M365 Backup System v10.0 — Multi-Tenant Edition

Major architectural upgrade: from single-tenant SharePoint backup to full **Microsoft 365 multi-tenant backup manager** supporting SharePoint, OneDrive, Outlook, and Teams.

## ✨ What's New in v10

| Feature | Detail |
|---------|--------|
| 🏢 **Multi-tenant** | Manage multiple M365 tenants from one dashboard |
| 🔄 **Active tenant switcher** | Sidebar dropdown to switch context instantly |
| 📦 **Multi-workload** | SharePoint, OneDrive, Outlook (mail/calendar/contacts), Teams |
| 🎯 **Pluggable architecture** | Easy to add new workloads |
| 🔌 **Connection testing** | Multi-endpoint verification with permissions check |
| 🔄 **Restore Jobs** | Job-based restore with 3 modes (Overwrite/Merge/New Location) |
| 📊 **Live restore queue** | Real-time job status with progress bars |
| 🎨 **Updated branding** | "M365 Backup — Multi-tenant Manager" |

---

## 📂 Files in This Patch

```
spo-patch-v10/app/
├── tenant_manager.py            ← Tenant CRUD + connection testing
├── restore_manager.py           ← Job queue + restore engine
├── tasks_m365.py                ← Celery worker for restore execution
├── main_routes.py               ← Flask blueprint with M365 routes
├── workloads/                   ← Pluggable backup modules
│   ├── __init__.py              ← Factory + metadata
│   ├── base.py                  ← BaseWorkload abstract class
│   ├── sharepoint.py            ← SharePoint sites & libraries
│   ├── onedrive.py              ← OneDrive per-user
│   └── outlook.py               ← Mail/calendar/contacts
└── templates/
    ├── base.html                ← M365 branding + tenant switcher
    ├── tenants.html             ← Tenant cards + Add Tenant modal
    ├── workloads.html           ← Workload toggle + targets
    └── restore.html             ← Job-based restore with queue
```

---

## 🚀 Apply Patch

```bash
# 1. Stop containers
cd /volume3/spo-backup/spo-backup-final
sudo docker-compose down

# 2. Upload spo-patch-v10.zip ke /volume3/spo-backup/
cd /volume3/spo-backup
unzip spo-patch-v10.zip

# 3. Copy files
mkdir -p spo-backup-final/app/workloads
cp spo-patch-v10/app/tenant_manager.py        spo-backup-final/app/tenant_manager.py
cp spo-patch-v10/app/restore_manager.py       spo-backup-final/app/restore_manager.py
cp spo-patch-v10/app/tasks_m365.py            spo-backup-final/app/tasks_m365.py
cp spo-patch-v10/app/main_routes.py           spo-backup-final/app/main_routes.py
cp spo-patch-v10/app/workloads/*.py           spo-backup-final/app/workloads/
cp spo-patch-v10/app/templates/*.html         spo-backup-final/app/templates/

# 4. Register blueprint in main.py — add at top of file:
# from app.main_routes import register_m365_routes
# Then after Flask app init:
# register_m365_routes(app)

# 5. Rebuild & restart
cd spo-backup-final
sudo docker-compose build
sudo docker-compose up -d
sleep 15
```

---

## 🔧 Required Patch to main.py

Tambahkan **3 baris** ke `app/main.py`:

```python
# Import (di awal file)
from app.main_routes import register_m365_routes

# Setelah `app = Flask(__name__)`:
register_m365_routes(app)
```

---

## 🎯 Config Schema v10

Config sekarang multi-tenant:

```json
{
    "tenants": [
        {
            "id": "uuid-generated",
            "name": "Digiserve by Telkom",
            "primary_domain": "digiserve.telkom.co.id",
            "sharepoint_host": "digiservebytelkom.sharepoint.com",
            "tenant_id": "089a3ec7-8be6-41ac-aa5e-6f8a387d0e7c",
            "client_id": "c7241c60-c879-432c-a563-ea2045c9de40",
            "client_secret": "...",
            "workloads_enabled": ["sharepoint", "onedrive", "outlook"],
            "created_at": "2026-06-23T10:00:00Z",
            "last_tested": "2026-06-23T10:05:00Z",
            "last_status": "connected"
        }
    ],
    "active_tenant_id": "uuid-of-active",
    "backup": {...},
    "schedule": {...},
    "notification": {...}
}
```

---

## 📋 Azure AD Permissions (Required)

App Registration needs these **Application** permissions in Microsoft Graph:

```
✅ Sites.Read.All           — Read SharePoint sites
✅ Sites.FullControl.All    — Required for Restore (write back)
✅ Files.Read.All           — OneDrive + SharePoint files
✅ Mail.Read                — Outlook email
✅ Calendars.Read           — Outlook calendar
✅ Contacts.Read            — Outlook contacts
✅ ChannelMessage.Read.All  — Teams chats
✅ User.Read.All            — Enumerate users
✅ Group.Read.All           — Enumerate groups
```

⚠️ **Admin consent** must be granted for all.

---

## 🎨 UI Walkthrough

### 1. Sidebar — Active Tenant Switcher
- Click on "Active Tenant" card → dropdown shows all tenants
- Click any tenant → instant switch (page reloads)
- New menu: **Tenants** + **Workloads**

### 2. Tenants Page (`/tenants`)
- Top banner: Azure AD permissions info
- Grid of tenant cards (3 per row)
- Active tenant highlighted with purple glow
- Per-card actions: **Set Active** / **Test** / **Delete**
- **+ Add Tenant** button → opens modal

### 3. Add Tenant Modal
- Form fields: Display Name, Primary Domain, SP Host, Tenant ID, Client ID, Client Secret
- Show/hide password toggle
- **Test Connection** before saving
- Granted Graph Scopes shown (read-only)

### 4. Workloads Page (`/workloads`)
- Cards for SharePoint, OneDrive, Outlook, Teams
- Toggle switch per workload (enable/disable for active tenant)
- "View Targets" button → list sites/users for that workload

### 5. Restore Page (`/restore`)
- Left panel: New Restore form
  - Source Backup dropdown
  - Target Site dropdown  
  - **3 Mode buttons**: Overwrite / Merge / New Location
  - Start Restore button
- Right panel: Restore Jobs queue
  - Live progress cards
  - Status badges (Queued/Running/Completed/Failed)
  - Auto-refresh every 5 seconds

---

## 🆕 New API Endpoints

### Tenants
```
GET    /api/tenants                  — List all tenants
POST   /api/tenants                  — Add new tenant
PUT    /api/tenants/<id>             — Update tenant
DELETE /api/tenants/<id>             — Delete tenant
POST   /api/tenants/<id>/activate    — Set active
POST   /api/tenants/<id>/test        — Test connection
POST   /api/tenants/test-config      — Test before saving
GET    /api/tenants/active           — Get current active
```

### Workloads
```
GET  /api/workloads                       — List workload metadata
GET  /api/workloads/<type>/targets        — List sites/users
POST /api/workloads/<type>/toggle         — Enable/disable
```

### Restore Jobs
```
GET    /api/restore/jobs                  — List all jobs
POST   /api/restore/jobs                  — Create new job
GET    /api/restore/jobs/<id>             — Get job status
DELETE /api/restore/jobs/<id>             — Delete job record
POST   /api/restore/jobs/<id>/cancel      — Cancel running job
```

---

## 🐛 Migration Notes

### Migrating from v9 to v10

If you have an existing config, you need to convert it:

**Old (v9):**
```json
{
    "azure_ad": { "tenant_id": "...", "client_id": "...", "client_secret": "..." },
    "sharepoint": { "host": "digiservebytelkom.sharepoint.com" },
    "sites": [...]
}
```

**New (v10):** Add to `tenants` array:
```json
{
    "tenants": [{
        "id": "auto-generated-uuid",
        "name": "Digiserve by Telkom",
        "primary_domain": "digiserve.telkom.co.id",
        "sharepoint_host": "digiservebytelkom.sharepoint.com",
        "tenant_id": "089a3ec7-8be6-41ac-aa5e-6f8a387d0e7c",
        "client_id": "c7241c60-c879-432c-a563-ea2045c9de40",
        "client_secret": "your-secret-here",
        "workloads_enabled": ["sharepoint"],
        "created_at": "2026-06-23T00:00:00Z",
        "last_tested": null,
        "last_status": "untested"
    }],
    "active_tenant_id": "uuid-of-tenant"
}
```

The old fields can stay (for backward compatibility), but new code uses `tenants[]`.

---

## ⚠️ Known Limitations (v10)

1. **Teams chats workload** — Listed in UI but backup not implemented yet (returns empty)
2. **Outlook restore** — Currently only SharePoint restore is implemented
3. **Multi-tenant backup scheduling** — Schedule applies to active tenant only
4. **Sites page** — Still uses old single-tenant `config.sites` (will be moved to per-tenant in next patch)

These will be addressed in future patches.

---

## 🎬 Next Steps

After applying:

1. **Add first tenant** via Tenants page
2. **Test connection** to verify Azure AD permissions
3. **Enable workloads** on Workloads page (toggle SharePoint/OneDrive/Outlook)
4. **View Targets** to confirm sites/users are listed
5. **Run backup** (still uses old backup logic for now)
6. **Try Restore** with Merge mode (safest)
