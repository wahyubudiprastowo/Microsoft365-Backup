"""Celery tasks — v11: tenant-aware backup orchestration."""
import os
import json
import time
import logging
from datetime import datetime, timezone
from logging.handlers import RotatingFileHandler
from pathlib import Path

from celery import Celery
from celery.schedules import crontab
from celery.signals import worker_process_init

from app.config_manager import load_config
from app.tenant_manager import TenantManager
from app.workloads import get_workload, WORKLOAD_METADATA

# ── Logging ───────────────────────────────────────────────────
LOG_DIR = "/app/logs"
LOG_FILE = os.path.join(LOG_DIR, "m365_backup.log")
os.makedirs(LOG_DIR, exist_ok=True)


def setup_file_logger():
    logger = logging.getLogger("m365_backup")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    fmt = logging.Formatter("[%(asctime)s] %(levelname)s %(message)s",
                            datefmt="%Y-%m-%d %H:%M:%S")
    fh = RotatingFileHandler(LOG_FILE, maxBytes=10*1024*1024, backupCount=5)
    fh.setFormatter(fmt)
    logger.addHandler(fh)
    ch = logging.StreamHandler()
    ch.setFormatter(fmt)
    logger.addHandler(ch)
    logger.propagate = False
    return logger


log = setup_file_logger()


@worker_process_init.connect
def on_worker_start(**kwargs):
    setup_file_logger()


# ── Celery app ────────────────────────────────────────────────
celery_app = Celery("m365_backup",
    broker="redis://redis:6379/0",
    backend="redis://redis:6379/1")

celery_app.conf.update(
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],
    timezone="Asia/Jakarta",
    enable_utc=True,
    task_track_started=True,
    result_expires=86400,
    broker_connection_retry_on_startup=True,
    worker_prefetch_multiplier=1,
)

# Schedule (once per worker startup)
try:
    cfg = load_config()
    if cfg.get("schedule", {}).get("enabled"):
        parts = cfg["schedule"].get("cron_expression", "0 2 * * *").split()
        celery_app.conf.beat_schedule = {
            "scheduled-backup": {
                "task": "app.tasks.run_backup_task",
                "schedule": crontab(
                    minute=parts[0], hour=parts[1],
                    day_of_month=parts[2] if len(parts) > 2 else "*",
                    month_of_year=parts[3] if len(parts) > 3 else "*",
                    day_of_week=parts[4] if len(parts) > 4 else "*",
                ),
            },
        }
        marker = "/tmp/.m365_schedule_logged"
        if not os.path.exists(marker):
            log.info(f"Backup schedule: {cfg['schedule']['cron_expression']}")
            open(marker, "w").write(cfg['schedule']['cron_expression'])
except Exception as e:
    log.error(f"Schedule setup failed: {e}")


BACKUP_ROOT = "/backup/m365"


# ═══════════════════════════════════════════════════════════════
# BACKUP TASK — v11 tenant + workload aware
# ═══════════════════════════════════════════════════════════════
@celery_app.task(bind=True, name="app.tasks.run_backup_task")
def run_backup_task(self, tenant_id: str = None, workloads: list = None):
    """
    Run backup for a tenant (or active tenant) across enabled workloads.
    
    Folder structure created:
      /backup/m365/{tenant-slug}/sharepoint/backup_{ts}/
      /backup/m365/{tenant-slug}/onedrive/backup_{ts}/
      /backup/m365/{tenant-slug}/outlook/backup_{ts}/
    
    Args:
        tenant_id: UUID of tenant (uses active if not provided)
        workloads: list of workload types (uses tenant's enabled if not provided)
    """
    task_id = self.request.id
    log.info("=" * 60)
    log.info(f"BACKUP TASK STARTED — Task: {task_id[:8]}")

    # Redis tracking
    import redis as redis_lib
    r = redis_lib.Redis(host="redis", port=6379, db=2, decode_responses=True)
    r.setex("m365:current_backup_task", 86400, task_id)
    r.setex(f"m365:task:{task_id}:control", 86400, "running")

    # Get tenant
    tm = TenantManager()
    if tenant_id:
        tenant = tm.get_tenant(tenant_id, include_secret=True)
    else:
        tenant = tm.get_active_tenant()

    if not tenant:
        error = "No active tenant found. Please add a tenant first."
        log.error(error)
        r.delete("m365:current_backup_task")
        return {"status": "error", "message": error}

    log.info(f"  Tenant: {tenant['name']} ({tenant.get('primary_domain', '?')})")

    # Determine workloads to run
    if workloads is None:
        workloads = tenant.get("workloads_enabled", ["sharepoint"])
    workloads = [w for w in workloads if w in WORKLOAD_METADATA and w != "teams"]
    log.info(f"  Workloads: {', '.join(workloads)}")

    # Aggregate stats
    overall_stats = {
        "task_id": task_id,
        "tenant_id": tenant.get("id"),
        "tenant_name": tenant.get("name"),
        "tenant_slug": None,  # Will be filled by first workload
        "workloads": workloads,
        "start_time": datetime.now(timezone.utc).isoformat(),
        "end_time": None,
        "per_workload": {},
        "total_files": 0,
        "total_bytes": 0,
        "total_targets": 0,
        "total_failed": 0,
        "cancelled": False,
        "errors": [],
    }

    # Progress callback
    current_workload_stats = {}

    def progress_cb(evt, data):
        # Update per-workload live progress
        wl = data.get("workload", "?")
        current_workload_stats[wl] = data
        
        if evt == "backup_start":
            log.info(f"→ Starting {wl.upper()} → {data.get('backup_path', '?')}")
        elif evt == "target_start":
            log.info(f"  📁 [{data.get('target_idx')}/{data.get('target_total')}] "
                     f"{data.get('target_name', '?')}")
        elif evt == "target_done":
            status = data.get("status")
            if status == "success":
                log.info(f"    ✅ {data.get('target_name')}")
            else:
                log.error(f"    ❌ {data.get('target_name')}: {data.get('error', '?')[:100]}")
        elif evt == "workload_done":
            log.info(f"  ✓ {wl.upper()} completed: "
                     f"{data.get('files_downloaded', 0)} files, "
                     f"{data.get('bytes_downloaded', 0) / 1024 / 1024:.2f} MB")
        elif evt == "paused":
            log.warning(f"  ⏸ Paused")
        elif evt == "cancelled":
            log.warning(f"  ⛔ Cancelled")
        
        # Update Celery task state
        self.update_state(state="PROGRESS", meta={
            "event": evt,
            "current_workload": wl,
            "workloads_progress": current_workload_stats,
            **data,
        })

    # ── Iterate workloads ──
    for wl_type in workloads:
        try:
            log.info(f"────────────────────────────────────────────────")
            log.info(f"▶ Workload: {wl_type}")
            
            workload = get_workload(
                workload_type=wl_type,
                tenant=tenant,
                backup_root=BACKUP_ROOT,
                progress_callback=progress_cb,
                task_id=task_id,
            )
            
            # Store tenant_slug (same for all workloads of this tenant)
            if not overall_stats["tenant_slug"]:
                overall_stats["tenant_slug"] = workload.tenant_slug
            
            wl_stats = workload.backup()
            
            overall_stats["per_workload"][wl_type] = {
                "files_downloaded": wl_stats["files_downloaded"],
                "files_skipped": wl_stats["files_skipped"],
                "bytes_downloaded": wl_stats["bytes_downloaded"],
                "targets_processed": wl_stats["targets_processed"],
                "targets_failed": wl_stats["targets_failed"],
                "backup_path": wl_stats["backup_path"],
                "errors_count": len(wl_stats["errors"]),
                "duration_sec": _duration(wl_stats.get("start_time"), wl_stats.get("end_time")),
            }
            
            overall_stats["total_files"] += wl_stats["files_downloaded"]
            overall_stats["total_bytes"] += wl_stats["bytes_downloaded"]
            overall_stats["total_targets"] += wl_stats["targets_processed"]
            overall_stats["total_failed"] += wl_stats["targets_failed"]
            overall_stats["errors"].extend(
                [f"[{wl_type}] {e}" for e in wl_stats["errors"][:5]]
            )
            
            if wl_stats.get("cancelled"):
                overall_stats["cancelled"] = True
                log.warning(f"  ⛔ {wl_type} cancelled, skipping remaining workloads")
                break

        except Exception as e:
            log.error(f"Workload {wl_type} FAILED: {e}", exc_info=True)
            overall_stats["errors"].append(f"[{wl_type}] Fatal: {e}")
            overall_stats["per_workload"][wl_type] = {
                "status": "failed",
                "error": str(e),
            }

    overall_stats["end_time"] = datetime.now(timezone.utc).isoformat()

    # Save tenant-level backup manifest
    if overall_stats["tenant_slug"]:
        tenant_dir = os.path.join(BACKUP_ROOT, overall_stats["tenant_slug"])
        os.makedirs(tenant_dir, exist_ok=True)
        history_dir = os.path.join(tenant_dir, ".history")
        os.makedirs(history_dir, exist_ok=True)
        history_file = os.path.join(history_dir,
            f"backup_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.json")
        with open(history_file, "w") as f:
            json.dump(overall_stats, f, indent=2)

    log.info("=" * 60)
    log.info(f"BACKUP TASK COMPLETED")
    log.info(f"  Tenant  : {tenant['name']}")
    log.info(f"  Files   : {overall_stats['total_files']}")
    log.info(f"  Size    : {overall_stats['total_bytes'] / 1024 / 1024:.2f} MB")
    log.info(f"  Targets : {overall_stats['total_targets']} ok, "
             f"{overall_stats['total_failed']} failed")
    log.info("=" * 60)

    # Try notification
    try:
        from app.notifier import NotificationDispatcher
        NotificationDispatcher(load_config()).send_all(overall_stats)
    except Exception as e:
        log.warning(f"Notification failed: {e}")

    # Cleanup Redis
    r.delete("m365:current_backup_task")
    r.delete(f"m365:task:{task_id}:control")

    return overall_stats


def _duration(start_iso: str, end_iso: str) -> int:
    """Return duration in seconds between ISO timestamps."""
    if not start_iso or not end_iso:
        return 0
    try:
        s = datetime.fromisoformat(start_iso.replace("Z", "+00:00"))
        e = datetime.fromisoformat(end_iso.replace("Z", "+00:00"))
        return int((e - s).total_seconds())
    except Exception:
        return 0


# ═══════════════════════════════════════════════════════════════
# RESTORE & NOTIFICATION tasks (unchanged v10 signatures)
# ═══════════════════════════════════════════════════════════════
@celery_app.task(bind=True, name="app.tasks.execute_restore_job")
def execute_restore_job(self, job_id: str):
    """Execute a queued restore job."""
    from app.restore_manager import RestoreManager
    log.info(f"RESTORE JOB: {job_id[:8]}")
    return RestoreManager().execute(job_id, task_id=self.request.id)


@celery_app.task(name="app.tasks.send_test_notification")
def send_test_notification(channel: str = None):
    from app.notifier import NotificationDispatcher
    log.info(f"TEST NOTIFICATION: {channel or 'all'}")
    return NotificationDispatcher(load_config()).send_test(channel)


# ═══════════════════════════════════════════════════════════════
# UTILITIES
# ═══════════════════════════════════════════════════════════════
def force_cancel_task(task_id: str):
    """Cancel a running task."""
    import redis as redis_lib
    r = redis_lib.Redis(host="redis", port=6379, db=2, decode_responses=True)
    r.setex(f"m365:task:{task_id}:control", 86400, "cancelled")
    try:
        celery_app.control.revoke(task_id, terminate=True, signal="SIGTERM")
    except Exception as e:
        log.error(f"Revoke failed: {e}")
    r.delete("m365:current_backup_task")
