"""
Backup Registry — v11.
Scans tenant-aware folder structure and returns unified backup list.

Structure:
  /backup/m365/{tenant-slug}/{workload}/backup_{timestamp}/
                            /.manifests/
              /.history/backup_YYYYMMDD_HHMMSS.json
"""
import os
import json
import time
import shutil
import logging
from pathlib import Path
from datetime import datetime

log = logging.getLogger("m365_backup")

BACKUP_ROOT = "/backup/m365"


class BackupRegistry:
    """Scan & manage backups in tenant-aware folder structure."""

    def __init__(self, backup_root: str = BACKUP_ROOT):
        self.root = Path(backup_root)
        self._cache = {}

    def list_all(self, use_cache: bool = True) -> list:
        """
        Return list of all backup runs grouped by workload:
        [
          {
            "tenant_slug": "digiserve-by-telkom",
            "tenant_name": "Digiserve by Telkom" (from history),
            "workload": "sharepoint",
            "backup_name": "backup_20260628_150000",
            "backup_path": "/backup/m365/digiserve-by-telkom/sharepoint/backup_20260628_150000",
            "date": "2026-06-28 15:00:00",
            "size_bytes": 5242880,
            "size_human": "5.0 MB",
            "targets_count": 13,
            "files_count": 247,
          },
          ...
        ]
        """
        if use_cache and "all" in self._cache:
            cached, ts = self._cache["all"]
            if time.time() - ts < 30:
                return cached

        results = []
        if not self.root.exists():
            return results

        for tenant_dir in self.root.iterdir():
            if not tenant_dir.is_dir() or tenant_dir.name.startswith("."):
                continue

            for workload_dir in tenant_dir.iterdir():
                if not workload_dir.is_dir() or workload_dir.name.startswith("."):
                    continue

                for backup_dir in workload_dir.iterdir():
                    if not backup_dir.is_dir() or not backup_dir.name.startswith("backup_"):
                        continue

                    results.append(self._describe_backup(
                        backup_dir, tenant_dir.name, workload_dir.name
                    ))

        # Sort by date desc
        results.sort(key=lambda x: x["date"], reverse=True)

        self._cache["all"] = (results, time.time())
        return results

    def _describe_backup(self, backup_dir: Path, tenant_slug: str,
                         workload: str) -> dict:
        """Get metadata about a single backup folder."""
        # Cached size
        size_cache = backup_dir / "_size_cache.json"
        if size_cache.exists():
            try:
                sc = json.load(open(size_cache))
                size_bytes = sc.get("size_bytes", 0)
            except Exception:
                size_bytes = self._calc_size(backup_dir)
                self._save_size(backup_dir, size_bytes)
        else:
            size_bytes = self._calc_size(backup_dir)
            self._save_size(backup_dir, size_bytes)

        # Try read manifest for metadata
        manifest_file = backup_dir / "_workload_manifest.json"
        tenant_name = tenant_slug.replace("-", " ").title()
        files_count = 0
        targets_count = 0
        if manifest_file.exists():
            try:
                manifest = json.load(open(manifest_file))
                tenant_name = manifest.get("tenant_name", tenant_name)
                files_count = manifest.get("files_downloaded", 0)
                targets_count = (
                    manifest.get("sites_count")
                    or manifest.get("users_count")
                    or manifest.get("mailbox_count")
                    or manifest.get("targets_processed", 0)
                )
            except Exception:
                pass

        return {
            "tenant_slug": tenant_slug,
            "tenant_name": tenant_name,
            "workload": workload,
            "backup_name": backup_dir.name,
            "backup_path": str(backup_dir),
            "date": datetime.fromtimestamp(backup_dir.stat().st_mtime)
                    .strftime("%Y-%m-%d %H:%M:%S"),
            "size_bytes": size_bytes,
            "size_human": self._format_size(size_bytes),
            "files_count": files_count,
            "targets_count": targets_count,
        }

    def _calc_size(self, path: Path) -> int:
        total = 0
        try:
            for entry in os.scandir(path):
                try:
                    if entry.is_file():
                        total += entry.stat().st_size
                    elif entry.is_dir():
                        total += self._calc_size(Path(entry.path))
                except (OSError, PermissionError):
                    pass
        except (OSError, PermissionError):
            pass
        return total

    def _save_size(self, path: Path, size: int):
        try:
            with open(path / "_size_cache.json", "w") as f:
                json.dump({"size_bytes": size,
                           "computed_at": datetime.now().isoformat()}, f)
        except Exception:
            pass

    def _format_size(self, b: int) -> str:
        for unit in ["B", "KB", "MB", "GB", "TB"]:
            if b < 1024:
                return f"{b:.1f} {unit}"
            b /= 1024
        return f"{b:.1f} PB"

    def delete(self, tenant_slug: str, workload: str, backup_name: str) -> dict:
        """Delete a specific backup folder."""
        if not backup_name.startswith("backup_"):
            return {"error": "Invalid backup name"}
        path = self.root / tenant_slug / workload / backup_name
        if path.exists() and path.is_dir():
            shutil.rmtree(path)
            self._cache.clear()
            log.info(f"Deleted backup: {path}")
            return {"status": "deleted", "path": str(path)}
        return {"error": "Not found"}

    def get_history(self, tenant_slug: str, limit: int = 20) -> list:
        """Get last N backup runs for a tenant (from .history)."""
        history_dir = self.root / tenant_slug / ".history"
        if not history_dir.exists():
            return []
        files = sorted(history_dir.glob("backup_*.json"), reverse=True)[:limit]
        results = []
        for f in files:
            try:
                results.append(json.load(open(f)))
            except Exception:
                pass
        return results

    def invalidate_cache(self):
        self._cache.clear()

    def get_stats(self) -> dict:
        """Aggregate stats across all tenants/workloads."""
        backups = self.list_all()
        total_size = sum(b["size_bytes"] for b in backups)
        by_tenant = {}
        by_workload = {}
        for b in backups:
            by_tenant.setdefault(b["tenant_slug"], 0)
            by_tenant[b["tenant_slug"]] += 1
            by_workload.setdefault(b["workload"], 0)
            by_workload[b["workload"]] += 1
        return {
            "total_backups": len(backups),
            "total_size_bytes": total_size,
            "total_size_human": self._format_size(total_size),
            "by_tenant": by_tenant,
            "by_workload": by_workload,
        }
