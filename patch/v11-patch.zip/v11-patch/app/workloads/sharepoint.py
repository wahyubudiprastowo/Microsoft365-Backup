"""SharePoint Online workload — v11 tenant-aware."""
import os
import json
import time
from datetime import datetime, timezone
from .base import BaseWorkload

import logging
log = logging.getLogger("m365_backup")


class SharePointWorkload(BaseWorkload):
    WORKLOAD_NAME = "sharepoint"

    def list_targets(self) -> list:
        """List all SharePoint sites in tenant."""
        host = self.tenant.get("sharepoint_host")
        if not host:
            return []
        # Root site + follow sitesToFollow
        sites = []
        try:
            # Get root
            root = self._get(f"{self.GRAPH}/sites/{host}")
            sites.append({
                "id": root["id"],
                "name": root.get("displayName", "Root"),
                "url": root.get("webUrl"),
                "type": "root",
            })
            # Search all sites
            data = self._paginate(f"{self.GRAPH}/sites?search=")
            for s in data:
                if s.get("id") == root["id"]:
                    continue
                sites.append({
                    "id": s.get("id"),
                    "name": s.get("displayName") or s.get("name"),
                    "url": s.get("webUrl"),
                    "type": "site",
                })
        except Exception as e:
            log.error(f"list_targets(sharepoint) failed: {e}")
        return sites

    def backup(self) -> dict:
        """Backup all enabled SharePoint sites for this tenant."""
        self.stats["start_time"] = datetime.now(timezone.utc).isoformat()
        backup_path = self.build_backup_path()
        self.stats["backup_path"] = backup_path

        self.emit("backup_start", {"backup_path": backup_path})

        try:
            sites = self.list_targets()
            total_sites = len(sites)
            self.emit("targets_enumerated", {"total_targets": total_sites})

            for idx, site in enumerate(sites):
                self._check_control()
                self.emit("target_start", {
                    "target_name": site["name"],
                    "target_idx": idx + 1,
                    "target_total": total_sites,
                })
                try:
                    self._backup_site(site, backup_path)
                    self.stats["targets_processed"] += 1
                    self.emit("target_done", {
                        "target_name": site["name"],
                        "status": "success",
                    })
                except Exception as e:
                    self.stats["targets_failed"] += 1
                    self.stats["errors"].append(f"Site '{site['name']}': {e}")
                    self.emit("target_done", {
                        "target_name": site["name"],
                        "status": "failed",
                        "error": str(e),
                    })

            # Write workload manifest
            self._save_workload_manifest(backup_path, sites)

        except Exception as e:
            self.stats["cancelled"] = "PauseException" in str(type(e))
            log.error(f"SharePoint backup failed: {e}")

        self.stats["end_time"] = datetime.now(timezone.utc).isoformat()
        self.emit("workload_done")
        return self.stats

    def _backup_site(self, site: dict, backup_path: str):
        """Backup single site — all document libraries."""
        site_id = site["id"]
        safe_name = site["name"].replace("/", "_").replace(" ", "_")
        site_dir = os.path.join(backup_path, safe_name)
        os.makedirs(site_dir, exist_ok=True)

        # List drives
        drives = self._paginate(f"{self.GRAPH}/sites/{site_id}/drives")

        for drive in drives:
            self._check_control()
            drive_name = drive.get("name", "Documents")
            lib_dir = os.path.join(site_dir, drive_name.replace("/", "_"))
            os.makedirs(lib_dir, exist_ok=True)

            # Recursively backup all files in drive root
            self._backup_folder(drive["id"], "root", lib_dir)

        # Save site metadata
        meta = {
            "site_id": site_id,
            "site_name": site["name"],
            "site_url": site.get("url"),
            "drives": [{"id": d["id"], "name": d.get("name")} for d in drives],
            "backup_time": datetime.now(timezone.utc).isoformat(),
        }
        with open(os.path.join(site_dir, "_site_metadata.json"), "w") as f:
            json.dump(meta, f, indent=2)

    def _backup_folder(self, drive_id: str, folder_id: str, local_dir: str):
        """Recursively backup folder contents."""
        items = self._paginate(
            f"{self.GRAPH}/drives/{drive_id}/items/{folder_id}/children",
            params={"$top": 200}
        )
        for item in items:
            self._check_control()
            name = item.get("name", "unnamed")
            safe_name = name.replace("/", "_")

            if "folder" in item:
                sub_dir = os.path.join(local_dir, safe_name)
                os.makedirs(sub_dir, exist_ok=True)
                self._backup_folder(drive_id, item["id"], sub_dir)
            elif "file" in item:
                dest = os.path.join(local_dir, safe_name)
                size = item.get("size", 0)
                dl_url = f"{self.GRAPH}/drives/{drive_id}/items/{item['id']}/content"
                try:
                    self.download_file(dl_url, dest, size)
                    self.emit("file_done", {"current_file": name})
                except Exception as e:
                    self.stats["errors"].append(f"{name}: {e}")

    def _save_workload_manifest(self, backup_path: str, sites: list):
        """Save top-level manifest for this workload run."""
        manifest = {
            **self.get_workload_metadata(),
            "sites_count": len(sites),
            "files_downloaded": self.stats["files_downloaded"],
            "files_skipped": self.stats["files_skipped"],
            "bytes_downloaded": self.stats["bytes_downloaded"],
            "targets_processed": self.stats["targets_processed"],
            "targets_failed": self.stats["targets_failed"],
            "errors": self.stats["errors"][:20],
        }
        with open(os.path.join(backup_path, "_workload_manifest.json"), "w") as f:
            json.dump(manifest, f, indent=2)
