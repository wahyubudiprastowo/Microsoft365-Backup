"""OneDrive workload — v11 tenant-aware, per-user."""
import os
import json
from datetime import datetime, timezone
from .base import BaseWorkload

import logging
log = logging.getLogger("m365_backup")


class OneDriveWorkload(BaseWorkload):
    WORKLOAD_NAME = "onedrive"

    def list_targets(self) -> list:
        """List all users with OneDrive."""
        users = []
        try:
            data = self._paginate(
                f"{self.GRAPH}/users",
                params={"$select": "id,displayName,userPrincipalName,mail", "$top": 100}
            )
            for u in data:
                users.append({
                    "id": u["id"],
                    "name": u.get("displayName", "Unknown"),
                    "email": u.get("mail") or u.get("userPrincipalName"),
                    "type": "user",
                })
        except Exception as e:
            log.error(f"list_targets(onedrive) failed: {e}")
        return users

    def backup(self) -> dict:
        self.stats["start_time"] = datetime.now(timezone.utc).isoformat()
        backup_path = self.build_backup_path()
        self.stats["backup_path"] = backup_path
        self.emit("backup_start", {"backup_path": backup_path})

        try:
            users = self.list_targets()
            total = len(users)
            self.emit("targets_enumerated", {"total_targets": total})

            for idx, user in enumerate(users):
                self._check_control()
                self.emit("target_start", {
                    "target_name": user["email"],
                    "target_idx": idx + 1,
                    "target_total": total,
                })
                try:
                    self._backup_user_drive(user, backup_path)
                    self.stats["targets_processed"] += 1
                    self.emit("target_done", {
                        "target_name": user["email"],
                        "status": "success",
                    })
                except Exception as e:
                    self.stats["targets_failed"] += 1
                    self.stats["errors"].append(f"User '{user['email']}': {str(e)[:120]}")
                    self.emit("target_done", {
                        "target_name": user["email"],
                        "status": "failed",
                        "error": str(e),
                    })

            self._save_manifest(backup_path, users)
        except Exception as e:
            log.error(f"OneDrive backup failed: {e}")

        self.stats["end_time"] = datetime.now(timezone.utc).isoformat()
        self.emit("workload_done")
        return self.stats

    def _backup_user_drive(self, user: dict, backup_path: str):
        """Backup a user's OneDrive."""
        try:
            drive = self._get(f"{self.GRAPH}/users/{user['id']}/drive")
        except Exception as e:
            # User may not have OneDrive provisioned
            raise Exception(f"No OneDrive: {e}")

        user_folder = user["email"].replace("@", "_at_").replace("/", "_")
        user_dir = os.path.join(backup_path, user_folder)
        os.makedirs(user_dir, exist_ok=True)

        self._backup_folder(drive["id"], "root", user_dir)

        with open(os.path.join(user_dir, "_user_metadata.json"), "w") as f:
            json.dump({
                "user_id": user["id"],
                "email": user["email"],
                "name": user["name"],
                "drive_id": drive["id"],
                "backup_time": datetime.now(timezone.utc).isoformat(),
            }, f, indent=2)

    def _backup_folder(self, drive_id, folder_id, local_dir):
        items = self._paginate(
            f"{self.GRAPH}/drives/{drive_id}/items/{folder_id}/children",
            params={"$top": 200}
        )
        for item in items:
            self._check_control()
            name = item.get("name", "unnamed").replace("/", "_")
            if "folder" in item:
                sub = os.path.join(local_dir, name)
                os.makedirs(sub, exist_ok=True)
                self._backup_folder(drive_id, item["id"], sub)
            elif "file" in item:
                dest = os.path.join(local_dir, name)
                size = item.get("size", 0)
                dl_url = f"{self.GRAPH}/drives/{drive_id}/items/{item['id']}/content"
                try:
                    self.download_file(dl_url, dest, size)
                    self.emit("file_done", {"current_file": name})
                except Exception as e:
                    self.stats["errors"].append(f"{name}: {e}")

    def _save_manifest(self, backup_path, users):
        manifest = {
            **self.get_workload_metadata(),
            "users_count": len(users),
            "files_downloaded": self.stats["files_downloaded"],
            "bytes_downloaded": self.stats["bytes_downloaded"],
            "targets_processed": self.stats["targets_processed"],
            "targets_failed": self.stats["targets_failed"],
            "errors": self.stats["errors"][:20],
        }
        with open(os.path.join(backup_path, "_workload_manifest.json"), "w") as f:
            json.dump(manifest, f, indent=2)
