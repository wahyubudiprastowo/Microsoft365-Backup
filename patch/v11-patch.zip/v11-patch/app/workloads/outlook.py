"""Outlook workload — v11 tenant-aware. Backs up mail/cal/contacts as JSON."""
import os
import json
from datetime import datetime, timezone
from .base import BaseWorkload

import logging
log = logging.getLogger("m365_backup")


class OutlookWorkload(BaseWorkload):
    WORKLOAD_NAME = "outlook"

    def list_targets(self) -> list:
        """List all users (mail-enabled)."""
        users = []
        try:
            data = self._paginate(
                f"{self.GRAPH}/users",
                params={"$select": "id,displayName,mail,userPrincipalName", "$top": 100}
            )
            for u in data:
                if u.get("mail"):
                    users.append({
                        "id": u["id"],
                        "name": u.get("displayName"),
                        "email": u.get("mail") or u.get("userPrincipalName"),
                        "type": "mailbox",
                    })
        except Exception as e:
            log.error(f"list_targets(outlook) failed: {e}")
        return users

    def backup(self) -> dict:
        self.stats["start_time"] = datetime.now(timezone.utc).isoformat()
        backup_path = self.build_backup_path()
        self.stats["backup_path"] = backup_path
        self.emit("backup_start", {"backup_path": backup_path})

        try:
            users = self.list_targets()
            total = len(users)
            self.emit("targets_enumerated", {"total_targets": total})

            for idx, user in enumerate(users):
                self._check_control()
                self.emit("target_start", {
                    "target_name": user["email"],
                    "target_idx": idx + 1,
                    "target_total": total,
                })
                try:
                    self._backup_user_mailbox(user, backup_path)
                    self.stats["targets_processed"] += 1
                    self.emit("target_done", {"target_name": user["email"], "status": "success"})
                except Exception as e:
                    self.stats["targets_failed"] += 1
                    self.stats["errors"].append(f"Mailbox '{user['email']}': {str(e)[:120]}")
                    self.emit("target_done", {"target_name": user["email"], "status": "failed", "error": str(e)})

            self._save_manifest(backup_path, users)
        except Exception as e:
            log.error(f"Outlook backup failed: {e}")

        self.stats["end_time"] = datetime.now(timezone.utc).isoformat()
        self.emit("workload_done")
        return self.stats

    def _backup_user_mailbox(self, user, backup_path):
        user_folder = user["email"].replace("@", "_at_").replace("/", "_")
        user_dir = os.path.join(backup_path, user_folder)
        os.makedirs(user_dir, exist_ok=True)

        # 1. Messages (last 1000 for safety)
        try:
            messages = self._paginate(
                f"{self.GRAPH}/users/{user['id']}/messages",
                params={"$top": 100, "$orderby": "receivedDateTime desc"}
            )[:1000]
            with open(os.path.join(user_dir, "messages.json"), "w") as f:
                json.dump(messages, f, indent=2, default=str)
            self.stats["files_downloaded"] += 1
        except Exception as e:
            self.stats["errors"].append(f"messages: {e}")

        # 2. Calendar events
        try:
            events = self._paginate(
                f"{self.GRAPH}/users/{user['id']}/events",
                params={"$top": 100}
            )
            with open(os.path.join(user_dir, "calendar.json"), "w") as f:
                json.dump(events, f, indent=2, default=str)
            self.stats["files_downloaded"] += 1
        except Exception as e:
            self.stats["errors"].append(f"calendar: {e}")

        # 3. Contacts
        try:
            contacts = self._paginate(
                f"{self.GRAPH}/users/{user['id']}/contacts",
                params={"$top": 100}
            )
            with open(os.path.join(user_dir, "contacts.json"), "w") as f:
                json.dump(contacts, f, indent=2, default=str)
            self.stats["files_downloaded"] += 1
        except Exception as e:
            self.stats["errors"].append(f"contacts: {e}")

        with open(os.path.join(user_dir, "_mailbox_metadata.json"), "w") as f:
            json.dump({
                "user_id": user["id"],
                "email": user["email"],
                "name": user["name"],
                "backup_time": datetime.now(timezone.utc).isoformat(),
            }, f, indent=2)

    def _save_manifest(self, backup_path, users):
        manifest = {
            **self.get_workload_metadata(),
            "mailbox_count": len(users),
            "files_downloaded": self.stats["files_downloaded"],
            "targets_processed": self.stats["targets_processed"],
            "targets_failed": self.stats["targets_failed"],
            "errors": self.stats["errors"][:20],
        }
        with open(os.path.join(backup_path, "_workload_manifest.json"), "w") as f:
            json.dump(manifest, f, indent=2)
