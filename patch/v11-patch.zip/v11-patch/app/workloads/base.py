"""
Base workload class — v11 with tenant-aware folder structure.
Structure: /backup/m365/{tenant-slug}/{workload}/backup_{timestamp}/
"""
import os
import re
import json
import time
import logging
import msal
import requests
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Callable

log = logging.getLogger("m365_backup")


def slugify(text: str) -> str:
    """Convert tenant name to filesystem-safe slug."""
    if not text:
        return "unknown-tenant"
    text = text.lower().strip()
    text = re.sub(r'[^a-z0-9]+', '-', text)
    text = text.strip('-')
    return text or "unknown-tenant"


class BaseWorkload:
    """
    Base class for all workloads (SharePoint, OneDrive, Outlook, Teams).
    
    v11 changes:
    - Constructor requires `tenant` dict (not just credentials)
    - build_backup_path() returns tenant-aware path
    - stats includes tenant_slug + workload_name
    """
    
    WORKLOAD_NAME = "base"
    GRAPH = "https://graph.microsoft.com/v1.0"

    def __init__(self, tenant: dict, backup_root: str = "/backup/m365",
                 progress_callback: Optional[Callable] = None, task_id: str = None):
        """
        tenant: dict with {id, name, tenant_id, client_id, client_secret, sharepoint_host}
        backup_root: base folder (default /backup/m365)
        """
        self.tenant = tenant
        self.tenant_slug = slugify(tenant.get("name", "unknown"))
        self.backup_root = backup_root
        self.progress_callback = progress_callback
        self.task_id = task_id
        
        # Auth
        self._token = None
        self._token_expires_at = 0
        
        # Session with retries
        self.session = requests.Session()
        
        # Stats
        self.stats = {
            "tenant_id": tenant.get("id"),
            "tenant_name": tenant.get("name"),
            "tenant_slug": self.tenant_slug,
            "workload": self.WORKLOAD_NAME,
            "start_time": None,
            "end_time": None,
            "files_downloaded": 0,
            "files_skipped": 0,
            "bytes_downloaded": 0,
            "targets_processed": 0,
            "targets_failed": 0,
            "errors": [],
            "backup_path": None,
            "cancelled": False,
        }
        self._last_emit = 0

    # ── AUTH ──────────────────────────────────────────────────
    def get_token(self) -> str:
        """Get cached or fresh access token."""
        now = time.time()
        if self._token and now < self._token_expires_at - 60:
            return self._token
        
        app = msal.ConfidentialClientApplication(
            self.tenant["client_id"],
            authority=f"https://login.microsoftonline.com/{self.tenant['tenant_id']}",
            client_credential=self.tenant["client_secret"],
        )
        result = app.acquire_token_for_client(
            scopes=["https://graph.microsoft.com/.default"]
        )
        if "access_token" not in result:
            raise Exception(f"Auth failed for tenant {self.tenant.get('name')}: "
                           f"{result.get('error_description', 'Unknown')}")
        
        self._token = result["access_token"]
        self._token_expires_at = now + result.get("expires_in", 3600)
        return self._token

    def _headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self.get_token()}",
            "Content-Type": "application/json",
        }

    # ── HTTP with retry & throttling ──────────────────────────
    def _get(self, url: str, params: dict = None, timeout: int = 60):
        for attempt in range(3):
            try:
                r = self.session.get(url, headers=self._headers(),
                                     params=params, timeout=timeout)
                if r.status_code == 429:
                    retry = int(r.headers.get("Retry-After", 30))
                    log.warning(f"Rate limited, wait {retry}s")
                    time.sleep(retry)
                    continue
                r.raise_for_status()
                return r.json()
            except Exception as e:
                if attempt == 2:
                    raise
                time.sleep(2 ** attempt)
        return {}

    def _paginate(self, url: str, params: dict = None):
        """Iterate all pages using @odata.nextLink."""
        items = []
        current_url = url
        current_params = params
        while current_url:
            data = self._get(current_url, current_params)
            items.extend(data.get("value", []))
            current_url = data.get("@odata.nextLink")
            current_params = None
        return items

    # ── PATH HELPERS (v11 tenant-aware) ───────────────────────
    def build_backup_path(self, timestamp: str = None) -> str:
        """
        Returns: /backup/m365/{tenant-slug}/{workload}/backup_{timestamp}/
        """
        if timestamp is None:
            timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        path = os.path.join(
            self.backup_root,
            self.tenant_slug,
            self.WORKLOAD_NAME,
            f"backup_{timestamp}"
        )
        os.makedirs(path, exist_ok=True)
        return path

    def get_manifest_dir(self) -> str:
        """
        Returns: /backup/m365/{tenant-slug}/{workload}/.manifests/
        """
        path = os.path.join(
            self.backup_root,
            self.tenant_slug,
            self.WORKLOAD_NAME,
            ".manifests"
        )
        os.makedirs(path, exist_ok=True)
        return path

    # ── DOWNLOAD ──────────────────────────────────────────────
    def download_file(self, url: str, dest: str, size_hint: int = 0) -> int:
        """Download with resume support (skip if exists with matching size)."""
        # Resume: skip existing complete files
        if os.path.exists(dest) and size_hint > 0:
            if os.path.getsize(dest) == size_hint:
                self.stats["files_skipped"] += 1
                return size_hint

        # Check pause/cancel before starting
        self._check_control()

        os.makedirs(os.path.dirname(dest), exist_ok=True)
        tmp = dest + ".tmp"
        try:
            r = self.session.get(url, headers=self._headers(),
                                 stream=True, timeout=300)
            r.raise_for_status()
            written = 0
            with open(tmp, "wb") as f:
                for chunk in r.iter_content(chunk_size=65536):
                    if chunk:
                        self._check_control()
                        f.write(chunk)
                        written += len(chunk)
            os.replace(tmp, dest)
            self.stats["files_downloaded"] += 1
            self.stats["bytes_downloaded"] += written
            return written
        except Exception:
            if os.path.exists(tmp):
                try:
                    os.remove(tmp)
                except OSError:
                    pass
            raise

    # ── CONTROL (pause/resume/cancel) ─────────────────────────
    def _check_control(self):
        if not self.task_id:
            return
        try:
            from app.task_control import check_control, PauseException
            check_control(self.task_id)
        except ImportError:
            pass
        except Exception:
            raise

    # ── PROGRESS ──────────────────────────────────────────────
    def emit(self, event: str, extra: dict = None):
        now = time.time()
        important = event in (
            "backup_start", "backup_done", "target_start", "target_done",
            "paused", "resumed", "cancelled", "workload_done"
        )
        if important or (now - self._last_emit > 0.5):
            self._last_emit = now
            if self.progress_callback:
                data = dict(self.stats)
                if extra:
                    data.update(extra)
                data["event"] = event
                self.progress_callback(event, data)

    # ── MAIN INTERFACE (override in subclass) ─────────────────
    def list_targets(self) -> list:
        """Enumerate what will be backed up. Override in subclass."""
        return []

    def backup(self) -> dict:
        """Main backup entry. Override in subclass."""
        raise NotImplementedError(f"{self.WORKLOAD_NAME} does not implement backup()")

    def get_workload_metadata(self) -> dict:
        """Return metadata for this workload run."""
        return {
            "workload": self.WORKLOAD_NAME,
            "tenant_id": self.tenant.get("id"),
            "tenant_name": self.tenant.get("name"),
            "tenant_slug": self.tenant_slug,
            "backup_time": datetime.now(timezone.utc).isoformat(),
        }
