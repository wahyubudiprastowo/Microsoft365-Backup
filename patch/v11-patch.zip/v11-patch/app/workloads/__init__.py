"""Workload registry — v11."""
from .base import BaseWorkload, slugify
from .sharepoint import SharePointWorkload
from .onedrive import OneDriveWorkload
from .outlook import OutlookWorkload


WORKLOAD_REGISTRY = {
    "sharepoint": SharePointWorkload,
    "onedrive": OneDriveWorkload,
    "outlook": OutlookWorkload,
}


WORKLOAD_METADATA = {
    "sharepoint": {
        "name": "SharePoint Online",
        "description": "Sites, document libraries, files",
        "icon": "bi-cloud-fill",
        "color": "#0078d4",
        "required_scopes": ["Sites.Read.All", "Files.Read.All"],
    },
    "onedrive": {
        "name": "OneDrive for Business",
        "description": "Personal cloud storage per user",
        "icon": "bi-hdd-fill",
        "color": "#0078d4",
        "required_scopes": ["Files.Read.All", "User.Read.All"],
    },
    "outlook": {
        "name": "Outlook / Exchange",
        "description": "Mail, calendar, contacts",
        "icon": "bi-envelope-fill",
        "color": "#0078d4",
        "required_scopes": ["Mail.Read", "Calendars.Read", "Contacts.Read"],
    },
    "teams": {
        "name": "Microsoft Teams",
        "description": "Channel messages (coming soon)",
        "icon": "bi-microsoft-teams",
        "color": "#6264a7",
        "required_scopes": ["ChannelMessage.Read.All"],
    },
}


def get_workload(workload_type: str, tenant: dict, backup_root: str = "/backup/m365",
                 progress_callback=None, task_id=None) -> BaseWorkload:
    """Factory: get workload instance."""
    cls = WORKLOAD_REGISTRY.get(workload_type)
    if not cls:
        raise ValueError(f"Unknown workload: {workload_type}")
    return cls(tenant=tenant, backup_root=backup_root,
               progress_callback=progress_callback, task_id=task_id)
