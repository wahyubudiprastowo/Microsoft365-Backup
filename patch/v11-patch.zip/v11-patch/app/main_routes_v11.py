"""
v11 route patches — Add these routes to main.py or import as blueprint.

Provides new endpoints that use BackupRegistry (tenant-aware) instead of
scanning old flat structure.
"""
from flask import jsonify, request
from app.backup_registry import BackupRegistry
from app.tenant_manager import TenantManager


def register_v11_routes(app):
    """
    Register v11 backup-related routes.
    
    In main.py, add:
        from app.main_routes_v11 import register_v11_routes
        register_v11_routes(app)
    """
    registry = BackupRegistry()
    
    # ── LIST all backups (tenant-aware) ──
    @app.route("/api/v2/backups")
    def list_backups_v2():
        """
        List all backups in tenant-aware structure.
        Optional query params:
          - tenant_slug: filter by tenant
          - workload: filter by workload type
        """
        tenant_slug = request.args.get("tenant_slug")
        workload = request.args.get("workload")
        
        backups = registry.list_all()
        
        if tenant_slug:
            backups = [b for b in backups if b["tenant_slug"] == tenant_slug]
        if workload:
            backups = [b for b in backups if b["workload"] == workload]
        
        return jsonify({
            "backups": backups,
            "total": len(backups),
        })

    # ── DELETE a backup ──
    @app.route("/api/v2/backups/<tenant_slug>/<workload>/<backup_name>",
               methods=["DELETE"])
    def delete_backup_v2(tenant_slug, workload, backup_name):
        result = registry.delete(tenant_slug, workload, backup_name)
        if result.get("status") == "deleted":
            return jsonify(result)
        return jsonify(result), 404

    # ── STATS aggregated ──
    @app.route("/api/v2/backups/stats")
    def backup_stats_v2():
        return jsonify(registry.get_stats())

    # ── HISTORY per tenant ──
    @app.route("/api/v2/tenants/<tenant_slug>/history")
    def tenant_history(tenant_slug):
        history = registry.get_history(tenant_slug, limit=int(request.args.get("limit", 20)))
        return jsonify({"history": history, "total": len(history)})

    # ── RUN backup (v11 — accepts tenant_id + workloads) ──
    @app.route("/api/v2/backup/start", methods=["POST"])
    def start_backup_v2():
        from app.tasks import run_backup_task
        data = request.get_json(force=True, silent=True) or {}
        tenant_id = data.get("tenant_id")  # Optional (uses active if not set)
        workloads = data.get("workloads")  # Optional (uses tenant's enabled)
        
        task = run_backup_task.delay(tenant_id=tenant_id, workloads=workloads)
        return jsonify({
            "status": "started",
            "task_id": task.id,
            "tenant_id": tenant_id or "active",
            "workloads": workloads or "tenant-default",
        })

    # ── BROWSE new folder structure ──
    @app.route("/api/v2/browse/tenants")
    def browse_tenants():
        """List tenant slugs that have backups on disk."""
        import os
        from app.backup_registry import BACKUP_ROOT
        if not os.path.exists(BACKUP_ROOT):
            return jsonify({"tenants": []})
        tenants = []
        for name in os.listdir(BACKUP_ROOT):
            path = os.path.join(BACKUP_ROOT, name)
            if os.path.isdir(path) and not name.startswith("."):
                tenants.append({"slug": name, "path": path})
        return jsonify({"tenants": tenants})

    @app.route("/api/v2/browse/<tenant_slug>/workloads")
    def browse_workloads(tenant_slug):
        """List workloads for a tenant."""
        import os
        from app.backup_registry import BACKUP_ROOT
        path = os.path.join(BACKUP_ROOT, tenant_slug)
        if not os.path.isdir(path):
            return jsonify({"workloads": []})
        workloads = []
        for name in os.listdir(path):
            wpath = os.path.join(path, name)
            if os.path.isdir(wpath) and not name.startswith("."):
                backup_count = len([
                    x for x in os.listdir(wpath)
                    if x.startswith("backup_") and os.path.isdir(os.path.join(wpath, x))
                ])
                workloads.append({"name": name, "backup_count": backup_count})
        return jsonify({"workloads": workloads})
