# 🚀 v11 Patch — Tenant-Aware Backup Structure

## What Changed

### New Folder Structure
```
/backup/m365/
├── {tenant-slug}/                        ← NEW: per-tenant grouping
│   ├── sharepoint/
│   │   ├── backup_20260628_020000/       ← per-workload backup runs
│   │   ├── backup_20260629_020000/
│   │   └── .manifests/                   ← incremental tracking
│   ├── onedrive/
│   │   └── backup_20260628_020000/
│   ├── outlook/
│   │   └── backup_20260628_020000/
│   └── .history/                         ← tenant-level backup task history
│       └── backup_20260628_020000.json
└── {another-tenant-slug}/
    └── ...
```

### Example
```
/backup/m365/
├── digiserve-by-telkom/
│   ├── sharepoint/backup_20260628_020000/
│   │   ├── BIRA_TEAM/
│   │   ├── Photo_Gallery/
│   │   └── _workload_manifest.json
│   ├── onedrive/backup_20260628_020000/
│   │   ├── user1_at_digiserve.co.id/
│   │   └── _workload_manifest.json
│   └── .history/backup_20260628_020000.json
└── contoso/
    └── sharepoint/backup_20260628_030000/
```

---

## Files Included in v11 Patch

### New/Modified Python Files
- `app/workloads/base.py` — Added `tenant` awareness + `slugify()`
- `app/workloads/sharepoint.py` — Uses `build_backup_path()` for new structure
- `app/workloads/onedrive.py` — Per-user OneDrive backup
- `app/workloads/outlook.py` — Mail/cal/contacts as JSON
- `app/workloads/__init__.py` — Factory
- `app/tasks.py` — Refactored `run_backup_task` to iterate tenant+workloads
- `app/backup_registry.py` — NEW: Scanner for new structure
- `app/main_routes_v11.py` — NEW: `/api/v2/*` endpoints

### Templates
- `app/templates/backups.html` — New UI grouped by tenant + workload

---

## Apply Patch

```bash
# 1. Stop containers
cd /media/Storage/Container/M365
docker compose down

# 2. Backup old data (optional but recommended)
tar -czf /media/Storage/Container/M365_backup_pre_v11.tar.gz \
    /media/Storage/Container/M365/data

# 3. Upload v11-patch.zip
cd /media/Storage/Container/M365
unzip v11-patch.zip

# 4. Copy new files
cp v11-patch/app/workloads/base.py       app/workloads/
cp v11-patch/app/workloads/sharepoint.py app/workloads/
cp v11-patch/app/workloads/onedrive.py   app/workloads/
cp v11-patch/app/workloads/outlook.py    app/workloads/
cp v11-patch/app/workloads/__init__.py   app/workloads/
cp v11-patch/app/tasks.py                app/
cp v11-patch/app/backup_registry.py      app/
cp v11-patch/app/main_routes_v11.py      app/
cp v11-patch/app/templates/backups.html  app/templates/

# 5. Register v11 routes in main.py
# Add these 2 lines near top of main.py:
#     from app.main_routes_v11 import register_v11_routes
# Add near where app = Flask(...) is (after route definitions):
#     register_v11_routes(app)

# 6. Rebuild + restart
DOCKER_CONFIG=/media/Storage/Container/M365/.docker docker compose build
DOCKER_CONFIG=/media/Storage/Container/M365/.docker docker compose up -d

# 7. Verify
docker compose logs -f worker
```

---

## Test Backup

Once patched, run a test backup:

```bash
# Via curl:
curl -X POST http://localhost:5055/api/v2/backup/start \
  -H "Content-Type: application/json" \
  -d '{}'

# Or via UI: click "Run Backup" button
```

Then verify new folder structure:
```bash
tree /media/Storage/Container/M365/data -L 3
# Should show:
#   data/
#   ├── digiserve-by-telkom/
#   │   ├── sharepoint/
#   │   │   └── backup_20260628_HHMMSS/
#   │   └── .history/
```

---

## Migration from Old Structure

Old v10 backups are in flat structure:
```
/backup/m365/backup_20260626_140000/
```

New v11 will create in tenant-aware structure. Old backups will still show in
Backups UI (they'll appear as "unknown-tenant" tenant slug because there's no
tenant metadata).

To migrate old backups manually:
```bash
# Assume old backup was for Digiserve tenant
mkdir -p /media/Storage/Container/M365/data/digiserve-by-telkom/sharepoint
mv /media/Storage/Container/M365/data/backup_20260626_140000 \
   /media/Storage/Container/M365/data/digiserve-by-telkom/sharepoint/
```

---

## API Endpoints (v11)

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/v2/backups` | GET | List all backups (with filters) |
| `/api/v2/backups?tenant_slug=X&workload=Y` | GET | Filtered list |
| `/api/v2/backups/stats` | GET | Aggregate statistics |
| `/api/v2/backups/<slug>/<workload>/<name>` | DELETE | Delete backup |
| `/api/v2/backup/start` | POST | Trigger backup |
| `/api/v2/tenants/<slug>/history` | GET | Backup task history |

---

## Rollback

If something breaks, restore v10:
```bash
cd /media/Storage/Container/M365
docker compose down
# Restore backup taken in step 2
tar -xzf /media/Storage/Container/M365_backup_pre_v11.tar.gz -C /
# Restore v10 files from your git/backup
docker compose up -d
```
